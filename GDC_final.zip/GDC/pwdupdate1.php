<?php
	$a= $_POST['usr'];
	$b= $_POST['pwd'];
session_start();
 
require_once("db.php");
	if(isset($_POST)) {

 
		
	$usr = mysqli_real_escape_string($conn, $_POST['usr']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
	 
	$sql = "UPDATE users SET password='$pwd' WHERE email='$usr'";

	if($conn->query($sql) === TRUE) {

		header("Location: password_update.php");
		?>
		<script type="text/javascript">
		alert('Password Updated');</script><?php
		exit();
	} else {
		echo $conn->error;
	}


	}
	 

?>