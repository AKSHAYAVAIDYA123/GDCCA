<?php
session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
//$_SESSION['callFrom'] = "a1.php";

 if(isset($_POST["sub1"]))
{

 $didval=$_POST["didval1"];
 $recipt=$_POST["recipt"]; 
 $email=$_POST["email"];  
// $search_result = $conn->query("SELECT * FROM users WHERE id_user=''");
 // mysqli_query($conn,"delete from usn");
    $sql = "UPDATE users SET lock_act='0',flag='1',recp_no='$recipt' WHERE id_user=$didval";

  if($conn->query($sql) === TRUE) {
  	if(empty($email)){
 header("Location:user-profile.php");
    exit();
  	}
  	else
  	{
  		ob_start();
 
	
	require 'class/class.phpmailer.php';
	$output = '';
	 

		$txt=$_POST['email'];
		$txt2=$_POST['email'];
		$mail = new PHPMailer;
		$mail->IsSMTP();								//Sets Mailer to send message using SMTP
	$mail ->Host = "smtp.hostinger.in";
   $mail ->Port = 587; // or 587
   		$mail->SMTPAuth = true;							//Sets SMTP 
$mail->IsHTML(true);
$mail ->Username = "gdcaa@alumnigdc.in";
   $mail ->Password = "Gdcaa@2021";
   $mail ->SetFrom("gdcaa@alumnigdc.in","Admin GDCAA");
//$mail->SetFrom('alumni@nmamit-alumni.in','A');
		 $mail->SMTPSecure = 'TLS';					
		$mail->AddAddress($txt,$txt2);	//Adds a "To" address
		$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
		$mail->IsHTML(true);							//Sets message type to HTML
		//$mail->Subject = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'; //Sets the Subject of the message
		//An HTML or plain text message body
		$mail->Subject = "Approval Status from GDCCA";
		//$mail->Body = "Click the below link to Update the Password  https://alumnigdc.in/password_update-link.php";
		 $mail->Body =   nl2br("Your request to become alumni member is approved by the admin and you can use the credentials to login using  https://alumnigdc.in/login.php.\n\n\n\n\nWith Regards\n Govinda Dasa College Alumni Association(R.)\nGovinda Dasa College,Surathkal-575014\nEmail :GDCAA2019@gmail.com\nContact Number : 9481916741,6362659243,9480347065");
  
		$mail->AltBody = '';

		$result = $mail->Send();						//Send an Email. Return true on success or false on error

		if($result["code"] == '400')
		{
			$output .= html_entity_decode($result['full_error']);
		}

	if($output == '')
	{
	//	echo 'ok';
			  echo "<script>
alert('Successfully Update the Status');
window.location.href='user-profile.php';
</script>";
	}
	else
	{
		echo $output;
	}

ob_flush();
  	}
   
  } else {
    echo $conn->error;
  }
 
}

?>