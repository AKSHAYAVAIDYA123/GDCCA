 

<?php

session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
//$_SESSION['callFrom'] = "a1.php";

if(isset($_POST["search"]))
{
   $b = $_POST['valueToSearch'];
    $a=$_POST['year'];
    
   if($a=="life_mem"){
  if($b=="ALL")
  {
    $sql = "SELECT `name`,`email`,`address`,`city`,`current_qualification`,`mode_pay`,tran_id,degree,recp_no FROM `users` where user_type='$_POST[year]' and lock_act='0'";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Name" . "\t" . "Email" . "\t" . "Address" . "\t". "Qualification of GDCC" . "\t". "Education" . "\t". "Mode of Payment" . "\t". "Tran ID" . "\t". "YOP" . "\t". "Receipt Number " . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  }
  else
  {
    $sql = "SELECT `name`,`email`,`address`,`city`,`current_qualification`,`mode_pay`,tran_id,degree,recp_no FROM `users` where user_type='$_POST[year]' and city='$_POST[valueToSearch]' and lock_act='0'";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Name" . "\t" . "Email" . "\t" . "Address" . "\t". "Qualification of GDCC" . "\t". "Education" . "\t". "Mode of Payment" . "\t". "Tran ID" . "\t". "YOP" . "\t". "Receipt Number " . "\t";  ;  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  }

 



}
else
{
  if($b=="ALL")
  {
    $sql = "SELECT `name`,`email`,`address`,`city`,`phone`,ass_work_status,retire FROM `users` where user_type='$_POST[year]' and lock_act='0'";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Name" . "\t" . "Email" . "\t" . "Address" . "\t". "Qualification of GDCC" . "\t". "phone" . "\t". "Work Status" . "\t". "YOP" . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  }
  else
  {
    $sql = "SELECT `name`,`email`,`address`,`city`,`phone`,ass_work_status,retire FROM `users` where user_type='$_POST[year]' and city='$_POST[valueToSearch]' and lock_act='0'";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Name" . "\t" . "Email" . "\t" . "Address" . "\t". "Qualification of GDCC" . "\t". "phone" . "\t". "Work Status" . "\t". "YOP" . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  }
}
 
}
 
 
?>
