<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from conven where id='$id'");
	header('location:add-conven.php');

?>