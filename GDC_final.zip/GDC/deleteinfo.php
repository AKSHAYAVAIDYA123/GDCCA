<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from convenners_description where id='$id'");
	header('location:con-des.php');

?>