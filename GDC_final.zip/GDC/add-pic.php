<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['cap'];
	$lastname=$_POST['folder'];
	$a='add.php';
 	 $lastname .= "/";
	$sql = "INSERT INTO caption (cap,folder) VALUES ('$firstname','$lastname')";
	if($conn->query($sql)===TRUE) {
		header("Location: "  . $a);
		exit();
	} else {
		echo $conn->error;
	}