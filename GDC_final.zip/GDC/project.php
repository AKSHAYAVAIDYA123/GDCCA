<?php

session_start();
 
//unset ($_SESSION["yop"]);
require_once("db.php");
$search_result = $conn->query("SELECT * FROM `donation_info` where AGREE='YES' and ap='0' and lock_bt='1' order by id desc");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDC</title>

 <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
 
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="dashboard/css/nmamit.css" rel="stylesheet"/>
    <!--Main Menu File-->
    <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu-demo.css" />
    <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
     <link href="dashboard/css/login.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css">
</head>
<body onload="myFunction1()">
<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}


.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}

.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}

.text{

  height: 50px;
  width: 490px;
    margin: 0;
    padding: 0 20px;
    vertical-align: middle;
    background: #fff;
    border: 3px solid #fff;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    font-weight: 300;
    line-height: 50px;
    color: #888; 
    color: #888;
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    border-radius: 4px;
    
}
</style>

</style>
<div class="wsmobileheader clearfix ">
  <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>
  <span class="smllogo">
    <a href="#">
      <img src="img/nitte-mobile-logo.png" alt="Nitte"/>
    </a>
  </span>
  <!-- <a href="tel:09480812310" class="callusbtn"><i class="fas fa-phone-alt" aria-hidden="true"></i></a> -->
  <a href="#search" class="callusbtn"> <i class="fas fa-search" aria-hidden="true"></i></a>
</div>
<!-- Mobile Header -->
<div class="wsmainfull clearfix top-menu">
  <div class="wsmainwp clearfix">
    <div class="desktoplogo">
      <a href="#">
        <div class="content">
          <img src="img/nitte-nmamit-logo.png" alt="GOVINDA DASA COLLEGE" title="Nitte Mahalinga Adyanthaya Memorial Institute of Technology">
          
        </div>
      </a>
    </div>

    <!--Main Menu HTML Code-->
    <nav class="wsmenu clearfix">
      <ul class="wsmenu-list main-menu">
        <!-- <li class="home-i"><a href="index.php" title="home"> <i class="fas fa-home"></i></a></li> -->
        
        <li><a href="http://www.govindadasacollege.edu.in"> Home</a></li>
     <li><a href="index.php"> About Us</a></li>
        <li><a href="login.php">Membership</a></li>
        <li><a href="archieves.php"> Archieves</a></li>
       </ul>
      <ul class="wsmenu-list main-menu-nxt">
        <li><a href="project.php">Project Funding<span class=""></span></a>
          <div class="wsmegamenu clearfix" >
            <div class="container" >
              <div class="row">
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">title</li>
                    <li><a href="">desciption</a></li>
             <li><a href="founder.php">Founder</a></li>
                    <li><a href="chairman.php">Chairman</a></li>
                  </ul>
                </div>
              
                 
              </div>
            </div>
          </div>
        </li>
       
        <li><a href="#">Blogs <span class=""></span></a>
          <div class="wsmegamenu clearfix">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">UNDERGRADUATE (BE)</li>
          <li></li>           </ul>
                </div>

              
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                       
                    <li class="title">BASIC SCIENCE & HUMANITIES DEPARTMENT</li>
                      </ul>
                </div>
              </div>
            </div>
          </div>
        </li>
         <li><a href="contact.php">Contact Us <span class=""></span></a>
          <div class="wsmegamenu clearfix">
            <div class="container">
              <div class="row">
              
              </div>
            </div>
          </div>
        </li>
        <li><a href="#">Developer Info <span class="wsarrow"></span></a>
          <div class="wsmegamenu clearfix">
            <div class="container">
              <div class="row">
                   <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">About US</li>
  									<li><a href="about-nmamit-nitte.php">About NMAMIT</a></li>
									  <li><a href="about-nmamit-nitte.php#vision-mission">Vision & Mission</a></li>
									  <li><a href="about-nmamit-nitte.php#quality-policy">Quality Policy & Core Values</a></li>
                    <li><a href="founder.php">Founder</a></li>
                    <li><a href="chairman.php">Chairman</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </li>
       

      </ul>
    </nav>
    <!--Menu HTML Code-->
  </div>
  <div class="search-top hidden-xs">
    <a href="#search"> <i class="fas fa-search"></i></a>
  </div>
</div>
<br>
<br>
<br>
 

<section class="inner-bg">
  <div class="container">
    <div class="row">
    <div class="col-sm-6" style="display:none;">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">Appeal to Alumni</h2>
      
        </p>

        <div class="strip float-right wow fadeInRight"></div>
        <div class="clearfix"></div>
      </div>

    </div>
    <div class="col-sm-12">
<div class="container">
      <div class="row">
      <div class="col-md-12">
        <div class="panel panel-login">
          <div class="panel-heading">
            <div class="row">
             <div class="col-xs-3">
                <a href="#" class="active" id="info-form-link">General Description</a>
              </div>
              <div class="col-xs-3">
                <a href="#"  id="login-form-link">Contribute to General Corpus</a>
              </div>
              <div class="col-xs-3">
                <a href="#" id="register-form-link">Contribute to a Cause</a>
              </div>
              <div class="col-xs-3">
                <a href="#" id="as-form-link">Infra / Long Term Projects</a>
              </div>
            </div>
            <hr>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-lg-12">
   <div id="as-form"  style="display: none;">

				   <p class="wow fadeInDown"> 
    This is a medium term project envisioned by the current Management of the association. As per inputs from College Principal, today college lacks the infrastructure of a well furnished VIP meeting room where the guests can be welcomed and meeting can be held. The college will provide the basic infrastructure, and association plans to furnish the same with the modern amenities including state of the art AV facilities.         </p>
         <p class="wow fadeInDown"> 
   The fund requirement will be XXXXX as per the current estimate and will change depending on when the project gets executed.
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>

<!-- Modal -->
   
</div>
     <div id="info-form">
	 <p class="wow fadeInDown"> 
	 <b>Fund Utilization & Investment Policies of GDCAA:</b> As per the Bye-laws of the associations, Executive committee has the Duty and responsibilities for Fund Management.  
        		 	</p>
	<ul>
        		<li class="wow fadeInDown"> 
        		  The EC is empowered raise, manage and utilize the funds for programs and events in furtherance of the objects of association.  	
        		</li>
        		<li class="wow fadeInDown"> 
        		EC can form and oversee Project & Functional subcommittees as may be necessary and fix their duties and responsibilities for managing the contribution on specific Programs
        		</li>
        		<li class="wow fadeInDown"> 
        		 The funds of the association shall be invested  in compliance with the Laws
        		 </li>
				<li class="wow fadeInDown"> 
				 The budget has to be prepared and approved by the EC and then by the GB in the AGM.
				 </li>
<li class="wow fadeInDown"> 
				 The budget has to be prepared and approved by the EC and then by the GB in the AGM.
				 </li>
				 <li class="wow fadeInDown"> 
				 	Bank account shall be operated jointly by the Treasurer with President or Secretary as the other signatory. 
				 </li>
				  <li class="wow fadeInDown"> 
				 	The accounts of the association will be audited annually and will be available to the members of the association. 
				</li>
				    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#donate">
 Top Contributors List
</button>
<div class="modal fade" id="donate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Contribute</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          

            <table class="table table-striped table-bordered table-hover">
            
               
                    <th>Name</th>
                      
                    <th>Purpose</th>
                     <th>Amount</th>
                   
                       
                 
                

      <!-- populate table from mysql database -->
            <?php while($row = mysqli_fetch_array($search_result)):?>
          
                <tr>
                    <td><?php echo $row['name'];?></td>
                     
                    <td><?php echo $row['purpose'];?></td>
                     <td><?php echo $row['amount'];?></td>
                   
                         </tr>
                          <?php endwhile;?>
                          </table>
             
   
                  
                    
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      
        </div>
        </form>
      </div>
    </div>
    </div>
</div>
 <div id="register-form"  style="display: none;">
    <div class="col-sm-12">
<div class="container">
      <div class="row">
      <div class="col-md-12">
        <div class="panel panel-login">
          <div class="panel-heading">
            <div class="row">
              <div class="col-xs-3">
                <a href="#" class="active" id="login-form-link1">Sponsor a Student:</a>
              </div>
              <div class="col-xs-3">
                <a href="#" id="register-form-link1">Mid-Day Meal Program</a>
              </div>
              <div class="col-xs-3">
                <a href="#" id="as-form-link1">Fund for Honoring Achievers:</a>
              </div>
                <div class="col-xs-3">
                <a href="#" id="as-form-link2">Contribute to Benevolent Fund</a>
              </div>
            </div>
            <hr>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-lg-12">
                <div id="as-form2"  style="display: none;">

           <p class="wow fadeInDown">   
    This fund will be accumulated and utilized for providing Assistance to the Needy on case by case in case of emergencies. The beneficiaries of the fund can be Alumni’s, Teachers, Students of the college or general public. The utilization will be done on a case by case basis after due verification of the cause and approval from Executive Council.     </p>
       
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>

<!-- Modal -->

       </div>
   <div id="as-form1"  style="display: none;">

				   <p class="wow fadeInDown">   
           The contributions will be used to recognize the achievers who have excelled in their respective role like
        </p>
        <ul>
        <li class="wow fadeInDown"> 
         Awarding the outstanding performance from Professors during the academic year or during reskilling themselves.  
        </li>
        <li class="wow fadeInDown"> 
          Awarding the outstanding performance from Students during the academic year  </li>
        <li class="wow fadeInDown"> 
         Awarding the outstanding achievement from fellow Alumni.
         </li>

             <p class="wow fadeInDown">   
      The Association will form a key committee consisting of College staff, association office bearers including President and Alumni member to review and finalize the Awards   </p>
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>
    </div>

 <div id="register-form1"  style="display: none;">

					 <p class="wow fadeInDown">   
        	The funds from this program will be used to provide Mid-Day Meal vouchers to the students of Govinda Dasa College. There are many students who come from rural areas or faraway places and are not able to carry their meal to the college and are not in a position to go back home for Lunch. Association will contribute money from this fund to College Mid-Day Meal program to help such students “Not to go hungry” while studying.	
        			</p>

        			<ul>
        			<li class="wow fadeInDown">
        					Contribution Amount: Minimum Rs 1500 (approximate cost for one student for one month)

        			</li>
        					<li class="wow fadeInDown">
        			 Amount of contribution to College’s Mid-Day Meal Program will be decided by Association in consultation with College Principal based on the program requirements 
        			</li>

              <li>
           
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>
              </li>
              </ul>
 
  </div>

      <div id="login-form1" >
     			 <p class="wow fadeInDown">   
        			 Funds will be used to sponsor the education of under privileged students who are facing financial difficulties to continue the education. The Association will reimburse the tuition fees of the students partially or fully. The association will review and finalize the list of students based on the recommendation received from Principal or after independently obtaining details on candidate’s financial situations.
        		</p>

        		<ul>
        		<li class="wow fadeInDown"> 
        		 	Contributions amount: Minimum Rs 2000. Contribution more than minimum amount can be one time or recurring  
        	 	</li>
        	 	<li class="wow fadeInDown"> 
        		 	Donors’ can identify the student of their choice to sponsor if they know student/s requiring such assistance and inform the same to the association along with their contribution amount.	
        		 	</li>
        		<li class="wow fadeInDown"> 
        		 	Donors’ can sponsor the tuition fee for complete one year or pledge to sponsor particular student for full course duration (3 or 2 years). Association will work with college to provide the sponsorship amount needed.
        		</li>	
        		</ul>
	
       <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>
          
</div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


    </div>
	   </div>

      <div id="login-form" method="post" style="display:none;">
     			 <p class="wow fadeInDown">   
          <?php
                 $query=mysqli_query($conn,"select * from `payment`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php 
                  if ($row['Contribute to General Corpus']=="Objectives"||$row['Contribute to General Corpus']=="Alumni Outreach") {
                    # code...
                    ?>
                    <b><?php echo $row['Contribute to General Corpus']; ?></b>
                    
                <br>
                <?php
                  }
                  else
                  {
                        echo $row['Contribute to General Corpus']; ?>
                <br>
                <?php
                  }
                  ?>
                
            </td>
            
             
          </tr>
          <?php
        }
 
      ?>
       <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>
        </p>


 
         
    </div>
  </div>
<div class="modal fade" id="exampleModal15" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Contribute</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <h5><b>For Online Transfer Transfer</b></h5> 
         <span>
           
            A/c Name: Govinda Dasa College Alumni Association<br>
            A/c Number:3512500146746201<br>
            IFSC Code:KARB0000351<br>
            Bank Name: Karnataka Bank Ltd, Iddya Branch<br>
            </span> 


              <h5><b>For Cheque</b></h5> 
         <span>
           
           Payable to Govinda Dasa College Alumni Association,<br>
            Mail:Attn: President - GDCAA<br>
            C/o Govinda Dasa College<br>
            Iddya, Surathkal 575014<br>
            </span>  

            <hr>
        <div class="container-fluid">
        <form method="POST" action="add-don.php" enctype="multipart/form-data">
          <div class="row">
            <div class="col-lg-3">
                <label class="control-label" style="position:relative; top:7px;">Type</label>
          </div>
            <div class="col-lg-9">
             <select id="mySelect" onchange="myFunction()" class="form-control"name="mySelect" required>
        <option value="">Please Select Payment Type</option>
        <option value="Cheque">Cheque</option>
            <option value="online">Online Payment</option>
      </select>   
                </div>
          </div>
          <div style="height:10px;"></div>
          <div class="row">
            <div class="col-lg-3">
                <label class="control-label" style="position:relative; top:7px;">Purpose</label>
          </div>
            <div class="col-lg-9">
              <select id="mySelect1" class="form-control" name="mySelect1" required>
        <option value="">Please Purpose</option>
        <option value="Sponsor a Student">Sponsor a Student</option>
        <option value="Contribute to General Corpus">Contribute to General Corpus</option>

          <option value="Mid-Day Meal Program">Mid-Day Meal Program</option>
        <option value="Fund for Honoring Achievers">Fund for Honoring Achievers</option>

          <option value="Contribute to Benevolent Fund">Contribute to Benevolent Fund</option>
        <option value="Infra / Long Term Projects">Infra / Long Term Projects</option>
        </select> 
            </div>
          </div>
           <div style="height:10px;"></div>
          <div class="row" >
            <div class="col-lg-3">
             <label class="control-label" style="position:relative; top:7px;">Amount</label>
       
            </div>
            <div class="col-lg-9">
             <input type="text" name="amt" id="amt"  class="form-control1" placeholder="Amount" >
          
      
            </div>
          </div>

           <div style="height:10px;"></div>
          <div class="row" >
            <div class="col-lg-3">
             <label class="control-label" style="position:relative; top:7px;">Name</label>
       
            </div>
            <div class="col-lg-9">
             <input type="text" name="name" id="name"  class="form-control1" placeholder="Name" >
          
      
            </div>
          </div>
              <div style="height:10px;"></div>
          <div class="row">
            <div class="col-lg-8">
            <label class="control-label" style="position:relative; top:7px;">Agree to report contribution to large group</label>
             </div>
            <div class="col-lg-4">
                   <input type="radio" id="Y" name="report" value="YES">
         <label>Yes</label> 
         <input type="radio" id="N" name="report" value="NO">
         <label  >No</label><br>
            </div>
          </div>
  
          <div style="height:10px;"></div>
          <div class="row" id="row12">
            <div class="col-lg-6">
             <label class="control-label" style="position:relative; top:7px;">Cheque # and Bank Drawn</label>
       
            </div>
            <div class="col-lg-6">
               <!-- <input type="text" name="tran_id"    class="form-control1" placeholder="Online Confirmation" >
         -->
             <input type="text" name="name2" id="name2"  class="form-control1" placeholder="Cheque # and Bank Drawn" >
         
            </div>
          </div>
       <div style="height:10px;"></div>
          <div class="row" id="row13">
            <div class="col-lg-6">
             <label class="control-label" style="position:relative; top:7px;">Online Payment Confirmation</label>
       
            </div>
            <div class="col-lg-6">
                   <input type="text" name="name1" id="name1"  class="form-control1" placeholder="Confirmation" >
        
      
            </div>
          </div>
        </div>
          
 
 
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="save"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
   
        </div>
        </form>
      </div>
    </div>
  </div> 

    </div>
     
    </div>
  
  </div>

</section>   
 
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/menu.js"></script>

<script type="text/javascript">
  $(function() {


  	   $('#info-form-link').click(function(e) {
    $("#info-form").delay(100).fadeIn(100);
    $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $("#as-form").fadeOut(100);
    $('#as-form-link').removeClass('active');
     $("#login-form").fadeOut(100);
    $('#login-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });

    $('#login-form-link').click(function(e) {
    $("#login-form").delay(100).fadeIn(100);
    $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $("#as-form").fadeOut(100);
    $('#as-form-link').removeClass('active');
     $("#info-form").fadeOut(100);
    $('#info-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });
  $('#register-form-link').click(function(e) {
    $("#register-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
    $('#login-form-link').removeClass('active');
     $("#as-form").fadeOut(100);
    $('#as-form-link').removeClass('active');
     $("#info-form").fadeOut(100);
    $('#info-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });


    $('#as-form-link').click(function(e) {
    $("#as-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
      $("#register-form").fadeOut(100);
         $("#info-form").fadeOut(100);
    $('#info-form-link').removeClass('active');
   
    $('#register-form-link').removeClass('active');
    $('#login-form-link').removeClass('active');

    $(this).addClass('active');
    e.preventDefault();
  });

 ///--------------------------------------------

    $('#login-form-link1').click(function(e) {
    $("#login-form1").delay(100).fadeIn(100);
    $("#register-form1").fadeOut(100);
    $('#register-form-link1').removeClass('active');
    $("#as-form1").fadeOut(100);
    $('#as-form-link1').removeClass('active');
  $("#as-form2").fadeOut(100);
    $('#as-form-link2').removeClass('active');

    $(this).addClass('active');
    e.preventDefault();
  });
  $('#register-form-link1').click(function(e) {
    $("#register-form1").delay(100).fadeIn(100);
    $("#login-form1").fadeOut(100);
    $('#login-form-link1').removeClass('active');
     $("#as-form1").fadeOut(100);
    $('#as-form-link1').removeClass('active');
     $("#as-form2").fadeOut(100);
    $('#as-form-link2').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });


    $('#as-form-link1').click(function(e) {
    $("#as-form1").delay(100).fadeIn(100);
    $("#login-form1").fadeOut(100);
      $("#register-form1").fadeOut(100);
    $('#register-form-link1').removeClass('active');
    $('#login-form-link1').removeClass('active');
  $("#as-form2").fadeOut(100);
    $('#as-form-link2').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });

     $('#as-form-link2').click(function(e) {
    $("#as-form2").delay(100).fadeIn(100);
      $("#as-form1").fadeOut(100);
    $('#as-form-link1').removeClass('active');
    $("#login-form1").fadeOut(100);
      $("#register-form1").fadeOut(100);
    $('#register-form-link1').removeClass('active');
    $('#login-form-link1').removeClass('active');

    $(this).addClass('active');
    e.preventDefault();
  });

});

</script>
<script type="text/javascript">    
function myFunction() {
  var x = document.getElementById("mySelect").value; 
 // alert(x);
  if(x=="Cheque")
  {
      document.getElementById("row12").style.display = "block";
document.getElementById("row13").style.display = "none";
  }
  else if(x=="online")
  {
    document.getElementById("row13").style.display = "block";
     document.getElementById("row12").style.display = "none";
  }

}
function myFunction1() {
 
document.getElementById("row12").style.display = "none";
document.getElementById("row13").style.display = "none";

}

</script>


<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
 
 
</body>
</html>
