<?php

session_start();
 
//unset ($_SESSION["yop"]);
require_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDC</title>

 <link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="../dist/css/custom.css">
  <link rel="stylesheet" href="../dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/form-elements.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="../assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <link href="css/nmamit.css" rel="stylesheet"/>
    <!--Main Menu File-->
    <link id="effect" rel="stylesheet" type="text/css" media="all" href="css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="css/menu.css" />
    <link rel="stylesheet" type="text/css" media="all" href="css/menu-demo.css" />
    <link id="theme" rel="stylesheet" type="text/css" media="all" href="css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="css/all.css" rel="stylesheet"/>
     <link href="css/login.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/magnific/magnific-popup.css">
</head>
<body>

<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}

.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}

.text{

  height: 50px;
  width: 490px;
    margin: 0;
    padding: 0 20px;
    vertical-align: middle;
    background: #fff;
    border: 3px solid #fff;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    font-weight: 300;
    line-height: 50px;
    color: #888; 
    color: #888;
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    border-radius: 4px;
    
}
</style>

</style>
<div class="wsmobileheader clearfix ">
  <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>
  <span class="smllogo">
       <img src="img/nitte-mobile-logo.png" alt="Nitte"/>
  
  </span>
  <!-- <a href="tel:09480812310" class="callusbtn"><i class="fas fa-phone-alt" aria-hidden="true"></i></a> -->
  <a href="#search" class="callusbtn"> <i class="fas fa-search" aria-hidden="true"></i></a>
</div>
<!-- Mobile Header -->
<div class="wsmainfull clearfix top-menu">
  <div class="wsmainwp clearfix">
    <div class="desktoplogo">
       <div class="content">
          <img src="img/nitte-nmamit-logo.png" alt="Nitte Mahalinga Adyanthaya Memorial Institute of Technology" title="Nitte Mahalinga Adyanthaya Memorial Institute of Technology">
          
        </div>
    </div>

    <!--Main Menu HTML Code-->
    <nav class="wsmenu clearfix">
      <ul class="wsmenu-list main-menu">
        <!-- <li class="home-i"><a href="index.php" title="home"> <i class="fas fa-home"></i></a></li> -->
        
        <li><a href="rankings.php"> Home</a></li>
     <li><a href="admissions.php"> About Us</a></li>
        <li><a href="membership.php">Membership</a></li>
        <li><a href="placement.php"> Archieves</a></li>
        <li>         <li><a href="contact-nmamit.php">Event /News</a></li>
      </ul>
      <ul class="wsmenu-list main-menu-nxt">
        <li><a href="#">Project Funding<span class=""></span></a>
          <div class="wsmegamenu clearfix" >
            <div class="container" >
              <div class="row">
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">title</li>
                    <li><a href="">desciption</a></li>
             <li><a href="founder.php">Founder</a></li>
                    <li><a href="chairman.php">Chairman</a></li>
                  </ul>
                </div>
              
                 
              </div>
            </div>
          </div>
        </li>
       
        <li><a href="#">Blogs <span class=""></span></a>
          <div class="wsmegamenu clearfix">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">UNDERGRADUATE (BE)</li>
          <li></li>           </ul>
                </div>

              
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                       
                    <li class="title">BASIC SCIENCE & HUMANITIES DEPARTMENT</li>
                      </ul>
                </div>
              </div>
            </div>
          </div>
        </li>
         <li><a href="#">Contact Us <span class=""></span></a>
          <div class="wsmegamenu clearfix">
            <div class="container">
              <div class="row">
              
              </div>
            </div>
          </div>
        </li>
        <li><a href="#">Developer Info <span class="wsarrow"></span></a>
          <div class="wsmegamenu clearfix">
            <div class="container">
              <div class="row">
                 
              </div>
            </div>
          </div>
        </li>
       

      </ul>
    </nav>
    <!--Menu HTML Code-->
  </div>
  <div class="search-top hidden-xs">
    <a href="#search"> <i class="fas fa-search"></i></a>
  </div>
</div>
<br>
<br>
<br>
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<section class="inner-bg">
  <div class="container">
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
    <div class="row">
    <div class="col-sm-6">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">Appeal to Alumni</h2>
        <p class="wow fadeInDown"> Greetings to you. We feel very happy to announce that our long standing wait for an Alumni  AssociationofGovinda Dasa Collegehas become a reality.Govinda Dasa College Alumni Association (GDCAA) has officially come into existence in December 2019. Our pursuit of bringing together all the alumni of our Alma mater under one umbrella has begun and it is incomplete without YOU. Let’s come together and  work to relive our glorious days at the college. It is time for us to do contribute something valuable in our little ways to the Institution that has shaped our lives to a considerable extent. More importantly let us take it as an opportunity to show our patronage to the present generation of students who are occupying our benches where we used to sit long back</p>
       
    <p class="wow fadeInDown">Objective of the Association is to provide acommon platform for all the ex-studentsto come together andshare their rich experiences in various fields with each other, with present staff and students of the college.Association will provide opportunity to re-exhibit alumni talents in sports and entertainment through exclusive programs; inspire such talents amongst present students; promote scholarship and welfare schemes for deserving students, undertake developmental activities for the college, students and to the society</p>
    

        <p class="wow fadeInDown">To becomepart of this wonderful journey, all you need to do is become member of the GDCAA. Lifetime Membership of the association costs Rs. 2000. The membership will provide platform for alumni’s to interact with other alumni’s, participate & vote in AGM of the association, become office bearers of the Executive Committee, receive association communications, actively participate and contribute in all the activities of the association.</p>
    
        <p class="wow fadeInDown">We also requestgenerous donationin addition tothe membership fee,whichwill go a long way in executing the objectives we have set for ourselves. </p>
        <p class="wow fadeInDown">Please fill in enclosed Alumni Membership Application Form and submit the same along with the membership fee.We also need your assistance in reaching out to the other Alumni’s of the GDC you are aware and encourage them to subscribe to the membership of the association.Let us all join hands as partners in making our Alma Mater a Centre of Excellence. Together WE CAN and WE WILL</p>


        <div class="strip float-right wow fadeInRight"></div>
        <div class="clearfix"></div>
      </div>

    </div>
    <div class="col-sm-6">
<div class="container">
      <div class="row">
      <div class="col-md-12">
        <div class="panel panel-login">
          <div class="panel-heading">
            <div class="row">
              <div class="col-xs-6">
                <a href="#" class="active" id="login-form-link">Login</a>
              </div>
              <div class="col-xs-6">
                <a href="#" id="register-form-link">Register</a>
              </div>
            </div>
            <hr>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-lg-12">

      <form id="login-form" method="post" action="checklogin.php">
      <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
    
        <div class="col-xs-4">

          <button type="submit" class="btn btn-info">Sign In</button>          
        </div>
        <!-- /.col -->
      </div>
      <div class="row">
        <div class="col-xs-12">
            <span id="loginError" class="color-red hide-me">Invalid Email/Password!</span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form>
                  <form id="register-form" action="index.html" method="post" style="display: none;">
      <div class="form-group has-feedback">
        <input type="text" id="name" name="name" class="text" placeholder="Full name" style="padding: 0 20 0 0px;"required>
        <span id="nameError" class="color-red hide-me">Name Error</span>
      </div>

       <div class="form-group has-feedback">
        <input type="email" id="email" name="email" class="form-control" placeholder="Email" required>
               <span id="emailError" class="color-red hide-me">Email Error</span>
        <span id="emailExistsError" class="color-red hide-me">Email Error</span>
        
      </div>
                  
                  <div class="form-group">
                    <input type="password" name="password" id="password" tabindex="2" class="text" placeholder="Password">
                  </div>
                  <div class="form-group">
                       <input type="password" id="cpassword" name="cpassword" class="text" placeholder="Retype password" required>
         <span id="cpasswordError" class="color-red hide-me">Confirm Password Error</span>

                  </div>


                  <div class="form-group">
                    <input type="text" name="address" id="address" tabindex="1" class="form-control" placeholder="    Address" required>
                    </div>
                
                    <div class="form-group">
                    <input type="text" name="phone" id="phone" tabindex="1" class="form-control" placeholder="    Contact Number">
                  </div>


                    <div class="form-group">
                    <input type="text" name="yop" id="yop" tabindex="2" class="form-control" placeholder="Year of Passout">
                  </div>


                     <div class="form-group">
                     <select name="dept" class="form-control" id="dept"  required>
<option value="" selected="selected">Select the Department</option>
<?php
$sql = "SELECT DISTINCT dept FROM usn where dept !='' order by dept";

$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["dept"]; ?>"><?php echo $rows["dept"]; ?></option>
<?php } ?>
</select>  
                   </div>
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-12 ">
                        <button id="sbtBtn" type="submit" class="btn btn-primary btn-block btn-flat">Register</button>
                 </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


    </div>
     
    </div>
  </div>
</section>   
 
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/menu.js"></script>

<script type="text/javascript">
  $(function() {

    $('#login-form-link').click(function(e) {
    $("#login-form").delay(100).fadeIn(100);
    $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });
  $('#register-form-link').click(function(e) {
    $("#register-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
    $('#login-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });

});

</script>


<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
<script>
  $('#registerForm').on("submit", function(e) {
    e.preventDefault();

    var errors = false;

    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

    //Minimum 8 Characters with at least 1 letter and 1 number
    var passwordReg = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
 
    if($("#cpassword").val() === $("#password").val()) {
      $("#cpasswordError").hide();
    } else {
        $("#cpasswordError").text("Password Mismatch");
        $("#cpasswordError").show();
        errors = true;
    }

    if(errors == false) {
      if(emailReg.test($("#email").val())) {
        $("#emailError").hide();
        $.post("checkemail.php", { email: $("#email").val()}).done(function(data) {
          var result = $.trim(data);
          if(result == "Error") {
            $("#emailExistsError").text("This email is already registered with us. Choose Different Email.");
            $("#emailExistsError").show();
          } else {
            $("#emailExistsError").hide();
            adduser();
          } 
        });
      } else {
          $("#emailError").text("Email should be of format example@example.com");
          $("#emailError").show();
      }
    }
    



  });
</script>
<script>
  function adduser() {
     $.post("adduser1.php", $("#registerForm").serialize() ).done(function(data) {
        var result = $.trim(data);
        if(result == "ok") {
          window.location.href = "login.php";
        }
      });
  }
</script>
<script>
  $(function() {
    $("#registeredSuccessfully:visible").fadeOut(8000);
  });
</script>
 
 
</body>
</html>
