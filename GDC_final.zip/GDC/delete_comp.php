<?php
require_once("db.php");
$sql = "DELETE FROM company WHERE Id='" . $_GET["Id"] . "'";
mysqli_query($conn,$sql);
	?>
		<script>
		alert('Information Successfully Deleted');
       window.location.href='view%20company.php?Successfully';
        </script>
		<?php    

?>