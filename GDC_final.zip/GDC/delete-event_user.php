<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from event_reg_user where id_event='$id'");
	header('location:eventadd.php');

?>