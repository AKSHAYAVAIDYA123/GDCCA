<?php
require_once("db.php");

$sql = "SELECT * FROM caption";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $capt = $row['cap'];
   
  }
}
$result511 = $conn->query("SELECT * FROM caption");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>NMAMIT</title>
    <link rel="stylesheet" href="gallery/style.css">
    <script src="gallery/jquery-3.4.1.min.js"></script>
    <script src="gallery/script.js"></script>
    
     <script src="dist1/js/lightbox-plus-jquery.min.js"></script>
     
 <link rel="stylesheet" href="dist1/css/lightbox.min.css">
    
        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">   

 <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
     <?php include_once("header1.php"); ?>
       <br> 
    <div class="container">
    <?php
            $i=1;
            while($row1 = mysqli_fetch_array($result511)) {
                    
            ?>
        <div class="box">
            <div class="titleHolder">
            <h1><?php echo $row1["cap"]; ?></h1>
                <div class="btn">show</div>
            </div>
                
              <div class="ImageHolder" style="display:none;">
            <?php
$a=$row1["folder"];
$folder_path = $a; //image's folder path

$num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);

$folder = opendir($folder_path);
 
if($num_files > 0)
{
    while(false !== ($file = readdir($folder))) 
    {
        $file_path = $folder_path.$file;
        $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
        if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp') 
        {
            ?>
            <!--<a href="" height="100" width="100"><img src="<?php echo $file_path; ?>"  height="150" width="150" /></a>
              <img class="images" src="<?php echo $file_path; ?>" alt="">-->
              <style>
                  .zoom {
  
  transition: transform .2s; /* Animation */
  width: 150px;
  height: 150px;
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
img{
    margin:10px;
}
</style>
              </style>
            <a href="<?php echo $file_path; ?>" data-lightbox="<?php echo $row1["cap"]; ?>" height="100" width="100"><img src="<?php echo $file_path; ?>"  class="zoom"height="150" width="150" /></a>
 
            <?php
        }
    }
}
else
{
    echo "the folder was empty !";
}
closedir($folder);
?>
            <!--    <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">-->
            </div>
        </div>
  <?php
            

            }

?>
         
    </div>

    <div class="popBox">
        <div class="butn-Holders">
            <!--Close button-->
            <div class="butn btn-Close">X</div>
            <!--Prev button-->
            <div class="butn btn-Prev" style="display:none;"><</div>
            <!--Next button-->
            <div class="butn btn-Next" style="display:none;">></div>
        </div>

        <img src="" alt="images"/>
    </div>
</body>
</html>