<?php
 
session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");


$_SESSION['callFrom'] = "email.php";
?>
<!DOCTYPE html>
<html>
  <head>
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GDCAA</title>

  <!-- Google Font --> 
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">  
  </head>
  <body class="hold-transition skin-blue sidebar-mini">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <!-- Header -->
     <script type="text/javascript">
                function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}</script>
    <br />
    <div class="container">
	  
      <h3 align="center">Send Bulk Email </h3>
      <br />
	  
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                   <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Message and Subject Dialog</h4></center>
                </div>
                
                 <div class="modal-body">
        <div class="container-fluid">
                <form class="form-horizontal" action="update-subject-msg.php"  method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                
                 
    <input type="text" class="form-control"  name="name1" placeholder="Enter the SUBJECT">
	</div>
	<div class="form-group">
	 <textarea class="form-control" name="msg" placeholder="Enter text here...">
</textarea>
                  </label>
                </div>
              </div>
                </div>
                        <div class="box-footer">
               
                  </div>
          </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> save</a>
        </form>
                </div>
                </div>
                </form>
                </div>
                </div>
      <div class="table-responsive">
        <form>
        <table class="table table-bordered table-striped">
          <tr>
            <th>Customer Name</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Message</th>
             <th>Select<br>Select ALL<input type="checkbox" onclick="toggle(this);" /><br />
</th>
            <th>Action</th>
          </tr>
        <?php
        $count = 0;

                   $sql1 = "SELECT * FROM users where name !='admin'";
                    $result = $conn->query($sql1);
                    if($result->num_rows > 0) {
        foreach($result as $row)
        {
          $count = $count + 1;
          echo '
          <tr>
            <td>'.$row["name"].'</td>
            <td>'.$row["email"].'</td>
            <td>'.$row["name1"].'</td>
            <td>'.$row["msg"].'</td>
            <td>
              <input type="checkbox" name="single_select" class="single_select" data-email="'.$row["email"].'"  data-name="'.$row["name"].'" data-email1="'.$row["name1"].'" data-email2="'.$row["msg"].'" />
            </td>
            <td>
            <button type="button" name="email_button" class="btn btn-info btn-xs email_button" id="'.$count.'" data-email="'.$row["email"].'" data-name="'.$row["name"].'"  data-email1="'.$row["name1"].'" data-email2="'.$row["msg"].'"data-action="single">Send Single</button>
            </td>
          </tr>
          ';
        }
      }
        ?>
          <tr>
            <td colspan="2"></td>
            <td><button type="button" name="bulk_email" class="btn btn-info email_button" id="bulk_email" data-action="bulk">Send Bulk</button> 
          
 <a href="#myModal" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span>ADD Message and Subject </a></td></td>
 <td colspan="3"></td>
      
          </tr>
        </table>
   </form>
   </div>
   </button>
   </div>
   </form>
  
   

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>
   <footer class="main-footer footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
  </body>
</html>

<script>
$(document).ready(function(){
  $('.email_button').click(function(){
    $(this).attr('disabled', 'disabled');
    var id  = $(this).attr("id");
    var action = $(this).data("action");
    var email_data = [];
    if(action == 'single')
    {
      email_data.push({
        email: $(this).data("email"),
        email1: $(this).data("email1"),
        name: $(this).data("name"),
        email2: $(this).data("email2")
      });
    }
    else
    {
      $('.single_select').each(function(){
        if($(this).prop("checked") == true)
        {
          email_data.push({
            email: $(this).data("email"),
            email1: $(this).data("email1"),
            name: $(this).data('name'),
            email2: $(this).data("email2")
          });
        } 
      });
    }

    $.ajax({
      url:"send_mail2.php",
      method:"POST",
      data:{email_data:email_data},
      beforeSend:function(){
        $('#'+id).html('Sending...');
        $('#'+id).addClass('btn-danger');
      },
      success:function(data){
        if(data == 'ok')
        {
          $('#'+id).text('Success');
          $('#'+id).removeClass('btn-danger');
          $('#'+id).removeClass('btn-info');
          $('#'+id).addClass('btn-success');
        }
        else
        {
          $('#'+id).text(data);
        }
        $('#'+id).attr('disabled', false);
      }
    })

  });
});
</script>



