<?php
	require_once("db.php");
 
	$id=$_GET['id'];

	$firstname=$_POST['a'];
	$lastname=$_POST['b'];
 
	mysqli_query($conn,"update caption set cap='$firstname', folder='$lastname' where id='$id'");
	header('location:add.php');

	
?>