<?php

session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");

   $search_result=$conn->query("SELECT * FROM `usn`");
  $search_result1= $conn->query("SELECT * FROM `usn`");
 
 

$query =  "SELECT degree,COUNT(*) as number FROM users GROUP BY degree";
 $result = mysqli_query($conn, $query); 

$_SESSION['callFrom'] = "up_asso.php";

if (isset($_POST["import"])) {
    
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {

         
 
	   $sql = "SELECT * FROM  users where id_user='$column[0]'"; 
	   $result = $conn->query($sql);
               

                if($result->num_rows > 0) {

                		$type = "error";
                $message = "Some Data Already Exist";
				}
				else
				{
           if($column[0]!=''){

            $sqlInsert = "INSERT into users (type,id_user,name,email,password,address,DOB,city,flag,lock_act,createdAt,phone,user_type,ass_work_status,retire,recp_no,degree)
                   values ('user','" . $column[0] . "','" . $column[1] . "','" . $column[2] . "','" . $column[3] . "','" . $column[4] . "','" . $column[5] . "','" . $column[6] . "','1','0',now(),'" . $column[7] . "','Associative Member','" . $column[8] . "','" . $column[9] . "','" . $column[10] . "','')";
            $result = mysqli_query($conn, $sqlInsert);
            
            if (! empty($result)) {
                 header('location:up_life.php');
                   $message = "uploaded Successfully";
            } else {
                $type = "error";
                $message = $conn->error;
            }
            }
					    
				}
        }
    }
}


?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
 <script type="text/javascript" src="dist\js\jquery-3.2.1.min.js.js"></script>

<style>
body {
    font-family: Arial;
  /*  width: 550px;*/
}

.outer-scontainer {
    background: #F0F0F0;
    border: #e0dfdf 1px solid;
    padding: 20px;
    border-radius: 2px;
}

.input-row {
    margin-top: 0px;
    margin-bottom: 20px;
}

.btn-submit {
    background: #333;
    border: #1d1d1d 1px solid;
    color: #f0f0f0;
    font-size: 0.9em;
    width: 100px;
    border-radius: 2px;
    cursor: pointer;
}

.outer-scontainer table {
    border-collapse: collapse;
    width: 100%;
}

.outer-scontainer th {
    border: 1px solid #dddddd;
    padding: 8px;
    text-align: left;
}

.outer-scontainer td {
    border: 1px solid #dddddd;
    padding: 8px;
    text-align: left;
}

#response {
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 2px;
    display:none;
}

.success {
    background: #c7efd9;
    border: #bbe2cd 1px solid;
}

.error {
    background: #fbcfcf;
    border: #f3c6c7 1px solid;
}

div#response.display-block {
    display: block;
}
</style>
<script type="text/javascript">
$(document).ready(function() {
    $("#frmCSVImport").on("submit", function () {

        $("#response").attr("class", "");
        $("#response").html("");
        var fileType = ".csv";
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
        if (!regex.test($("#file").val().toLowerCase())) {
                $("#response").addClass("error");
                $("#response").addClass("display-block");
            $("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
            return false;
        }
        return true;
    });
});
</script>



  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
     <div class="outer-scontainer" id="didval">
        <div class="row" >
  <div class=" col-md-6  "  >
        <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport" enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-0 control-label">Choose CSV For Associate Member 
                        File</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button>
                    <br />

                </div>

            </form>

    </div>
    <div class=" col-md-6  "  style="display:none;" >
         <form action="" method="post">
           <label class="col-md-0 control-label">Select Year and Department
                        </label> 
             <div class="input-group col-sm-6">

            <select name="valueToSearch" class="form-control" id="valueToSearch" required>
<option value="" selected="selected">STREAM</option>
<?php
$sql = "SELECT DISTINCT dept FROM usn";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
  if (!empty($rows["dept"])) {
?>

<option value="<?php echo $rows["dept"]; ?>"><?php echo $rows["dept"]; ?></option>
<?php }} ?>
</select>  
              <span class="input-group-btn">

                <select name="year" class="form-control" id="year" required>>
<option value="" selected="selected">Year</option>
<?php
$sql = "SELECT DISTINCT yop FROM usn";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["yop"]; ?>"><?php echo $rows["yop"]; ?></option>
<?php } ?>
</select>  





  
            <input type="submit" name="search" value="View" class="btn btn-info" id ="printbtn">

               <a class="btn btn-success hidden-print"  id ="printbtn" href="javascript:window.print()"><span class="glyphicon glyphicon-print"> Print</span></a>
 
</span>
            </div>
     
    </div>
         
        </div>
        </div>
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
                   <div class="table-responsive" style="width:500px;">
            <br>
               <?php while($row1 = mysqli_fetch_array($search_result1)):?>

             
     <form  method="POST" action="" class="form-horizontal"  enctype="multipart/form-data" >
   
<input type='hidden' name='didval' value="<?php echo $row1['id_user']; ?>" > 
 
 </form>
             <?php endwhile;?>
                  
          
           <script type="text/javascript">
      

            if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
            </script>
           
            </div>
       
                  </div>
      
    <!-- /.content -->
  
  <!-- /.
  <!-- /.content-wrapper -->

  

</div>
<!-- ./wrapper -->
    <footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
