<?php
require_once("db.php");

$sql = "SELECT * FROM caption";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $capt = $row['cap'];
   
  }
}
$result511 = $conn->query("SELECT * FROM caption");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Allumni</title>
    <link rel="stylesheet" href="assets/style1.css">
    <script src="assets/jquery1-3.4.1.min.js"></script>
    <script src="assets/script1.js"></script> 
  <!-- Bootstrap 3.3.7 -->


        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">   

 <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
     <?php include_once("header1.php"); ?>
       <br>
 <!--   <header>NMAMIT ALUMNI ASSOCIATION</header>-->
    <div class="container">
<link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
<?php
       		$i=1;
            while($row1 = mysqli_fetch_array($result511)) {
     				
            ?>
        <div class="box">
            <div class="titleHolder">
                <h1 style="font-family: 'Audiowide';"><?php echo $row1["cap"]; ?></h1>
                <div class="btn">show</div>
            </div>

            <div class="ImageHolder">
            <?php
$a=$row1["folder"];
$folder_path = $a; //image's folder path

$num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);

$folder = opendir($folder_path);
 
if($num_files > 0)
{
	while(false !== ($file = readdir($folder))) 
	{
		$file_path = $folder_path.$file;
		$extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
		if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp') 
		{
			?>
            <a href="<?php echo $file_path; ?>" height="100" width="100"><img src="<?php echo $file_path; ?>"  height="150" width="150" /></a>
            <?php
		}
	}
}
else
{
	echo "the folder was empty !";
}
closedir($folder);
?>
            <!--    <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">-->
            </div>
        </div>
    <?php
            

            }

?>
        
    </div>
</body>
</html>