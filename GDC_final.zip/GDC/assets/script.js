$('document').ready(function(){

    console.log("hello Samanth here!");


    $(".box , .btn-Close , .popBox , .images").hide();

    $(".box , .images").each(function(i){
        $(this).delay(200 * i).fadeIn(200);
    });

    $('.btn').click(function(){
        $(this).parent().siblings().slideToggle();
    });

    /* Count number of images inside all .ImageHolder class*/
    var counts = $('.ImageHolder .images').length;
    console.log(counts);

    /* When user press escape key */
    $(document).on('keyup', function(event) { 
        if (event.key == "Escape") { 
            $('.btn-Close').click();
            console.log("esc");
        } 
        else if(event.keyCode == 39){
            $('.btn-Next').click();
            console.log("Next");
        }
        else if(event.keyCode == 37){
            $('.btn-Prev').click();
            console.log("Prev");
        }
    });

    /* Clicking on images function that will popup image viewer */
    $('.images').click(function(){
        
        var item = $(this).attr('src');
        
        var $first = $('.images:first'),
        $last = $('.images:last');
        
        $('.container , header').css({
              filter:'blur(50px) grayscale(100)'
        });

        $('.popBox').fadeIn(200);

        $(".popBox img").attr("src", item);

        /* Button close */
        $('.btn-Close').fadeIn(200).click(function(){
            
            $('.container , header').css({
                filter:'blur(0px) grayscale(0)'
            });

            $(this).parent().parent().hide();
        });

        /* Button Next */
        $('.btn-Next').click(function(){

            var $next,
            $selected = $(".selected");

            $next = $selected.next('.images').length ? $selected.next('.images') : $first;
            $selected.removeClass("selected");
            $next.addClass('selected');
            $(".popBox img").attr("src", $next.attr('src'));
            var s = $next.attr('src');
            console.log(s);
        });

        /* Button Prev */
        $('.btn-Prev').click(function(){
    
            var $prev,
            $selected = $(".selected");

             $prev = $selected.prev('.images').length ? $selected.prev('.images') : $last;
            $selected.removeClass("selected");
            $prev.addClass('selected');
            
            $(".popBox img").attr("src", $prev.attr('src'));
            var p = $prev.attr('src');
            console.log(p);
        });
        
    });

});