<?php
session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
//$_SESSION['callFrom'] = "a1.php";

 if(isset($_POST["sub1"]))
{

 $didval=$_POST["didval1"];  
 // $search_result = $conn->query("SELECT * FROM users WHERE id_user=''");
 // mysqli_query($conn,"delete from usn");
    $sql = "UPDATE users SET lock_act='0',flag='1' WHERE id_user=$didval";

  if($conn->query($sql) === TRUE) {
    header("Location:user-profile.php");
    exit();
  } else {
    echo $conn->error;
  }
 
}

?>