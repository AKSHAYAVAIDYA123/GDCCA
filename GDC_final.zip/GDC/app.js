window.onload= () => {

// Declarations 
const showCheckbox = document.getElementById('checkbox-show');
const hideCheckbox = document.getElementById('checkbox-hide');
const displayBox = document.getElementById('display-model');


const showDisplay = () =>{
    console.log("visible");
    displayBox.style="display:block";
}

const hideDisplay = () =>{
    console.log("hidden");
    displayBox.style="display:none";
}

// on click event listeners when clicked on specific radio button
showCheckbox.addEventListener('click',showDisplay);
hideCheckbox.addEventListener('click',hideDisplay);

}