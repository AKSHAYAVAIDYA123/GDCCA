<?php
session_start();
$name='';
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");

if(isset($_POST["search"]))
{
     $a=$_POST['year'];
     echo $a;
     if($a=="all")
  {
    $sql = "SELECT `name`,`payment_type`,`purpose`,`amount`,`Agree`,`confirmation`,chq_info,updated_at,rcn  FROM `donation_info` where ap='0'";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Name" . "\t" . "Payment Mode" . "\t" . "Purpose" . "\t". "Amount" . "\t". "Agree to Contribute" . "\t". "Online Confirmation" . "\t". "Cheque info" . "\t". "Approve Time" . "\t". "Receipt No" . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=donation.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  

  }
  else
  {
     $sql = "SELECT `name`,`payment_type`,`purpose`,`amount`,`Agree`,`confirmation`,chq_info,updated_at,rcn  FROM `donation_info` where purpose='$_POST[year]' and ap='0'";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Name" . "\t" . "Payment Mode" . "\t" . "Purpose" . "\t". "Amount" . "\t". "Agree to Contribute" . "\t". "Online Confirmation" . "\t". "Cheque info" . "\t". "Approve Time" . "\t". "Receipt No" . "\t"; 
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=donation.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  }
   
}
 
 
 
 
  ?>