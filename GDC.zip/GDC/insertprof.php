<?php

session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}

require_once("db.php");

$name = $designation ="";

$sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $email = $row['email'];
    $designation = $row['designation'];
    $degree = $row['degree'];
  }
}

if(isset($_POST)) {

	//$id=mysqli_real_escape_string($conn, $_POST['$_SESSION[id_user]');
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$company = mysqli_real_escape_string($conn, $_POST['company']);
	$position = mysqli_real_escape_string($conn, $_POST['position']);
	$place = mysqli_real_escape_string($conn, $_POST['place']);
	$start = mysqli_real_escape_string($conn, $_POST['start']);
	$till = mysqli_real_escape_string($conn, $_POST['till']);

	 

	$sql = "INSERT INTO company(id_user,name, company, position,place,start,till,email,department,passout) VALUES ('$_SESSION[id_user]','$name', '$company', '$position','$place', '$start', '$till','$email','$_SESSION[designation]','$degree')";


	if($conn->query($sql)===TRUE) {
		  header("Location: profile.php");
	} else {
		 header("Location: profile.php");
	}
}