 <?php


 ?>

<aside class="main-sidebar" style="background-color:#2f2424;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" >
      <!-- Sidebar user panel<img src="images/logo2.jpg" align="left" height="150px" width="230px">--> 
      <div class="user-panel">
        <div class="pull-left image">
          <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['profileimage'] != '') {
                    echo '<img src="uploads/profile/'.$row['profileimage'].'" class="img-circle" alt="User Image">';
                  } else {
                    echo '<img src="dist/img/avatar5.png" class="img-circle" alt="User Image">';
                  }
                  $username = $row['name'];
                  $type  = $row['type'];
                }
                ?>
        </div>

        <div class="pull-left info">
          <p><?php echo $username; ?></p>
            <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['online'] == '1') {
                    ?>
                        <a href="index.php?did=<?php echo $_SESSION['id_user']; ?>" ><i class="fa fa-circle text-success"></i> Online</a>
                                       <?php
                      if(isset($_GET['did']))
                      {
                            $sql2 = "UPDATE users SET online='0' WHERE id_user='$_GET[did]'";
                            if($conn->query($sql2) === TRUE) {
                          }
                     }


     

                   

                     } else {
                    ?>
                        <a href="index.php?did=<?php echo $_SESSION['id_user']; ?>" ><i class="fa fa-circle text-danger"></i> Offline</a>
                     
                    <?php
                     if(isset($_GET['did']))
                      {
                            $sql2 = "UPDATE users SET online='1' WHERE id_user='$_GET[did]'";
                            if($conn->query($sql2) === TRUE) {
                          }
                     }
                  }
                 
                }
                ?>
                    

                    
                    
       
        </div>
      </div>
      <!-- sidebar menu  -->
  
      <ul class="sidebar-menu" data-widget="tree" style="background-color:#2f2424;">
  
  <?php
     if( $_SESSION['type']=='admin')
    { 
    ?>
 <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Approve/Reject Request</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu"style="background-color: black">
      
 
              <li <?php if($_SESSION['callFrom'] == "user-profile.php") { echo 'class="active"'; } ?>>
          <a href="user-profile.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Members</span>
          </a>
        </li>
   <li <?php if($_SESSION['callFrom'] == "donation.php") { echo 'class="active"'; } ?>>
          <a href="donation.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Donations</span>
          </a>
        </li>

    </ul>
  </li> 
  
           <li <?php if($_SESSION['callFrom'] == "user-index.php") { echo 'class="active"'; } ?>>
          <a href="user-index.php">
            <i class="fa fa-user-o"></i> <span>POST AS SUPER ADMIN</span>
          </a>
        </li>

<li class="  treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu" style="background-color: black">
       <li <?php if($_SESSION['callFrom'] == "about_us_db.php") { echo 'class="active"'; } ?>>
          <a href="about_us_db.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>About Us</span>
          </a>
        </li>  
 
 <li <?php if($_SESSION['callFrom'] == "appeal_us_db.php") { echo 'class="active"'; } ?>>
          <a href="appeal_us_db.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Apeal</span>
          </a>
        </li>  

        <li <?php if($_SESSION['callFrom'] == "member-add.php") { echo 'class="active"'; } ?>>
          <a href="member-add.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Members
</span>
          </a>
        </li> 
          <li <?php if($_SESSION['callFrom'] == "member-add.php") { echo 'class="active"'; } ?>>
          <a href="add-office-br.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Add Office Bearer
</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "add-conven.php") { echo 'class="active"'; } ?>>
          <a href="add-conven.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Add Convener Committee
</span>
          </a>
        </li>
 <li <?php if($_SESSION['callFrom'] == "con-des.php") { echo 'class="active"'; } ?>>
          <a href="con-des.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Add Convener Info
</span>
          </a>
        </li>




    </ul>
  </li>

 <li class="treeview" >
      <a href="#">
       <i class="fa fa-envelope-o"></i>
        <span>Events</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
             <li <?php if($_SESSION['callFrom'] == "eventadd.php") { echo 'class="active"'; } ?>>
          <a href="eventadd.php">
            <i class="fa fa-search"></i> <span>Event Registration</span>
          </a>
        </li>

          <li <?php if($_SESSION['callFrom'] == "eventreg.php") { echo 'class="active"'; } ?>>
          <a href="eventadd - Copy.php">
            <i class="fa fa-search"></i> <span>ADD Event</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "event_reg_user.php") { echo 'class="active"'; } ?>>
          <a href="event_reg_user.php">
            <i class="fa fa-circle-o text-red"></i> <span>Registerd Users List</span>
          </a>
        </li> 
     
     </ul>
     </li>
 <li class="  treeview" >
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Registered Alumini</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu" style="background-color: black">
   <li <?php if($_SESSION['callFrom'] == "all-users.php") { echo 'class="active"'; } ?>>
          <a href="all-users%20-%20Copy.php">
            <i class="fa fa-users text-yellow"></i> <span>life Member Alumini</span>
          </a>
        </li>
 <li <?php if($_SESSION['callFrom'] == "all1.php") { echo 'class="active"'; } ?>>
          <a href="all1.php">
            <i class="fa fa-users text-yellow"></i> <span>Associative Member Alumini</span>
          </a>
        </li>


    </ul>
  </li>

       

      

<li class="  treeview" style="display:none;">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Login As Normal User</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu" style="background-color: black">
       <li <?php if($_SESSION['callFrom'] == "profile.php") { echo 'class="active"'; } ?>>
          <a href="profile.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Profile</span>
          </a>
        </li>  
        <li <?php if($_SESSION['callFrom'] == "batch.php") { echo 'class="active"'; } ?>>
          <a href="batch.php">
           <i class="fa fa-users text-yellow" aria-hidden="true"></i><span>Batchmates</span>
          </a>
        </li>   
      <!--  <li <?php if($_SESSION['callFrom'] == "index.php") { echo 'class="active"'; } ?>>
          <a href="index.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>ADMIN POST</span>
          </a>
        </li>-->
        <li <?php if($_SESSION['callFrom'] == "messages.php") { echo 'class="active"'; } ?>>
          <a href="messages.php">
            <i class="fa fa-wechat text-yellow"></i> <span>Messages</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "friends.php") { echo 'class="active"'; } ?>>
          <a href="friends.php">
            <i class="fa fa-users text-yellow"></i> <span>Friends</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "all-users.php") { echo 'class="active"'; } ?>>
          <a href="all-users.php">
            <i class="fa fa-users text-yellow"></i> <span>Registered Alumini</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "friend-request.php") { echo 'class="active"'; } ?>>
          <a href="friend-request.php">
            <i class="fa fa-users text-yellow"></i> <span>Friend Requests</span>
          </a>
        </li>

      
     
    <!--    <li <?php if($_SESSION['callFrom'] == "pages.php") { echo 'class="active"'; } ?>>
          <a href="pages.php">
            <i class="fa fa-file-o"></i> <span>Pages</span>
          </a>
        </li>-->
       
        <li style="display:none;"> 
          <a href="photos.php" >
            <i class="fa  fa-file-photo-o text-yellow"></i> <span>Photos</span>
          </a>
        </li>


    </ul>
  </li>



         

       <li <?php if($_SESSION['callFrom'] == "admin-contact.php") { echo 'class="active"'; } ?>>
          <a href="admin-contact.php">
            <i class="fa fa-search"></i> <span>Users-Contacts</span>
          </a>
        </li>

       <!--  <li <?php if($_SESSION['callFrom'] == "pages.php") { echo 'class="active"'; } ?>>
          <a href="pages.php">
            <i class="fa fa-file-o"></i> <span>Pages</span>
          </a>
        </li> -->
           <li <?php if($_SESSION['callFrom'] == "usn.php") { echo 'class="active"'; } ?>>
          <a href="usn.php">
            <i class="fa fa-search"></i> <span>Add/View Department</span>
          </a>
        </li>

               <li <?php if($_SESSION['callFrom'] == "up_don.php") { echo 'class="active"'; } ?>>
          <a href="up_don.php">
            <i class="fa fa-search"></i> <span>Add Donations</span>
          </a>
        </li>

          <li <?php if($_SESSION['callFrom'] == "up_life.php") { echo 'class="active"'; } ?>>
          <a href="up_life.php">
            <i class="fa fa-search"></i> <span>Add Life Member</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "up_asso.php") { echo 'class="active"'; } ?>>
          <a href="up_asso.php">
            <i class="fa fa-search"></i> <span>Add Associative Member</span>
          </a>
        </li>
     
          
        
            <li class="treeview" >
      <a href="#">
       <i class="fa fa-envelope-o"></i>
        <span>Mail</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
           <li <?php if($_SESSION['callFrom'] == "email.php") { echo 'class="active"'; } ?>>
          <a href="email.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Email</span>
          </a>
        </li> 

         <li <?php if($_SESSION['callFrom'] == "csv.php") { echo 'class="active"'; } ?>>
          <a href="csv.php">
            <i class="fa fa-circle-o text-red"></i> <span>ADD Unregistered Contacts</span>
          </a>
        </li> 
     
     
     
     </ul>
      <li <?php if($_SESSION['callFrom'] == "picsframe.php") { echo 'class="active"'; } ?>>
          <a href="picsframe.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>ADD Gallery</span>
          </a>
        </li> 
             <li class="treeview" style="display:none;">
      <a href="#">
       <i class="fa fa-envelope-o"></i>
        <span>Gallery</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
           <li <?php if($_SESSION['callFrom'] == "picsframe.php") { echo 'class="active"'; } ?>>
          <a href="picsframe.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>ADD Gallery</span>
          </a>
        </li> 

         <li <?php if($_SESSION['callFrom'] == "potos1.php") { echo 'class="active"'; } ?>>
          <a href="images.php">
            <i class="fa fa-circle-o text-red"></i> <span>View Gallery</span>
          </a>
        </li> 
     </ul>
     </li>
    <li class="treeview" style="display:none;">
      <a href="#">
       <i class="fa fa-edit"></i>
        <span>Analysis</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
            <li <?php if($_SESSION['callFrom'] == "deptstat.php") { echo 'class="active"'; } ?>>
          <a href="deptstat.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Department Wise</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "passout.php") { echo 'class="active"'; } ?>>
          <a href="passout.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Registered Alumni</span>
          </a>
        </li>
    </li>  
  </ul>
    <li class="treeview">
    <a href="#">
      <i class="fa fa-dashboard"></i> <span>Reports</span> <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu"style="background-color: black">
      
 
              <li <?php if($_SESSION['callFrom'] == "user-profile1.php") { echo 'class="active"'; } ?>>
          <a href="user-profile1.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Export Members</span>
          </a>
        </li>
   <li <?php if($_SESSION['callFrom'] == "donation1.php") { echo 'class="active"'; } ?>>
          <a href="donation1.php">
            <i class="fa fa-circle-o text-yellow"></i> <span>Export Donations</span>
          </a>
        </li>

    </ul>
  </li> 
  
  
  <?php }?>
    <?php
      
    if( $_SESSION['type']=='life_mem')
      {
      ?>
          <li <?php if($_SESSION['callFrom'] == "profile.php") { echo 'class="active"'; } ?>>
          <a href="profile.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Profile</span>
          </a>
        </li> 


         
         <li class="treeview" >
      <a href="#">
       <i class="fa fa-envelope-o"></i>
        <span>Friends</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
               <li <?php if($_SESSION['callFrom'] == "batch.php") { echo 'class="active"'; } ?>>
          <a href="batch.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Batch</span>
          </a>
        </li>
        
            <li <?php if($_SESSION['callFrom'] == "department.php") { echo 'class="active"'; } ?>>
          <a href="department.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Branch</span>
          </a>
        </li>

          <li <?php if($_SESSION['callFrom'] == "friends.php") { echo 'class="active"'; } ?>>
          <a href="friends.php">
            <i class="fa fa-users"></i> <span>Friends</span>
          </a>
        </li>

      
     
     </ul>
  
</li>


          <li <?php if($_SESSION['callFrom'] == "users.php") { echo 'class="active"'; } ?>>
          <a href="all-users.php">
            <i class="fa fa-users"></i> <span>Registered Alumni</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "index.php") { echo 'class="active"'; } ?>>
          <a href="uindex.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>ADMIN POST</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "messages.php") { echo 'class="active"'; } ?>>
          <a href="messages.php">
            <i class="fa fa-wechat"></i> <span>Messages</span>
          </a>
        </li>
      
        <li <?php if($_SESSION['callFrom'] == "friend-request.php") { echo 'class="active"'; } ?>>
          <a href="friend-request.php">
            <i class="fa fa-users"></i> <span>Friend Requests</span>
          </a>
        </li>
          <li <?php if($_SESSION['callFrom'] == "eventadd.php") { echo 'class="active"'; } ?>>
          <a href="eventadd.php">
            <i class="fa fa-search"></i> <span>Event Registration</span>
          </a>
        </li>

         <li <?php if($_SESSION['callFrom'] == "password_update.php") { echo 'class="active"'; } ?>>
          <a href="password_update.php">
            <i class="fa fa-search"></i> <span>Update Password</span>
          </a>
        </li>
      
     <!--  <li <?php if($_SESSION['callFrom'] == "pages.php") { echo 'class="active"'; } ?>>
          <a href="pages.php">
            <i class="fa fa-file-o"></i> <span>Pages</span>
          </a>
        </li> -->
     
        <li style="display:none;">
          <a href="photos.php">
            <i class="fa  fa-file-photo-o"></i> <span>Photos</span>
          </a>
        </li>



       
        
    <?php
  }
  else if($_SESSION['type']=='Associative Member')
  {
 ?>
          <li <?php if($_SESSION['callFrom'] == "profile.php") { echo 'class="active"'; } ?>>
          <a href="profile.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>Profile</span>
          </a>
        </li> 


         
         <li class="treeview" style="display:none;">
      <a href="#">
       <i class="fa fa-envelope-o"></i>
        <span>Friends</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu active"  style="background-color: black"> 
       

     
     
     </ul>
  
</li>
    <li <?php if($_SESSION['callFrom'] == "users.php") { echo 'class="active"'; } ?>>
          <a href="all-users.php">
            <i class="fa fa-users"></i> <span>Registered Alumni</span>
          </a>
        </li>
     <li <?php if($_SESSION['callFrom'] == "friends.php") { echo 'class="active"'; } ?>>
          <a href="friends.php">
            <i class="fa fa-users"></i> <span>Friends</span>
          </a>
        </li>
       <li <?php if($_SESSION['callFrom'] == "eventadd.php") { echo 'class="active"'; } ?>>
          <a href="eventadd.php">
            <i class="fa fa-search"></i> <span>Event Registration</span>
          </a>
        </li>
       
        <li <?php if($_SESSION['callFrom'] == "index.php") { echo 'class="active"'; } ?>>
          <a href="uindex.php">
           <i class="fa fa-users" aria-hidden="true"></i><span>ADMIN POST</span>
          </a>
        </li>
        <li <?php if($_SESSION['callFrom'] == "messages.php") { echo 'class="active"'; } ?>>
          <a href="messages.php">
            <i class="fa fa-wechat"></i> <span>Messages</span>
          </a>
        </li>
      
        <li <?php if($_SESSION['callFrom'] == "friend-request.php") { echo 'class="active"'; } ?>>
          <a href="friend-request.php">
            <i class="fa fa-users"></i> <span>Friend Requests</span>
          </a>
        </li>
   

         <li <?php if($_SESSION['callFrom'] == "password_update.php") { echo 'class="active"'; } ?>>
          <a href="password_update.php">
            <i class="fa fa-search"></i> <span>Update Password</span>
          </a>
        </li>
      
     <!--  <li <?php if($_SESSION['callFrom'] == "pages.php") { echo 'class="active"'; } ?>>
          <a href="pages.php">
            <i class="fa fa-file-o"></i> <span>Pages</span>
          </a>
        </li> -->
     
        <li style="display:none;">
          <a href="photos.php">
            <i class="fa  fa-file-photo-o"></i> <span>Photos</span>
          </a>
        </li>



       
        
    <?php
  }
    ?>
   
       <!--  <li <?php //if($_SESSION['callFrom'] == "log.php") { echo 'class="active"'; } ?> >
          <a href="log.php">
            <i class="fa fa-search"></i> <span>Activity Log</span>
          </a>
        </li>-->


 





     
      <li <?php if($_SESSION['callFrom'] == "groupchat.php") { echo 'class="active"'; } ?>>
          <a href="groupchat.php">
            <i class="fa fa-search"></i> <span>Group Chat</span>
          </a>
        </li>
</ul>

    </section>
    <!-- /.sidebar -->
  </aside>