<style type="text/css">
@media only screen and (min-width: 992px){
/*.container1{
   max-width: 100%;
    margin-left: 0px;
}
#a{
  background-color: rgb(255,255,255);
}*/

.img1 {
    display: inline-block;
    margin-top: -7px;
}
}
@media only screen and (max-width: 992px){
/*.container1{
   max-width: 100%;
    margin-left: 0px;
}
#a{
  background-color: rgb(255,255,255);
}*/

.img1 {
    display: inline-block;
    margin-top: -5px;
}
}

</style>
 <div class="wsmobileheader clearfix ">
  <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>
  <span class="smllogo">
     <img src="img/rsz_gdc1.png" alt="gdc" class="img1"/>
  
  </span>
  <!-- <a href="tel:09480812310" class="callusbtn"><i class="fas fa-phone-alt" aria-hidden="true"></i></a> -->
   
</div>
<!-- Mobile Header -->
<div class="wsmainfull clearfix top-menu">
  <div class="wsmainwp clearfix">
    <div class="desktoplogo" class="img">
      <a href="index.php">
        <div class="content">
          <img src="img/rsz_gdc.png" alt="GOVINDA DAS COLLEGE" width="100%" height="100" style="" class="img1">
              <div class="logo-accreditation">
            <h2></h2>
          </div>
        </div>
      </a>
    </div>


    <!--Main Menu HTML Code-->
      <nav class="wsmenu clearfix">
      <ul class="wsmenu-list main-menu">
        <!-- <li class="home-i"><a href="index.php" title="home"> <i class="fas fa-home"></i></a></li> -->
        
      <li><a href="index.php"> About Us</a></li>
        <li><a href="login.php">Membership</a></li>
        <li><a href="archieves.php"> Archieves</a></li>
                  <li><a href="http://www.govindadasacollege.edu.in"> GDC Home Page</a></li>
  
   
       </ul>
      <ul class="wsmenu-list main-menu-nxt" >
        <li ><a href="#">Contribution<span class="wsarrow"></span></a>
          <div class="wsmegamenu clearfix" id="a" >
          <style type="text/css">
          .container2{
          max-width: 1960px;
    margin-left: 67px;}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}
    </style>
            <div class="container2" style="background-color: rgba(34, 45, 50, 0.8);">
              <div class="row" >
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                       </ul>
                </div>
                 <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">Contribution</li>
                  <li><a href="do1.php"><h3>General Description</h3></a></li>
             <li><a href="do2.php" style="padding-top: 10px;"><h1>Contribute to General Corpus</h1></a></li>
                    <li><a href="do3.php" style="padding-top: 10px;"><h3>Infra and Long Term Project</h3></a></li>
                      <li><a href="do8.php" style="padding-top: 10px;"><h3>Sports and Culturals</h3></a></li>
            
                  </ul>
                </div>
               <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">Contribute to a Cause</li>
                  <li><a href="do4.php"><h3>Sponsor a Student</h3></a></li>
             <li><a href="do5.php"style="padding-top: 10px;"><h1>Mid-Day Meal Program</h1></a></li>
                    <li><a href="do6.php"style="padding-top: 10px;"><h3>Fund for Honoring Achievers</h3></a></li>
                         <li><a href="do7.php"style="padding-top: 10px;"><h3>Contribute to Benevolent Fund</h3></a></li>
               
                  </ul>
                </div>
                
             
              </div>
            </div>
          </div>
        </li>
       
        <li><a href="#">Blogs <span class=""></span></a>
        
        </li>
         <li><a href="contact.php">Contact Us <span class=""></span></a>
          
        </li>
     
       

      </ul>
    </nav>
