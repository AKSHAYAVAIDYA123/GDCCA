<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from caption where id='$id'");
	header('location:add.php');

?>