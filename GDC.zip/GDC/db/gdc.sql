-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2020 at 05:42 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gdc`
--

-- --------------------------------------------------------

--
-- Table structure for table `appeal`
--

CREATE TABLE `appeal` (
  `id` int(11) NOT NULL,
  `appeal` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `type` varchar(255) NOT NULL,
  `id_post` int(11) NOT NULL,
  `id_user` varchar(11) NOT NULL,
  `cap` text NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `file` text NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `status` text NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`type`, `id_post`, `id_user`, `cap`, `description`, `image`, `video`, `file`, `youtube`, `createdAt`, `status`) VALUES
('blog', 78, '17', 'test', 'test', '', '', '', '', '2020-11-15 01:04:21', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` int(11) NOT NULL,
  `cat_name` text NOT NULL,
  `bgcolor` text NOT NULL,
  `color` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `cat_name`, `bgcolor`, `color`) VALUES
(1, 'Association Program photos', 'rgb(29,62,103)', 'white'),
(2, 'Group Photos', 'rgb(29,62,103)', 'white'),
(3, 'Other Photos', 'rgb(29,62,103)', 'white');

-- --------------------------------------------------------

--
-- Table structure for table `caption`
--

CREATE TABLE `caption` (
  `id` int(11) NOT NULL,
  `cap` text NOT NULL,
  `folder` text NOT NULL,
  `test` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caption`
--

INSERT INTO `caption` (`id`, `cap`, `folder`, `test`) VALUES
(7, 'Others Photos', 'admin1/Others/test2/', 'Other Photos'),
(8, 'Association Program photos', 'admin1/Association photo/test2/', 'Association Program photos'),
(9, 'Group Photos', 'admin1/Group Photo/test2/', 'Group Photos');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id_comment`, `id_user`, `id_friend`, `id_post`, `comment`, `createdAt`) VALUES
(38, 43, 43, 18, 'f', '12-06-2020 19:43'),
(39, 17, 17, 21, 'ssd', '26-08-2020 17:25');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Id` int(11) NOT NULL,
  `id_user` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `start` varchar(255) NOT NULL,
  `till` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `passout` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Id`, `id_user`, `name`, `company`, `position`, `place`, `start`, `till`, `email`, `department`, `passout`) VALUES
(2, '43', '', 'Alva\'s Education Trust', 'Lecturer', 'Moodabidre', 'June 2007 ', 'March 2008', 'anantham2004@gmail.com', '', 'MAY.2007'),
(3, '43', '', 'NMAMIT, Nitte', 'Assistant Professor', 'Nitte, Karkala', 'March 2008', 'Today', 'anantham2004@gmail.com', '', 'MAY.2007'),
(4, '52', '', 'SDM INSTITUTE OF TECHNOLOGY, UJIRE', 'ASSISTANT PROFESSOR', 'UJIRE', '20-7-2015', 'TILL NOW', 'spmadavu@gmail.com', '', 'MAY.2014'),
(6, '66', '', 'a', 'v', 'v', 'e', '11', 'test2@gmail.com', '', '1996'),
(7, '65', '', 'a', 'a', '1212', '2020-01-01', 'ww', 'akshayakvaidya@gmail.com', 'MCA', '1992');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `id_user` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `insta` varchar(255) NOT NULL,
  `linkd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `id_user`, `name`, `city`, `degree`, `phone`, `email`, `fb`, `insta`, `linkd`) VALUES
(208, '43', 'Anantha Murthy', 'MCA', 'MAY.2007', '9743702262', 'anantham2004@gmail.com', '', '', ''),
(209, '44', 'Puneeth B R', 'MCA', 'MAY.2009', '', 'sweetpuni@gmail.com', '', '', ''),
(210, '45', 'Spoorthi shetty', 'MCA', 'MAY.2007', '', 'sshetty.07@nitte.edu.in', '', '', ''),
(212, '47', 'Dr.Surendra Shetty', 'MCA', 'MAY.2004', '', 'hsshetty4u@yahoo.com', '', '', ''),
(213, '17', 'admin', 'MCA', '', 'a', 'alumni.association@gmail.com', 'b', 'c', 'e'),
(214, '48', 'test2', 'MCA', 'MAY.2012', '', 'test2@gmail.com', '', '', ''),
(215, '49', 'Jasline Maria Tauro', 'ELC', '', '', 'taurojasline@gmail.com', '', '', ''),
(216, '50', 'Anoop M A', 'IFS', '', '', 'anoopjamadagni@gmail.com', '', '', ''),
(217, '51', 'Suhas Nayak', 'MCA', '', '', 'snsuhasnayak@gmail.com', '', '', ''),
(218, '52', 'Shivaprasad B L', 'MCA', 'MAY.2012', '', 'spmadavu@gmail.com', '', '', ''),
(219, '51', 'Suhas Nayak', 'ELE', 'MAY.2014', '', 'snsuhasnayak@gmail.com', '', '', ''),
(220, '52', 'Shivaprasad B L', 'MMD', 'MAY.2014', '', 'spmadavu@gmail.com', '', '', ''),
(221, '53', 'Karthik Kamath ', 'ELC', 'MAY.2014', '', 'karthikkamaths24@gmail.com', '', '', ''),
(222, '54', 'Yash Khetan', 'MEC', 'MAY.2016', '', 'yashkhetan1994@gmail.com', '', '', ''),
(223, '55', 'AKSHAY', 'MCA', 'MAY.2012', '', 'akshayakvaidya@gmail.com', '', '', ''),
(224, '56', 'akshay', '', '', '', 's@gmail.com', '', '', ''),
(225, '57', 'akshay', '', '', '', 's1@gmail.com', '', '', ''),
(226, '58', 'putta', '', '', '', 'putta@gmail.com', '', '', ''),
(227, '59', 'akshay', '', '', '', 'akshayakvaidya@gmail.com', '', '', ''),
(228, '60', 'savitha', 'Ph.D', '', '', 'sshe1tty.07@nitte.edu.in', '', '', ''),
(229, '61', 'akshay', 'MBA', '2001', '', 'akshayakvaidya123@gmail.com', '', '', ''),
(230, '62', 'XYZ', 'Construction Technology', '2003', '', 'xyz@gmail.com', '', '', ''),
(231, '63', 'putta1', 'Computer & Communication Engineering', '2002', '', 'putta1@gmail.com', '', '', ''),
(232, '64', 'super_user', 'Ph.D', '2000', '', '1admin@gmail.com', '', '', ''),
(233, '65', 'akshay', 'MCA', '1998', '', 'akshayakvaidya@gmail.com', '', '', ''),
(234, '66', 'test', 'MCA', '1996', '9740769579', 'test2@gmail.com', '', 'b', 'c'),
(235, '67', 'test3', 'Energy Systems Engineering', '2019', '', 'test3@gmail.com', '', '', ''),
(236, '68', 'putta', 'Mechanical Engineering', '1996', '', 'putta@gmail.com', '', '', ''),
(237, '69', 'test4', 'Ph.D', '1996', '', 'test34@gmail.com', '', '', ''),
(238, '78', 'test2', '', '', '', 'test2@gmail.com', '', '', ''),
(239, '79', 'test2', '', '', '', 'test2@gmail.com', '', '', ''),
(240, '80', 'test21221', '', '', '', 'test21221@gmail.com', '', '', ''),
(241, '81', 'test21221', '', '', '', 'test21221@gmail.com', '', '', ''),
(242, '82', 'test67', 'MCA', '1998', '', 'test67@gmail.com', '', '', ''),
(243, '83', 'akshay', ' M.Com', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(244, '84', 'test22222', 'MCA', '', '', 'test22222@gmail.com', '', '', ''),
(245, '85', 'test22222', 'MCA', '', '', 'test22222@gmail.com', '', '', ''),
(246, '86', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(247, '87', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(248, '88', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(249, '89', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(250, '92', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(251, '93', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(252, '94', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(253, '95', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(254, '96', 'M Ramesh Rao', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(255, '97', 'putta', 'MCA', '', '', 'putta1@gmail.com', '', '', ''),
(256, '98', 'Aks', ' M.Com', '1996', '', 'aks@gmail.com', '', '', ''),
(257, '99', 'akshay', ' M.Com', '1996', '', 'test21223@gmail.com', '', '', ''),
(258, '100', 'putta', 'MCA', '', '', '112admin@gmail.com', '', '', ''),
(259, '101', 'putta', 'MCA', '', '', 'dmin@gmail.com', '', '', ''),
(260, '102', 'putta', 'MCA', '', '', 'putta420@gmail.com', '', '', ''),
(261, '103', 'putta', 'MCA', '', '', 'putta421@gmail.com', '', '', ''),
(262, '104', 'putta100000', 'MCA', '', '', 'putta100000@gmail.com', '', '', ''),
(263, '105', 'putta12', 'MCA', '', '', 'putta42145@gmail.com', '', '', ''),
(264, '106', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(265, '107', 'putta12', 'MCA', '', '', 'putta42145@gmail.com', '', '', ''),
(266, '108', 'putta', 'MCA', '', '', 'admin1@gmail.com', '', '', ''),
(267, '109', 'putta12', 'MCA', '', '', 'putta1@gmail.com', '', '', ''),
(268, '110', 'putta', 'sfd', '', '', 'akshayakvaidya@gmail.com', '', '', ''),
(269, '17', 'admin', 'MCA', '1996', '', 'alumni.association@gmail.com', '', '', ''),
(270, '65', 'akshay', 'MCA', '', '', 'akshayakvaidya@gmail.com', '', '', ''),
(271, '82', 'test67', 'MCA', '1998', '', 'test67@gmail.com', '', '', ''),
(272, '83', 'akshay', ' M.Com', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(273, '96', 'M Ramesh Rao', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(274, '97', 'putta', 'MCA', '', '', 'putta1@gmail.com', '', '', ''),
(275, '98', 'Aks', ' M.Com', '1996', '', 'aks@gmail.com', '', '', ''),
(276, '99', 'akshay', ' M.Com', '1996', '', 'test21223@gmail.com', '', '', ''),
(277, '100', 'putta', 'MCA', '', '', '112admin@gmail.com', '', '', ''),
(278, '101', 'putta', 'MCA', '', '', 'dmin@gmail.com', '', '', ''),
(279, '102', 'putta', 'MCA', '', '', 'putta420@gmail.com', '', '', ''),
(280, '103', 'putta', 'MCA', '', '', 'putta421@gmail.com', '', '', ''),
(281, '104', 'putta100000', 'MCA', '', '', 'putta100000@gmail.com', '', '', ''),
(282, '105', 'putta12', 'MCA', '', '', 'putta42145@gmail.com', '', '', ''),
(283, '111', 'akshay1', 'MCA', '', '', 'akshay1@gmail.com', '', '', ''),
(284, '112', 'akshay', 'BBA', '2012', '', 'admin1212@gmail.com', '', '', ''),
(285, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(286, '114', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(287, '115', 'name', 'city', 'degree', '', 'email', '', '', ''),
(288, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(289, '116', '', '', '', '', '', '', '', ''),
(290, '117', '', '', '', '', '', '', '', ''),
(291, '118', 'name', 'city', 'degree', '', 'email', '', '', ''),
(292, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(293, '119', '', '', '', '', '', '', '', ''),
(294, '120', '', '', '', '', '', '', '', ''),
(295, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(296, '121', '', '', '', '', '', '', '', ''),
(297, '122', '', '', '', '', '', '', '', ''),
(298, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(299, '125', 'name', 'city', '', '', 'email', '', '', ''),
(300, '114', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(301, '126', '1', '6', '', '', '2', '', '', ''),
(302, '127', 'name', 'phone', 'city', '', 'email', '', '', ''),
(303, '114', 'putta', '1234567890', 'MCA', '', 'putta@gmail.com', '', '', ''),
(304, '128', 'Akshay', 'BSC', '1996', '', 'akshayakvaidya1@gmail.com', '', '', ''),
(305, '129', 'akshay', 'BCOM', '1996', '', 'akshayakvaidya2@gmail.com', '', '', ''),
(306, '130', 'akshay', '113', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(307, '131', 'akshay', 'BBA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(308, '132', 'akshay', 'BBA', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(309, '133', 'akshay', 'BA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(310, '134', 'akshay', 'BCOM', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(311, '135', 'akshay', 'BBA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(312, '136', 'akshay', 'BA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(313, '137', 'akshay', 'BBA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(314, '138', 'akshay', 'BCA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(315, '139', 'akshay', 'BA', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(316, '140', 'akshay', 'BCA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(317, '141', 'akshay', 'BSC', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(318, '142', 'akshay', 'BA', '1996', '', 'akshayakvaidya1@gmail.com', '', '', ''),
(319, '143', 'Santhosh', '113', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(320, '144', 'AK', 'BA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(321, '1', '', 'BA', '1986', '1234567890', 'akshayakvaidya1@gmail.com', 'sf', 'wf`', 'fef'),
(322, '2', 'M Ramesh Rao', 'BCOM', '1976', '', 'avaidya769579@GMAIL.COM', '', '', ''),
(323, '3', 'Guruprasad K', 'BCOM', '2000', '', 'anantham2004@gmail.com', '', '', ''),
(324, '4', 'B Ramdas Nayak', 'BCOM', '1971', '', 'anantham2004@nitte.edu.in', '', '', ''),
(325, '5', 'Dr. Sayeegeetha', 'BA', '1987', '', 'anantham2021@gmail.com', '', '', ''),
(326, '145', 'test', 'BBA', '', '', 'avaidya76957@gmail.com', '', '', ''),
(327, '146', 'AK', 'BCOM', '2000', '', 'akshayakvaidya@gmail.com', '', '', ''),
(328, '147', 'test1', '', '', '', 'test15@gmail.com', '', '', ''),
(329, '148', 'system_admin', 'BCOM', '1996', '', 'sys_admin@gmail.com', '', '', ''),
(330, '149', 'test', '', '', '', 'tes1t@gmail.com', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id` int(11) NOT NULL,
  `Position` text NOT NULL,
  `type` text NOT NULL,
  `url` text NOT NULL,
  `name` text NOT NULL,
  `email_id` text NOT NULL,
  `phone` text NOT NULL,
  `order1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`id`, `Position`, `type`, `url`, `name`, `email_id`, `phone`, `order1`) VALUES
(16, 'President\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'M.Ramesh Rao', 'akshayakvaidya@gmail.com', '9740769579', 3),
(17, 'Vice - President\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'Dr. Sayeegeetha\r\n', 'akshayakvaidya@gmail.com', '9740769579', 4),
(18, 'Secretary\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'CA Guruprasad K\r\n', 'akshayakvaidya@gmail.com', '9740769579', 5),
(19, 'Joint - Secretary\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'Leeladhara B Shetty\r\n', 'akshayakvaidya@gmail.com', '9740769579', 6),
(22, 'member', 'Member', '5f57b5464a91b.jpg', 'UDAYABHASKAR Y V\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(23, 'member', 'Member', '5f57b5464a91b.jpg', 'Dr. Suprabha K. R\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(24, 'member', 'Member', '5f57b5464a91b.jpg', 'VEENA T SHETTY\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(25, 'member', 'Member', '5f57b5464a91b.jpg', 'Dr. S. Gunakar\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(26, 'member', 'Member', '5f57b5464a91b.jpg', 'P. Madhava Suvarna\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(27, 'member', 'Member', '5f57b5464a91b.jpg', 'Sathish Surathkal\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(28, 'member', 'Member', '5f57b5464a91b.jpg', 'Smt Mani M Rai\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(29, 'member', 'Member', '5f57b5464a91b.jpg', 'Smt Lekha Jayekar\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(30, 'member', 'Member', '5f57b5464a91b.jpg', 'Vinod Shetty\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(31, 'member', 'Member', '5f57b5464a91b.jpg', 'Ms Priya Nayak\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(32, 'member', 'Member', '5f57b5464a91b.jpg', 'Venugopal Shenoy\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(33, 'member', 'Member', '5f57b5464a91b.jpg', 'Canute Jeevan Pinto\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(39, 'test', 'Office Bearers', 'IMG-20200819-WA0030.jpg', 'test', 'test', 'test', 2),
(40, 'test', 'Office Bearers', 'Mw.png', 'test', 'akshayakvaidya@gmail.com', 'test', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contribute to general corpus`
--

CREATE TABLE `contribute to general corpus` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contribute to general corpus`
--

INSERT INTO `contribute to general corpus` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `conven`
--

CREATE TABLE `conven` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `place` text NOT NULL,
  `phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conven`
--

INSERT INTO `conven` (`id`, `name`, `place`, `phone`) VALUES
(2, 'Akshay', 'byndoor', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `convenners_description`
--

CREATE TABLE `convenners_description` (
  `id` int(11) NOT NULL,
  `des` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `convenners_description`
--

INSERT INTO `convenners_description` (`id`, `des`) VALUES
(3, '   As per the discussion and decision taken in the GDCAA Governing Council Meeting held on 29.08.2020 the Convener Committee consisting of following GDC Alumni has been formed. The main purpose of the committee is to oversee the Membership Drive and enrollment of members to GDCAA. The committee will also coordinate and take active participation in mobilizing the funds for various activities and also give suggestions in formulating the plan for conducting the activities like Skill Training Programme for students, conducting Anniversary Programme, sports and cultural activities for GDCAA members.');

-- --------------------------------------------------------

--
-- Table structure for table `dashboard`
--

CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL,
  `about_us` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dashboard`
--

INSERT INTO `dashboard` (`id`, `about_us`) VALUES
(1, 'Govinda Dasa College Alumni Association (R), (GDCAA) is a non-profit organization formed in the year of 2019 and registered under Karnataka Societies Registration Act, 1960. GDCAA provides a lifelong bridge between Govinda Dasa College, Surathkal and its Alumnus\'. Association Members are ex-students of Govinda Dasa College, Surathkal(http://www.govindadasacollege.edu.in/) who had studied for one or more academic year in the institution.'),
(2, ''),
(3, 'Objectives'),
(4, '1.Provide a common platform for all the ex-students to come together and share their rich experiences in various fields with each other, with present staff and students of the college.'),
(5, '2.Provide opportunity to exhibit alumni expertise and talents in Intellectual, Academic, Cultural &sports through various programs in these areas and inspire such talents amongst present students;'),
(6, '3. Promote scholarship and welfare schemes for deserving students, undertake developmental activities for the college, students and to the society'),
(7, ''),
(8, 'Alumni Outreach'),
(9, 'This is a Pursuit of bringing together all the alumnus’ of Govinda Dasa College under one umbrella has begun. Let’s come together and contribute something valuable to the Institution that has shaped our lives to a considerable extent. More importantly let us take it as an opportunity to show our patronage to the present generation of students who are occupying our benches where we used to sit long back.');

-- --------------------------------------------------------

--
-- Table structure for table `donation_info`
--

CREATE TABLE `donation_info` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` int(20) NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL,
  `ap` int(11) NOT NULL DEFAULT 0,
  `lock_bt` int(11) NOT NULL DEFAULT 0,
  `updated_at` text NOT NULL,
  `rcn` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_info`
--

INSERT INTO `donation_info` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`, `ap`, `lock_bt`, `updated_at`, `rcn`) VALUES
(185, 'online', 'General Purpose', 2000, 'YES', '', 'Balakrishna Narayana Suvarna', 'NEFT-PADUBIDRI CO OPERATIVE AGR/BCBMH20188536641', 0, 1, '7-Jul-20', '10'),
(186, 'online', 'General Purpose', 2000, 'YES', '', 'P Somshekar Rao', 'IMPS/P2A-018919939720-P SOMASHEKAR RAO-9025000944', 0, 1, '7-Jul-20', '11'),
(187, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Yashvanth S Puthran', 'MClick/by YASHVANTH SUBBAYA PU/Membership/4993111', 0, 1, '23-Jul-20', '13'),
(188, 'online', 'Sponsor a Student', 10000, 'YES', '', 'H Venugopal Shenoy', 'IMPS/P2A-021421805605-H VENUGOPAL  SHENOY-9025334', 0, 1, '1-Aug-20', '9'),
(189, 'online', 'General Purpose', 20000, 'YES', '', 'Yashvanth S Puthran', 'MClick/by YASHVANTH SUBBAYA PU/Donation/5924591/0', 0, 1, '1-Aug-20', '12'),
(190, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Srikanth Hosabettu', 'NEFT-ASHWITA SHRIKANT HOSBETU/N215201202272235', 0, 1, '2-Aug-20', '15'),
(191, 'online', 'Sponsor a Student', 50000, 'YES', '', 'Badruddin Panambur', 'IMPS/P2A-021622498668-BADRUDDIN PANAMBUR-97570009', 0, 1, '3-Aug-20', '2'),
(192, 'online', 'Sponsor a Student', 25000, 'YES', '', 'Ravi Karkera', 'NEFT-RAVINDRANATH LILADHAR KARK/N216201203523682', 0, 1, '3-Aug-20', '3'),
(193, 'online', 'Sponsor a Student', 20000, 'YES', '', 'Jayakar karkera', 'By Cash JAYAKAR', 0, 1, '3-Aug-20', '8'),
(194, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Satish M. Shetty-Perara ', 'UPI:021608037820:7021733653@ybl(AKSHAY SATISH SHE', 0, 1, '3-Aug-20', '14'),
(195, 'online', 'Sponsor a Student', 10000, 'YES', '', 'K Govinda Das, Kuthethur', 'BY CLG/139603/BCB/003510500002880/', 0, 1, '4-Aug-20', '6'),
(196, 'online', 'General Purpose', 40000, 'YES', '', 'K Govinda Das, Kuthethur', 'BY CLG/139603/BCB/003510500002880/', 0, 1, '4-Aug-20', '7'),
(197, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Ramesh Kulai', 'BY CHQ RAMESH K', 0, 1, '6-Aug-20', '5'),
(198, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Shashidhar N. Karkera ', 'IMPS/P2A-022114125059-SHASHIDHAR NARSIMHA-9229273', 0, 1, '8-Aug-20', '1'),
(199, 'online', 'Sponsor a Student', 10500, 'YES', '', 'Sumithra R Kundar', 'NEFT-SUMITRA R KUNDAR/N223201210554945', 0, 1, '10-Aug-20', '16'),
(200, 'online', 'Sponsor a Student', 25000, 'YES', '', 'Thukaram Shriyan', 'BY CLG/019519/VJB/108701012000011/', 0, 1, '18-Aug-20', '4'),
(201, 'online', 'Sponsor a Student', 50000, 'YES', '', 'Prof. RAMESH BHAT S G', 'BY RAMESH BHAT S G', 0, 1, '7-Sep-20', '17'),
(202, 'online', 'Sponsor a Student', 20000, 'YES', '', 'Deepa Shetty', 'BY RAMESH BHAT S G', 0, 1, '7-Sep-20', '18'),
(203, 'online', 'Sponsor a Student', 30000, 'YES', '', 'Prof. Harish Acharya', 'BY CLG/88984/VJB/2015171269/', 0, 1, '9-Sep-20', '19'),
(204, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Prof. B.Y.Kumar', 'BY CLG/654329/SBI/20150171394/', 0, 1, '10-Sep-20', '20'),
(205, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Vishwanath B Puthran', 'NEFT-Mr. VISHWANATH B PUTHRAN/CBINH20258397159', 0, 1, '14-Sep-20', '21'),
(206, 'online', 'Sponsor a Student', 10000, 'YES', '', 'Harish Suratkal', 'NEFT-HARISH SURATKAL/000200207518', 0, 1, '17-Sep-20', '22'),
(207, 'online', 'General Purpose', 10000, 'NO', '', 'Srikanth Hosabettu', 'NEFT-ASHWITA SHRIKANT HOSBETU/N279201265332959', 0, 1, '6-Oct-20', '23'),
(208, 'online', 'Cultural & Sports', 2000, 'YES', '', 'Govinda Kamath', 'IMPS/P2A-028723782561-Mr  GANESH GOVIND KA-900200', 0, 1, '13-Oct-20', '29'),
(209, 'online', 'Cultural & Sports', 2000, 'YES', '', 'BALAKRISHNA SANIL', 'NEFT-BALAKRISHNA SANIL/AXIR202920524710', 0, 1, '18-Oct-20', '28'),
(210, 'online', 'Cultural & Sports', 2000, 'YES', '', 'KAMALAKSHA L KUNDER', 'IMPS/P2A-029622271822-KAMALAKSHA L KUNDER-9017000', 0, 1, '22-Oct-20', '27'),
(211, 'online', 'Cultural & Sports', 2000, 'YES', '', 'Leela Amrith', 'IMPS/P2A-029712288121-LEELA AMRITH-9017000948-CRB', 0, 1, '23-Oct-20', '26'),
(212, 'online', 'Cultural & Sports', 3000, 'YES', '', 'Ravi Karkera', 'NEFT-RAVINDRANATH LILADHAR KARK/N298201285456916', 0, 1, '24-Oct-20', '24'),
(213, 'online', 'Cultural & Sports', 2000, 'YES', '', 'Bhaskar Shenoy', 'UPI:029805777185:9632970767@ybl(SANJEEV  KUMAR B', 0, 1, '24-Oct-20', '25'),
(214, 'online', 'Sponsor a Student', 10000, 'YES', '', 'UDAYABHASKAR Y V', 'IMPS/P2A-030908773493-UDAYA BHASKAR Y V-900200091', 0, 1, '4-Nov-20', '30'),
(215, 'online', 'Sponsor a Student', 10000, 'YES', '', 'KUMUDA NAGESH MENDON', 'NEFT-KUMUDA NAGESH MENDON/BARBT20309273369', 0, 1, '4-Nov-20', '32'),
(216, 'online', 'Cultural & Sports', 1000, 'YES', '', 'UDAYABHASKAR Y V', 'IMPS/P2A-030908773493-UDAYA BHASKAR Y V-900200091', 0, 1, '4-Nov-20', '31');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id_event` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ename` varchar(255) NOT NULL,
  `conduct` varchar(255) NOT NULL,
  `dat` date NOT NULL,
  `addr` text NOT NULL,
  `info` time NOT NULL,
  `uploader` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id_event`, `id_user`, `ename`, `conduct`, `dat`, `addr`, `info`, `uploader`, `notice`) VALUES
(138, 17, 'test', 'test', '0000-00-00', 'test', '21:35:00', '', 'uploads/sample.pdf'),
(139, 17, 'test', 'test', '2020-11-13', 'sdd', '01:00:00', '', 'uploads/sample.pdf'),
(140, 17, 'test', 'test', '2020-11-13', 'test', '23:19:00', '', 'uploads/sample.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `events1`
--

CREATE TABLE `events1` (
  `id_event` int(11) NOT NULL,
  `id_user` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_calendar`
--

CREATE TABLE `event_calendar` (
  `id_calendar` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `bgColor` varchar(255) NOT NULL,
  `borderColor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_reg_user`
--

CREATE TABLE `event_reg_user` (
  `id_reg_user` int(11) NOT NULL,
  `id_event` text NOT NULL,
  `id_user` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_reg_user`
--

INSERT INTO `event_reg_user` (`id_reg_user`, `id_event`, `id_user`, `name`) VALUES
(10, '3', '17', 'admin'),
(11, '2', '17', 'admin'),
(13, '4', '17', 'admin'),
(14, '5', '17', 'admin'),
(15, '4', '46', 'test'),
(16, '5', '46', 'test'),
(17, '4', '43', 'Anantha Murthy'),
(19, '127', '17', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `friendrequest`
--

CREATE TABLE `friendrequest` (
  `id_friendrequest` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `viewed` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendrequest`
--

INSERT INTO `friendrequest` (`id_friendrequest`, `id_user`, `id_friend`, `purpose`, `viewed`) VALUES
(1, 44, 43, 'Hi Puneeth', 0),
(2, 47, 43, 'Hi Sir', 0),
(3, 55, 17, 'send', 0);

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id_friend` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_frienduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id_friend`, `id_user`, `id_frienduser`) VALUES
(17, 45, 43),
(18, 43, 45),
(19, 17, 46),
(20, 46, 17),
(21, 55, 43),
(22, 43, 55),
(23, 17, 66),
(24, 66, 17),
(25, 17, 65),
(26, 65, 17),
(29, 143, 142),
(30, 142, 143),
(31, 146, 3),
(32, 3, 146),
(33, 3, 2),
(34, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `friends_comments`
--

CREATE TABLE `friends_comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends_comments`
--

INSERT INTO `friends_comments` (`id_comment`, `id_user`, `id_friend`, `id_post`, `comment`, `createdAt`) VALUES
(1, 66, 66, 2, 'dgdg', '13-08-2020 17:12:28'),
(2, 146, 146, 5, 'fgfg', '09-11-2020 18:44:38'),
(3, 3, 3, 6, 'rhrhrttr', '09-11-2020 18:56:46');

-- --------------------------------------------------------

--
-- Table structure for table `friend_posts`
--

CREATE TABLE `friend_posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friend_posts`
--

INSERT INTO `friend_posts` (`id_post`, `id_user`, `id_friend`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
(1, 43, 45, 'hello friend ', '', '', '', '15-01-2020 12:56:47'),
(3, 66, 0, '', '5f3527031091b.png', '', '', '13-08-2020 17:11:55'),
(4, 66, 0, '', '5f352713b636b.png', '', '', '13-08-2020 17:12:11'),
(6, 3, 2, 'ehehhthte\r\n', '', '', '', '09-11-2020 18:56:39'),
(14, 3, 0, 'werewrwerwer', '', '', '', '09-11-2020 20:49:25'),
(17, 3, 0, 'fvg', '', '', '', '09-11-2020 20:49:58'),
(20, 3, 0, 'ty', '', '', '', '09-11-2020 20:50:22');

-- --------------------------------------------------------

--
-- Table structure for table `fund for honoring achievers`
--

CREATE TABLE `fund for honoring achievers` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fund for honoring achievers`
--

INSERT INTO `fund for honoring achievers` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `caption` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `infra`
--

CREATE TABLE `infra` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infra`
--

INSERT INTO `infra` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id_likes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `s` varchar(255) NOT NULL,
  `id_message` int(11) NOT NULL,
  `id_from` int(11) NOT NULL,
  `id_to` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `viewed` int(11) NOT NULL,
  `createdAt` text NOT NULL,
  `Rohan` int(11) NOT NULL DEFAULT 1,
  `Se` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`s`, `id_message`, `id_from`, `id_to`, `message`, `viewed`, `createdAt`, `Rohan`, `Se`) VALUES
('', 1, 43, 45, 'hi', 0, '11-01-2020 08:58:17', 1, 1),
('', 2, 46, 17, 'ds', 1, '11-01-2020 09:56:37', 0, 1),
('', 3, 17, 46, '1', 1, '11-01-2020 19:32:15', 0, 0),
('', 4, 17, 46, '2', 1, '11-01-2020 19:32:16', 1, 0),
('', 5, 17, 46, '3', 1, '11-01-2020 19:32:17', 1, 0),
('', 6, 17, 46, '4', 1, '11-01-2020 19:32:17', 1, 1),
('', 7, 17, 46, '5', 1, '11-01-2020 19:32:18', 1, 1),
('', 8, 43, 45, 'y not replying', 0, '13-01-2020 15:51:04', 1, 1),
('', 10, 66, 17, 'test', 1, '13-08-2020 16:49:15', 0, 1),
('', 11, 65, 17, 'hi', 1, '08-09-2020 22:19:41', 1, 1),
('', 12, 142, 143, 'eghjjhgfds', 0, '01-11-2020 12:42:03', 1, 1),
('', 13, 142, 143, 'sdfghj', 0, '01-11-2020 12:42:05', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mid-day meal program_info`
--

CREATE TABLE `mid-day meal program_info` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mid-day meal program_info`
--

INSERT INTO `mid-day meal program_info` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `notice_id` int(11) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `subject` text NOT NULL,
  `notices` varchar(50) NOT NULL,
  `Date` datetime NOT NULL,
  `ex_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`notice_id`, `branch`, `subject`, `notices`, `Date`, `ex_date`) VALUES
(3, 'ALL Branch', 'test', '20170722135325_IMG_9259.JPG', '2020-06-11 20:17:37', '2020-06-30');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id_page` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `vmode` varchar(255) NOT NULL DEFAULT 'Public',
  `pmode` varchar(255) NOT NULL DEFAULT 'Public'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_comments`
--

CREATE TABLE `page_comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_followers`
--

CREATE TABLE `page_followers` (
  `id_follower` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_likes`
--

CREATE TABLE `page_likes` (
  `id_likes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_posts`
--

CREATE TABLE `page_posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `Contribute to General Corpus` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `Contribute to General Corpus`) VALUES
(1, 'Govinda Dasa College (GDC), Surathkal started in 1967 has become one of the premier institution in and around Surathkal by providing quality education in Science, Commerce & management and Arts stream through graduate and post graduate courses. Over the years, its growth and development has been bolstered by contributions from alumni, philanthropists and well-wishers. As it forges ahead in the 21st century, after successfully completing 50 years of its formation, GDC aims to expand further in its academic pursuits and infrastructure, in order to be one of the best college in the Nation.\r\n\r\nWe alumni’sneed to partner with College in its development path. Request all the alumni’s, Donorsto contribute generously to GDCAA’s General Corpus and become a valuable partner. Your contributions will greatly help sustain Associations finances for discretionary expenditures to various activities.\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `type` varchar(255) NOT NULL,
  `id_post` int(11) NOT NULL,
  `id_user` varchar(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`type`, `id_post`, `id_user`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
('frien', 18, '43', 'Test', '', '', '', '12-06-2020 08:07:37'),
('frien', 23, '66', 'asas', '', '', '', '13-08-2020 15:59:02'),
('admin', 24, '17', 'admin', '', '', '', ''),
('admin', 25, '17', 'test', '', '', '', ''),
('admin', 26, '17', '', '5f59c688792d9.jpg', '', '', ''),
('admin', 27, '17', 'asass', '', '', '', ''),
('frien', 30, '146', 'ff', '', '', '', '09-11-2020 18:34:44'),
('admin', 31, '17', 'https://www.youtube.com/watch?v=0-Df0eb00sI', '', '', '0-Df0eb00sI', ''),
('admin', 32, '17', 'https://www.youtube.com/watch?v=0-Df0eb00sI', '', '', '0-Df0eb00sI', ''),
('admin', 33, '17', 'rfwetret\r\n\r\nhttps://www.youtube.com/watch?v=0-Df0eb00sI', '', '', '0-Df0eb00sI', '');

-- --------------------------------------------------------

--
-- Table structure for table `publicpost`
--

CREATE TABLE `publicpost` (
  `type` varchar(255) NOT NULL DEFAULT 'admin',
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purpose`
--

CREATE TABLE `purpose` (
  `id` int(11) NOT NULL,
  `purpose` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purpose`
--

INSERT INTO `purpose` (`id`, `purpose`) VALUES
(1, 'Contribute to General Corpus'),
(2, 'Sponsor a Student'),
(3, 'Mid-Day Meal Program'),
(4, 'Fund for Honoring Achievers'),
(5, 'Contribute to Benevolent Fund'),
(6, 'Infra / Long Term Projects'),
(7, 'Sports and Culturals');

-- --------------------------------------------------------

--
-- Table structure for table `sponsor a student`
--

CREATE TABLE `sponsor a student` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sponsor a student`
--

INSERT INTO `sponsor a student` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `gend` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unregister`
--

CREATE TABLE `unregister` (
  `type` varchar(255) NOT NULL DEFAULT 'user',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name1` text NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unregister`
--

INSERT INTO `unregister` (`type`, `name`, `email`, `name1`, `msg`) VALUES
('user', 'akshaya', 'akshayakvaidya@gmail.com', 'Welcome', 'Welcome\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `type` varchar(10) NOT NULL DEFAULT 'user',
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL,
  `DOB` varchar(255) NOT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `aboutme` text DEFAULT NULL,
  `profileimage` varchar(255) DEFAULT NULL,
  `online` int(11) NOT NULL DEFAULT 0,
  `name1` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `tran_id` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `mode_pay` varchar(255) NOT NULL,
  `current_qualification` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'life_mem',
  `ass_work_status` text NOT NULL,
  `retire` text NOT NULL,
  `flag` int(11) NOT NULL DEFAULT 0,
  `lock_act` text NOT NULL DEFAULT '1',
  `recp_no` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`type`, `id_user`, `name`, `email`, `password`, `createdAt`, `address`, `DOB`, `degree`, `university`, `city`, `skills`, `aboutme`, `profileimage`, `online`, `name1`, `msg`, `tran_id`, `phone`, `status`, `mode_pay`, `current_qualification`, `user_type`, `ass_work_status`, `retire`, `flag`, `lock_act`, `recp_no`) VALUES
('user', 1, 'Krishna moorthy P', 'akshayakvaidya1@gmail.com', '10001', '2020-11-06 16:13:19', 'Govindadasa college surathkal , ,Suratkal -575014', '1-Jan-65', '1986', NULL, 'BA', NULL, NULL, NULL, 1, 'test', 'email', '10001', '9480347065', '', 'Cash', 'MA Mphil', 'life_mem', '', '', 1, '0', '10001'),
('user', 2, 'M Ramesh Rao', 'avaidya769579@GMAIL.COM', '10002', '2020-11-06 16:13:19', 'Anagha, 8-8/2 (20) ,Lord Krishna Estate, Katla Iddya ,Suratkal -575014', '1-Apr-54', '1976', NULL, 'BCOM', NULL, NULL, NULL, 0, 'test', 'email', '10002', '9481916741', '', 'Cash', 'BCOM', 'Associative Member', '', '', 1, '0', '10002'),
('user', 3, 'Guruprasad K', 'anantham2004@gmail.com', '10003', '2020-11-06 16:13:19', '8-49, Murukundi House, Krishnapura Cross Road ,Iddya Village ,Suratkal -575014', '25-Dec-79', '2000', NULL, 'BCOM', NULL, NULL, NULL, 0, 'test', 'email', '10003', '7760979310', '', 'Cash', 'CA', 'life_mem', '', '', 1, '0', '10003'),
('user', 4, 'B Ramdas Nayak', 'anantham2004@nitte.edu.in', '10004', '2020-11-06 16:13:19', 'Kedar, House No. 6/59 ,Kodical Main Road ,Kodical, Mangalore -575006', '10-Sep-49', '2000', NULL, 'BCOM', NULL, NULL, NULL, 0, 'test', 'email', '10004', '9740547999', '', 'Cheque', 'BCOM', 'life_mem', '', '', 1, '0', '10004'),
('user', 5, 'Dr. Sayeegeetha', 'anantham2021@gmail.com', '10005', '2020-11-06 16:13:19', 'Sanjeevini, Site no. 606 ,Chelaru Via Haleangadi ,Mangalore -574146', '16-Oct-66', '1987', NULL, 'BA', NULL, NULL, NULL, 0, 'test', 'email', '10005', '9448931212', '', 'Cheque', 'MA. Ph.D', 'life_mem', '', '', 1, '0', '10005'),
('admin', 17, 'admin', 'alumni.association@gmail.com', 'admin', '2019-11-01 04:31:26', 'admin', '', '1996', 'Nitte', 'MCA', 'CSS', '', NULL, 1, 'test', 'email', '481986', '', '0', '', '', 'admin', '', '0', 1, '0', ''),
('user', 145, 'test', 'avaidya76957@gmail.com', '1234', '2020-11-08 10:51:10', 'wwd', '0001-01-01', '', NULL, 'BBA', NULL, NULL, NULL, 0, '', '', '', '1234567890', '', '', '', 'life_mem', 'work', '', 0, '1', ''),
('user', 146, 'AK', 'akshayakvaidya@gmail.com', '1234', '2020-11-09 12:58:48', 'Address', '2020-11-25', '2000', NULL, 'BCOM', NULL, NULL, NULL, 0, 'AK', '', '', '9740769579', '', 'Check Payment', 'BCOM', 'life_mem', '', '', 1, '0', 'AAAAAAAAA'),
('admin', 147, 'test1', 'test15@gmail.com', '12345', '2020-11-12 09:53:34', '', '', '', NULL, '', NULL, NULL, NULL, 0, '', '', '', '', '', '', '', 'Media_admin', '', '', 1, '0', ''),
('admin', 148, 'system_admin', 'sys_admin@gmail.com', 'admin', '2019-11-01 04:31:26', 'admin', '', '1996', 'GDC', 'BCOM', 'CSS', '', NULL, 0, 'test', 'email', '481986', '', '0', '', '', 'main_admin', '', '0', 1, '0', '');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `insert` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO contact(id_user,name,email,city,degree)VALUES(NEW.id_user,NEW.name,NEW.email,NEW.city,NEW.degree)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update1` AFTER UPDATE ON `users` FOR EACH ROW UPDATE contact set contact.name=NEW.name,contact.email=NEW.email WHERE contact.id_user=old.id_user
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_followers`
--

CREATE TABLE `user_followers` (
  `id_follower` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_userfollower` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usn`
--

CREATE TABLE `usn` (
  `id` int(11) NOT NULL,
  `yop` varchar(255) NOT NULL,
  `dept` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usn`
--

INSERT INTO `usn` (`id`, `yop`, `dept`) VALUES
(83, '', 'PUC'),
(84, '', 'BA'),
(85, '', 'BCOM'),
(86, '', 'BSC'),
(87, '', 'BBA'),
(88, '', 'BCA'),
(89, '', 'MSC'),
(90, '', 'MCOM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appeal`
--
ALTER TABLE `appeal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `caption`
--
ALTER TABLE `caption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contribute to general corpus`
--
ALTER TABLE `contribute to general corpus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conven`
--
ALTER TABLE `conven`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `convenners_description`
--
ALTER TABLE `convenners_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dashboard`
--
ALTER TABLE `dashboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donation_info`
--
ALTER TABLE `donation_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `events1`
--
ALTER TABLE `events1`
  ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `event_calendar`
--
ALTER TABLE `event_calendar`
  ADD PRIMARY KEY (`id_calendar`);

--
-- Indexes for table `event_reg_user`
--
ALTER TABLE `event_reg_user`
  ADD PRIMARY KEY (`id_reg_user`);

--
-- Indexes for table `friendrequest`
--
ALTER TABLE `friendrequest`
  ADD PRIMARY KEY (`id_friendrequest`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id_friend`);

--
-- Indexes for table `friends_comments`
--
ALTER TABLE `friends_comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `friend_posts`
--
ALTER TABLE `friend_posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `fund for honoring achievers`
--
ALTER TABLE `fund for honoring achievers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `infra`
--
ALTER TABLE `infra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id_likes`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`);

--
-- Indexes for table `mid-day meal program_info`
--
ALTER TABLE `mid-day meal program_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `page_comments`
--
ALTER TABLE `page_comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `page_followers`
--
ALTER TABLE `page_followers`
  ADD PRIMARY KEY (`id_follower`);

--
-- Indexes for table `page_likes`
--
ALTER TABLE `page_likes`
  ADD PRIMARY KEY (`id_likes`);

--
-- Indexes for table `page_posts`
--
ALTER TABLE `page_posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `publicpost`
--
ALTER TABLE `publicpost`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `purpose`
--
ALTER TABLE `purpose`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsor a student`
--
ALTER TABLE `sponsor a student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `user_followers`
--
ALTER TABLE `user_followers`
  ADD PRIMARY KEY (`id_follower`);

--
-- Indexes for table `usn`
--
ALTER TABLE `usn`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appeal`
--
ALTER TABLE `appeal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `caption`
--
ALTER TABLE `caption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=331;

--
-- AUTO_INCREMENT for table `contact_info`
--
ALTER TABLE `contact_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `contribute to general corpus`
--
ALTER TABLE `contribute to general corpus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `conven`
--
ALTER TABLE `conven`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `convenners_description`
--
ALTER TABLE `convenners_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dashboard`
--
ALTER TABLE `dashboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `donation_info`
--
ALTER TABLE `donation_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT for table `events1`
--
ALTER TABLE `events1`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_calendar`
--
ALTER TABLE `event_calendar`
  MODIFY `id_calendar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_reg_user`
--
ALTER TABLE `event_reg_user`
  MODIFY `id_reg_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `friendrequest`
--
ALTER TABLE `friendrequest`
  MODIFY `id_friendrequest` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id_friend` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `friends_comments`
--
ALTER TABLE `friends_comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `friend_posts`
--
ALTER TABLE `friend_posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `fund for honoring achievers`
--
ALTER TABLE `fund for honoring achievers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `infra`
--
ALTER TABLE `infra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `mid-day meal program_info`
--
ALTER TABLE `mid-day meal program_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_comments`
--
ALTER TABLE `page_comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_followers`
--
ALTER TABLE `page_followers`
  MODIFY `id_follower` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_likes`
--
ALTER TABLE `page_likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_posts`
--
ALTER TABLE `page_posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `publicpost`
--
ALTER TABLE `publicpost`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purpose`
--
ALTER TABLE `purpose`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sponsor a student`
--
ALTER TABLE `sponsor a student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `user_followers`
--
ALTER TABLE `user_followers`
  MODIFY `id_follower` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usn`
--
ALTER TABLE `usn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `Clean_Older_Than_90_days_logs` ON SCHEDULE EVERY '0 1' DAY_HOUR STARTS '2020-07-30 09:37:16' ON COMPLETION NOT PRESERVE ENABLE COMMENT 'Clean up log connections at 1 AM.' DO DELETE FROM log
    WHERE log_date < DATE_SUB(NOW(), INTERVAL 90 DAY)$$

CREATE DEFINER=`root`@`localhost` EVENT `delete event_info` ON SCHEDULE EVERY 1 MINUTE STARTS '2020-07-30 11:24:02' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
   delete from EVENTS 
   where DATE(dat) = DATE(NOW() - INTERVAL 1 DAY);
   END$$

CREATE DEFINER=`root`@`localhost` EVENT `delete7DayOldMessages` ON SCHEDULE EVERY 1 SECOND STARTS '2020-07-30 11:26:50' ON COMPLETION PRESERVE DISABLE DO BEGIN
   delete from EVENTS 
   where dat =NOW();
   END$$

CREATE DEFINER=`root`@`localhost` EVENT `delete event_info1` ON SCHEDULE EVERY 1 DAY STARTS '2020-09-14 17:13:00' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM Detroit
WHERE STR_TO_DATE(startDate, '%a, %e %b %Y') < CURDATE()$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
