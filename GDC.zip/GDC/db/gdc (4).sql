-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2020 at 08:34 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gdc`
--

-- --------------------------------------------------------

--
-- Table structure for table `appeal`
--

CREATE TABLE `appeal` (
  `id` int(11) NOT NULL,
  `appeal` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `caption`
--

CREATE TABLE `caption` (
  `id` int(11) NOT NULL,
  `cap` text NOT NULL,
  `folder` text NOT NULL,
  `test` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caption`
--

INSERT INTO `caption` (`id`, `cap`, `folder`, `test`) VALUES
(4, 'a', 'admin1/a4/', '');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id_comment`, `id_user`, `id_friend`, `id_post`, `comment`, `createdAt`) VALUES
(38, 43, 43, 18, 'f', '12-06-2020 19:43'),
(39, 17, 17, 21, 'ssd', '26-08-2020 17:25');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Id` int(11) NOT NULL,
  `id_user` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `start` varchar(255) NOT NULL,
  `till` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `passout` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Id`, `id_user`, `name`, `company`, `position`, `place`, `start`, `till`, `email`, `department`, `passout`) VALUES
(2, '43', '', 'Alva\'s Education Trust', 'Lecturer', 'Moodabidre', 'June 2007 ', 'March 2008', 'anantham2004@gmail.com', '', 'MAY.2007'),
(3, '43', '', 'NMAMIT, Nitte', 'Assistant Professor', 'Nitte, Karkala', 'March 2008', 'Today', 'anantham2004@gmail.com', '', 'MAY.2007'),
(4, '52', '', 'SDM INSTITUTE OF TECHNOLOGY, UJIRE', 'ASSISTANT PROFESSOR', 'UJIRE', '20-7-2015', 'TILL NOW', 'spmadavu@gmail.com', '', 'MAY.2014'),
(6, '66', '', 'a', 'v', 'v', 'e', '11', 'test2@gmail.com', '', '1996'),
(7, '65', '', 'a', 'a', '1212', '2020-01-01', 'ww', 'akshayakvaidya@gmail.com', 'MCA', '1992');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `id_user` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `insta` varchar(255) NOT NULL,
  `linkd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `id_user`, `name`, `city`, `degree`, `phone`, `email`, `fb`, `insta`, `linkd`) VALUES
(208, '43', 'Anantha Murthy', 'MCA', 'MAY.2007', '9743702262', 'anantham2004@gmail.com', '', '', ''),
(209, '44', 'Puneeth B R', 'MCA', 'MAY.2009', '', 'sweetpuni@gmail.com', '', '', ''),
(210, '45', 'Spoorthi shetty', 'MCA', 'MAY.2007', '', 'sshetty.07@nitte.edu.in', '', '', ''),
(212, '47', 'Dr.Surendra Shetty', 'MCA', 'MAY.2004', '', 'hsshetty4u@yahoo.com', '', '', ''),
(213, '17', 'admin', 'MCA', '', 'a', 'admin@gmail.com', 'b', 'c', 'e'),
(214, '48', 'test2', 'MCA', 'MAY.2012', '', 'test2@gmail.com', '', '', ''),
(215, '49', 'Jasline Maria Tauro', 'ELC', '', '', 'taurojasline@gmail.com', '', '', ''),
(216, '50', 'Anoop M A', 'IFS', '', '', 'anoopjamadagni@gmail.com', '', '', ''),
(217, '51', 'Suhas Nayak', 'MCA', '', '', 'snsuhasnayak@gmail.com', '', '', ''),
(218, '52', 'Shivaprasad B L', 'MCA', 'MAY.2012', '', 'spmadavu@gmail.com', '', '', ''),
(219, '51', 'Suhas Nayak', 'ELE', 'MAY.2014', '', 'snsuhasnayak@gmail.com', '', '', ''),
(220, '52', 'Shivaprasad B L', 'MMD', 'MAY.2014', '', 'spmadavu@gmail.com', '', '', ''),
(221, '53', 'Karthik Kamath ', 'ELC', 'MAY.2014', '', 'karthikkamaths24@gmail.com', '', '', ''),
(222, '54', 'Yash Khetan', 'MEC', 'MAY.2016', '', 'yashkhetan1994@gmail.com', '', '', ''),
(223, '55', 'AKSHAY', 'MCA', 'MAY.2012', '', 'akshayakvaidya@gmail.com', '', '', ''),
(224, '56', 'akshay', '', '', '', 's@gmail.com', '', '', ''),
(225, '57', 'akshay', '', '', '', 's1@gmail.com', '', '', ''),
(226, '58', 'putta', '', '', '', 'putta@gmail.com', '', '', ''),
(227, '59', 'akshay', '', '', '', 'akshayakvaidya@gmail.com', '', '', ''),
(228, '60', 'savitha', 'Ph.D', '', '', 'sshe1tty.07@nitte.edu.in', '', '', ''),
(229, '61', 'akshay', 'MBA', '2001', '', 'akshayakvaidya123@gmail.com', '', '', ''),
(230, '62', 'XYZ', 'Construction Technology', '2003', '', 'xyz@gmail.com', '', '', ''),
(231, '63', 'putta1', 'Computer & Communication Engineering', '2002', '', 'putta1@gmail.com', '', '', ''),
(232, '64', 'super_user', 'Ph.D', '2000', '', '1admin@gmail.com', '', '', ''),
(233, '65', 'akshay', 'MCA', '1998', '', 'akshayakvaidya@gmail.com', '', '', ''),
(234, '66', 'test', 'MCA', '1996', '9740769579', 'test2@gmail.com', '', 'b', 'c'),
(235, '67', 'test3', 'Energy Systems Engineering', '2019', '', 'test3@gmail.com', '', '', ''),
(236, '68', 'putta', 'Mechanical Engineering', '1996', '', 'putta@gmail.com', '', '', ''),
(237, '69', 'test4', 'Ph.D', '1996', '', 'test34@gmail.com', '', '', ''),
(238, '78', 'test2', '', '', '', 'test2@gmail.com', '', '', ''),
(239, '79', 'test2', '', '', '', 'test2@gmail.com', '', '', ''),
(240, '80', 'test21221', '', '', '', 'test21221@gmail.com', '', '', ''),
(241, '81', 'test21221', '', '', '', 'test21221@gmail.com', '', '', ''),
(242, '82', 'test67', 'MCA', '1998', '', 'test67@gmail.com', '', '', ''),
(243, '83', 'akshay', ' M.Com', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(244, '84', 'test22222', 'MCA', '', '', 'test22222@gmail.com', '', '', ''),
(245, '85', 'test22222', 'MCA', '', '', 'test22222@gmail.com', '', '', ''),
(246, '86', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(247, '87', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(248, '88', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(249, '89', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(250, '92', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(251, '93', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(252, '94', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(253, '95', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(254, '96', 'M Ramesh Rao', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(255, '97', 'putta', 'MCA', '', '', 'putta1@gmail.com', '', '', ''),
(256, '98', 'Aks', ' M.Com', '1996', '', 'aks@gmail.com', '', '', ''),
(257, '99', 'akshay', ' M.Com', '1996', '', 'test21223@gmail.com', '', '', ''),
(258, '100', 'putta', 'MCA', '', '', '112admin@gmail.com', '', '', ''),
(259, '101', 'putta', 'MCA', '', '', 'dmin@gmail.com', '', '', ''),
(260, '102', 'putta', 'MCA', '', '', 'putta420@gmail.com', '', '', ''),
(261, '103', 'putta', 'MCA', '', '', 'putta421@gmail.com', '', '', ''),
(262, '104', 'putta100000', 'MCA', '', '', 'putta100000@gmail.com', '', '', ''),
(263, '105', 'putta12', 'MCA', '', '', 'putta42145@gmail.com', '', '', ''),
(264, '106', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(265, '107', 'putta12', 'MCA', '', '', 'putta42145@gmail.com', '', '', ''),
(266, '108', 'putta', 'MCA', '', '', 'admin1@gmail.com', '', '', ''),
(267, '109', 'putta12', 'MCA', '', '', 'putta1@gmail.com', '', '', ''),
(268, '110', 'putta', 'sfd', '', '', 'akshayakvaidya@gmail.com', '', '', ''),
(269, '17', 'admin', 'MCA', '1996', '', 'admin@gmail.com', '', '', ''),
(270, '65', 'akshay', 'MCA', '', '', 'akshayakvaidya@gmail.com', '', '', ''),
(271, '82', 'test67', 'MCA', '1998', '', 'test67@gmail.com', '', '', ''),
(272, '83', 'akshay', ' M.Com', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(273, '96', 'M Ramesh Rao', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(274, '97', 'putta', 'MCA', '', '', 'putta1@gmail.com', '', '', ''),
(275, '98', 'Aks', ' M.Com', '1996', '', 'aks@gmail.com', '', '', ''),
(276, '99', 'akshay', ' M.Com', '1996', '', 'test21223@gmail.com', '', '', ''),
(277, '100', 'putta', 'MCA', '', '', '112admin@gmail.com', '', '', ''),
(278, '101', 'putta', 'MCA', '', '', 'dmin@gmail.com', '', '', ''),
(279, '102', 'putta', 'MCA', '', '', 'putta420@gmail.com', '', '', ''),
(280, '103', 'putta', 'MCA', '', '', 'putta421@gmail.com', '', '', ''),
(281, '104', 'putta100000', 'MCA', '', '', 'putta100000@gmail.com', '', '', ''),
(282, '105', 'putta12', 'MCA', '', '', 'putta42145@gmail.com', '', '', ''),
(283, '111', 'akshay1', 'MCA', '', '', 'akshay1@gmail.com', '', '', ''),
(284, '112', 'akshay', 'BBA', '2012', '', 'admin1212@gmail.com', '', '', ''),
(285, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(286, '114', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(287, '115', 'name', 'city', 'degree', '', 'email', '', '', ''),
(288, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(289, '116', '', '', '', '', '', '', '', ''),
(290, '117', '', '', '', '', '', '', '', ''),
(291, '118', 'name', 'city', 'degree', '', 'email', '', '', ''),
(292, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(293, '119', '', '', '', '', '', '', '', ''),
(294, '120', '', '', '', '', '', '', '', ''),
(295, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(296, '121', '', '', '', '', '', '', '', ''),
(297, '122', '', '', '', '', '', '', '', ''),
(298, '113', 'putta', 'BCA', '1996', '', 'putta@gmail.com', '', '', ''),
(299, '125', 'name', 'city', '', '', 'email', '', '', ''),
(300, '114', 'putta', 'MCA', '', '', 'putta@gmail.com', '', '', ''),
(301, '126', '1', '6', '', '', '2', '', '', ''),
(302, '127', 'name', 'phone', 'city', '', 'email', '', '', ''),
(303, '114', 'putta', '1234567890', 'MCA', '', 'putta@gmail.com', '', '', ''),
(304, '128', 'Akshay', 'BSC', '1996', '', 'akshayakvaidya1@gmail.com', '', '', ''),
(305, '129', 'akshay', 'BCOM', '1996', '', 'akshayakvaidya2@gmail.com', '', '', ''),
(306, '130', 'akshay', '113', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(307, '131', 'akshay', 'BBA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(308, '132', 'akshay', 'BBA', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(309, '133', 'akshay', 'BA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(310, '134', 'akshay', 'BCOM', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(311, '135', 'akshay', 'BBA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(312, '136', 'akshay', 'BA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(313, '137', 'akshay', 'BBA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(314, '138', 'akshay', 'BCA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(315, '139', 'akshay', 'BA', '1996', '', 'anantham2004@gmail.com', '', '', ''),
(316, '140', 'akshay', 'BCA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(317, '141', 'akshay', 'BSC', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(318, '142', 'akshay', 'BA', '1996', '', 'akshayakvaidya@gmail.com', '', '', ''),
(319, '143', 'Santhosh', '113', '1996', '', 'anantham2004@gmail.com', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id` int(11) NOT NULL,
  `Position` text NOT NULL,
  `type` text NOT NULL,
  `url` text NOT NULL,
  `name` text NOT NULL,
  `email_id` text NOT NULL,
  `phone` text NOT NULL,
  `order1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`id`, `Position`, `type`, `url`, `name`, `email_id`, `phone`, `order1`) VALUES
(16, 'President\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'M.Ramesh Rao', 'akshayakvaidya@gmail.com', '9740769579', 3),
(17, 'Vice - President\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'Dr. Sayeegeetha\r\n', 'akshayakvaidya@gmail.com', '9740769579', 4),
(18, 'Secretary\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'CA Guruprasad K\r\n', 'akshayakvaidya@gmail.com', '9740769579', 5),
(19, 'Joint - Secretary\r\n', 'Office Bearers', '5f57b5464a91b.jpg', 'Leeladhara B Shetty\r\n', 'akshayakvaidya@gmail.com', '9740769579', 6),
(22, 'member', 'Member', '5f57b5464a91b.jpg', 'UDAYABHASKAR Y V\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(23, 'member', 'Member', '5f57b5464a91b.jpg', 'Dr. Suprabha K. R\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(24, 'member', 'Member', '5f57b5464a91b.jpg', 'VEENA T SHETTY\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(25, 'member', 'Member', '5f57b5464a91b.jpg', 'Dr. S. Gunakar\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(26, 'member', 'Member', '5f57b5464a91b.jpg', 'P. Madhava Suvarna\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(27, 'member', 'Member', '5f57b5464a91b.jpg', 'Sathish Surathkal\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(28, 'member', 'Member', '5f57b5464a91b.jpg', 'Smt Mani M Rai\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(29, 'member', 'Member', '5f57b5464a91b.jpg', 'Smt Lekha Jayekar\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(30, 'member', 'Member', '5f57b5464a91b.jpg', 'Vinod Shetty\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(31, 'member', 'Member', '5f57b5464a91b.jpg', 'Ms Priya Nayak\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(32, 'member', 'Member', '5f57b5464a91b.jpg', 'Venugopal Shenoy\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(33, 'member', 'Member', '5f57b5464a91b.jpg', 'Canute Jeevan Pinto\r\n', 'akshayakvaidya@gmail.com', '9740769579', 0),
(39, 'test', 'Office Bearers', 'IMG-20200819-WA0030.jpg', 'test', 'test', 'test', 2),
(40, 'test', 'Office Bearers', 'Mw.png', 'test', 'akshayakvaidya@gmail.com', 'test', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contribute to general corpus`
--

CREATE TABLE `contribute to general corpus` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contribute to general corpus`
--

INSERT INTO `contribute to general corpus` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `conven`
--

CREATE TABLE `conven` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `place` text NOT NULL,
  `phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conven`
--

INSERT INTO `conven` (`id`, `name`, `place`, `phone`) VALUES
(2, 'Akshay', 'byndoor', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `convenners_description`
--

CREATE TABLE `convenners_description` (
  `id` int(11) NOT NULL,
  `des` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `convenners_description`
--

INSERT INTO `convenners_description` (`id`, `des`) VALUES
(3, '   As per the discussion and decision taken in the GDCAA Governing Council Meeting held on 29.08.2020 the Convener Committee consisting of following GDC Alumni has been formed. The main purpose of the committee is to oversee the Membership Drive and enrollment of members to GDCAA. The committee will also coordinate and take active participation in mobilizing the funds for various activities and also give suggestions in formulating the plan for conducting the activities like Skill Training Programme for students, conducting Anniversary Programme, sports and cultural activities for GDCAA members.');

-- --------------------------------------------------------

--
-- Table structure for table `dashboard`
--

CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL,
  `about_us` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dashboard`
--

INSERT INTO `dashboard` (`id`, `about_us`) VALUES
(1, 'Govinda Dasa College Alumni Association (R), (GDCAA) is a non-profit organization formed in the year of 2019 and registered under Karnataka Societies Registration Act, 1960. GDCAA provides a lifelong bridge between Govinda Dasa College, Surathkal and its Alumnus\'. Association Members are ex-students of Govinda Dasa College, Surathkal(http://www.govindadasacollege.edu.in/) who had studied for one or more academic year in the institution.'),
(2, ''),
(3, 'Objectives'),
(4, '1.Provide a common platform for all the ex-students to come together and share their rich experiences in various fields with each other, with present staff and students of the college.'),
(5, '2.Provide opportunity to exhibit alumni expertise and talents in Intellectual, Academic, Cultural &sports through various programs in these areas and inspire such talents amongst present students;'),
(6, '3. Promote scholarship and welfare schemes for deserving students, undertake developmental activities for the college, students and to the society'),
(7, ''),
(8, 'Alumni Outreach'),
(9, 'This is a Pursuit of bringing together all the alumnus’ of Govinda Dasa College under one umbrella has begun. Let’s come together and contribute something valuable to the Institution that has shaped our lives to a considerable extent. More importantly let us take it as an opportunity to show our patronage to the present generation of students who are occupying our benches where we used to sit long back.');

-- --------------------------------------------------------

--
-- Table structure for table `donation_info`
--

CREATE TABLE `donation_info` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL,
  `ap` int(11) NOT NULL DEFAULT 0,
  `lock_bt` int(11) NOT NULL DEFAULT 0,
  `updated_at` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_info`
--

INSERT INTO `donation_info` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`, `ap`, `lock_bt`, `updated_at`) VALUES
(35, 'online', 'Sponsor a Student', '5000', 'YES', 'Online Confirmation', 'AKSHAY', '', 0, 1, '2020-10-28 21:57:39'),
(36, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'putta', 'cheque', 0, 1, '2020-10-28 21:57:39'),
(37, 'payment_type', 'purpose', 'amount', 'Agree', 'confirmation', 'name', 'chq_info', 0, 1, '2020-10-28 21:57:39'),
(38, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'test', 'A520255', 0, 0, ''),
(39, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'test', 'A520255', 0, 0, ''),
(40, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'test', 'A520255', 0, 0, ''),
(41, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'test', 'A520255', 0, 0, ''),
(42, 'Cheque', 'Sponsor a Student', '552', 'YES', '', 'XYZ', 'A11', 0, 0, ''),
(43, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'putta', 'cheque', 0, 0, ''),
(44, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'putta', 'cheque', 0, 0, ''),
(45, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'putta', 'cheque', 0, 0, ''),
(46, 'online', 'Sponsor a Student', '5000', 'YES', '500 syndixate', 'XYZ', '', 0, 0, ''),
(47, 'online', 'Mid-Day Meal Program', '500', 'YES', 'message from Alumni', 'Santhosh', '', 0, 0, ''),
(48, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'XYZ', 'cheque', 0, 0, ''),
(49, 'Cheque', 'Sponsor a Student', '5000', 'YES', '', 'akshay', '1500', 0, 0, ''),
(50, 'online', 'Sponsor a Student', '5000', 'YES', 'a', 'akshay', '1500', 0, 0, ''),
(51, 'Cheque', 'Sponsor a Student', '5000', 'YES', '', 'XYZ', '1500', 0, 0, ''),
(52, 'Cheque', 'Sponsor a Student', '5000', 'YES', '', 'putta', 'AAA', 0, 0, ''),
(53, 'Cheque', 'Sponsor a Student', '5000', 'YES', '', 'XYZ', 'A520255', 0, 0, ''),
(54, 'Cheque', 'Contribute to General Corpus', '5000', 'YES', '', 'XYZ', 'cheque', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id_event` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ename` varchar(255) NOT NULL,
  `conduct` varchar(255) NOT NULL,
  `dat` datetime NOT NULL,
  `addr` text NOT NULL,
  `info` text NOT NULL,
  `uploader` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events1`
--

CREATE TABLE `events1` (
  `id_event` int(11) NOT NULL,
  `id_user` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_calendar`
--

CREATE TABLE `event_calendar` (
  `id_calendar` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `bgColor` varchar(255) NOT NULL,
  `borderColor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_reg_user`
--

CREATE TABLE `event_reg_user` (
  `id_reg_user` int(11) NOT NULL,
  `id_event` text NOT NULL,
  `id_user` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_reg_user`
--

INSERT INTO `event_reg_user` (`id_reg_user`, `id_event`, `id_user`, `name`) VALUES
(10, '3', '17', 'admin'),
(11, '2', '17', 'admin'),
(13, '4', '17', 'admin'),
(14, '5', '17', 'admin'),
(15, '4', '46', 'test'),
(16, '5', '46', 'test'),
(17, '4', '43', 'Anantha Murthy'),
(19, '127', '17', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `friendrequest`
--

CREATE TABLE `friendrequest` (
  `id_friendrequest` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `viewed` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendrequest`
--

INSERT INTO `friendrequest` (`id_friendrequest`, `id_user`, `id_friend`, `purpose`, `viewed`) VALUES
(1, 44, 43, 'Hi Puneeth', 0),
(2, 47, 43, 'Hi Sir', 0),
(3, 55, 17, 'send', 0);

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id_friend` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_frienduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id_friend`, `id_user`, `id_frienduser`) VALUES
(17, 45, 43),
(18, 43, 45),
(19, 17, 46),
(20, 46, 17),
(21, 55, 43),
(22, 43, 55),
(23, 17, 66),
(24, 66, 17),
(25, 17, 65),
(26, 65, 17),
(29, 143, 142),
(30, 142, 143);

-- --------------------------------------------------------

--
-- Table structure for table `friends_comments`
--

CREATE TABLE `friends_comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends_comments`
--

INSERT INTO `friends_comments` (`id_comment`, `id_user`, `id_friend`, `id_post`, `comment`, `createdAt`) VALUES
(1, 66, 66, 2, 'dgdg', '13-08-2020 17:12:28');

-- --------------------------------------------------------

--
-- Table structure for table `friend_posts`
--

CREATE TABLE `friend_posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_friend` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friend_posts`
--

INSERT INTO `friend_posts` (`id_post`, `id_user`, `id_friend`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
(1, 43, 45, 'hello friend ', '', '', '', '15-01-2020 12:56:47'),
(3, 66, 0, '', '5f3527031091b.png', '', '', '13-08-2020 17:11:55'),
(4, 66, 0, '', '5f352713b636b.png', '', '', '13-08-2020 17:12:11');

-- --------------------------------------------------------

--
-- Table structure for table `fund for honoring achievers`
--

CREATE TABLE `fund for honoring achievers` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fund for honoring achievers`
--

INSERT INTO `fund for honoring achievers` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `caption` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image`, `caption`) VALUES
(1, 'admin1/a4/1211289217.png', 'a'),
(2, 'admin1/a4/1270510983.png', 'a'),
(3, 'admin1/a4/1834379623.png', 'aaa'),
(4, 'admin1/a4/115747264.png', 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `infra`
--

CREATE TABLE `infra` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infra`
--

INSERT INTO `infra` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id_likes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `s` varchar(255) NOT NULL,
  `id_message` int(11) NOT NULL,
  `id_from` int(11) NOT NULL,
  `id_to` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `viewed` int(11) NOT NULL,
  `createdAt` text NOT NULL,
  `Rohan` int(11) NOT NULL DEFAULT 1,
  `Se` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`s`, `id_message`, `id_from`, `id_to`, `message`, `viewed`, `createdAt`, `Rohan`, `Se`) VALUES
('', 1, 43, 45, 'hi', 0, '11-01-2020 08:58:17', 1, 1),
('', 2, 46, 17, 'ds', 1, '11-01-2020 09:56:37', 0, 1),
('', 3, 17, 46, '1', 1, '11-01-2020 19:32:15', 0, 0),
('', 4, 17, 46, '2', 1, '11-01-2020 19:32:16', 1, 0),
('', 5, 17, 46, '3', 1, '11-01-2020 19:32:17', 1, 0),
('', 6, 17, 46, '4', 1, '11-01-2020 19:32:17', 1, 1),
('', 7, 17, 46, '5', 1, '11-01-2020 19:32:18', 1, 1),
('', 8, 43, 45, 'y not replying', 0, '13-01-2020 15:51:04', 1, 1),
('', 10, 66, 17, 'test', 1, '13-08-2020 16:49:15', 0, 1),
('', 11, 65, 17, 'hi', 1, '08-09-2020 22:19:41', 1, 1),
('', 12, 142, 143, 'eghjjhgfds', 0, '01-11-2020 12:42:03', 1, 1),
('', 13, 142, 143, 'sdfghj', 0, '01-11-2020 12:42:05', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mid-day meal program_info`
--

CREATE TABLE `mid-day meal program_info` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mid-day meal program_info`
--

INSERT INTO `mid-day meal program_info` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `notice_id` int(11) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `subject` text NOT NULL,
  `notices` varchar(50) NOT NULL,
  `Date` datetime NOT NULL,
  `ex_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`notice_id`, `branch`, `subject`, `notices`, `Date`, `ex_date`) VALUES
(3, 'ALL Branch', 'test', '20170722135325_IMG_9259.JPG', '2020-06-11 20:17:37', '2020-06-30');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id_page` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `vmode` varchar(255) NOT NULL DEFAULT 'Public',
  `pmode` varchar(255) NOT NULL DEFAULT 'Public'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_comments`
--

CREATE TABLE `page_comments` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_followers`
--

CREATE TABLE `page_followers` (
  `id_follower` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_likes`
--

CREATE TABLE `page_likes` (
  `id_likes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_posts`
--

CREATE TABLE `page_posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_page` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `Contribute to General Corpus` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `Contribute to General Corpus`) VALUES
(1, 'Govinda Dasa College (GDC), Surathkal started in 1967 has become one of the premier institution in and around Surathkal by providing quality education in Science, Commerce & management and Arts stream through graduate and post graduate courses. Over the years, its growth and development has been bolstered by contributions from alumni, philanthropists and well-wishers. As it forges ahead in the 21st century, after successfully completing 50 years of its formation, GDC aims to expand further in its academic pursuits and infrastructure, in order to be one of the best college in the Nation.\r\n\r\nWe alumni’sneed to partner with College in its development path. Request all the alumni’s, Donorsto contribute generously to GDCAA’s General Corpus and become a valuable partner. Your contributions will greatly help sustain Associations finances for discretionary expenditures to various activities.\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `type` varchar(255) NOT NULL,
  `id_post` int(11) NOT NULL,
  `id_user` varchar(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`type`, `id_post`, `id_user`, `description`, `image`, `video`, `youtube`, `createdAt`) VALUES
('frien', 18, '43', 'Test', '', '', '', '12-06-2020 08:07:37'),
('admin', 21, '17', 'asad', '', '', '', ''),
('admin', 22, '17', 'af', '', '', '', ''),
('frien', 23, '66', 'asas', '', '', '', '13-08-2020 15:59:02'),
('admin', 24, '17', 'admin', '', '', '', ''),
('admin', 25, '17', 'test', '', '', '', ''),
('admin', 26, '17', '', '5f59c688792d9.jpg', '', '', ''),
('admin', 27, '17', 'asass', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `publicpost`
--

CREATE TABLE `publicpost` (
  `type` varchar(255) NOT NULL DEFAULT 'admin',
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purpose`
--

CREATE TABLE `purpose` (
  `id` int(11) NOT NULL,
  `purpose` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purpose`
--

INSERT INTO `purpose` (`id`, `purpose`) VALUES
(1, 'Contribute to General Corpus'),
(2, 'Sponsor a Student'),
(3, 'Mid-Day Meal Program'),
(4, 'Fund for Honoring Achievers'),
(5, 'Contribute to Benevolent Fund'),
(6, 'Infra / Long Term Projects'),
(7, 'Sports and Culturals');

-- --------------------------------------------------------

--
-- Table structure for table `sponsor a student`
--

CREATE TABLE `sponsor a student` (
  `id` int(11) NOT NULL,
  `payment_type` text NOT NULL,
  `purpose` text NOT NULL,
  `amount` text NOT NULL,
  `Agree` text NOT NULL,
  `confirmation` text NOT NULL,
  `name` text NOT NULL,
  `chq_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sponsor a student`
--

INSERT INTO `sponsor a student` (`id`, `payment_type`, `purpose`, `amount`, `Agree`, `confirmation`, `name`, `chq_info`) VALUES
(9, 'online', 'mid', '500', 'Y', '500 syndixate', 'putta', ''),
(10, 'chq', 'mid', '5000', 'Y', '', 'putta', ''),
(11, 'online', 'mid', '5000', 'Y', '500 syndixate', 'AAAA', ''),
(12, 'Cheque', 'mid', '5000', 'Y', '', 'Akshay', ''),
(13, 'online', 'donate', '5000', 'Y', '500', 'akshay', ''),
(14, 'Cheque', 'mid', '5000', 'Y', '', 'akshay', 'cheque'),
(15, 'online', 'donate', '5000', 'Y', 'Online', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `gend` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unregister`
--

CREATE TABLE `unregister` (
  `type` varchar(255) NOT NULL DEFAULT 'user',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name1` text NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unregister`
--

INSERT INTO `unregister` (`type`, `name`, `email`, `name1`, `msg`) VALUES
('user', 'akshaya', 'akshayakvaidya@gmail.com', 'Welcome', 'Welcome\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `type` varchar(10) NOT NULL DEFAULT 'user',
  `id_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL,
  `DOB` varchar(255) NOT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `aboutme` text DEFAULT NULL,
  `profileimage` varchar(255) DEFAULT NULL,
  `online` int(11) NOT NULL DEFAULT 0,
  `name1` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `tran_id` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `mode_pay` varchar(255) NOT NULL,
  `current_qualification` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'life_mem',
  `ass_work_status` text NOT NULL,
  `retire` text NOT NULL,
  `flag` int(11) NOT NULL DEFAULT 0,
  `lock_act` text NOT NULL DEFAULT '1',
  `recp_no` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`type`, `id_user`, `name`, `email`, `password`, `createdAt`, `address`, `DOB`, `degree`, `university`, `city`, `skills`, `aboutme`, `profileimage`, `online`, `name1`, `msg`, `tran_id`, `phone`, `status`, `mode_pay`, `current_qualification`, `user_type`, `ass_work_status`, `retire`, `flag`, `lock_act`, `recp_no`) VALUES
('admin', 17, 'admin', 'admin@gmail.com', 'admin', '2019-11-01 04:31:26', 'admin', '', '1996', 'Nitte', 'MCA', 'CSS', '', NULL, 0, 'gdcca', 'gdcca', '481986', '', '0', '', '', 'admin', '', '0', 1, '0', ''),
('user', 142, 'akshay', 'akshayakvaidya@gmail.com', '1234', '2020-10-29 16:43:15', 'address', '2020-10-31', '1996', NULL, 'BA', NULL, NULL, NULL, 0, 'akshay', '', '100', '9740769579', '', 'Check Payment', 'MCA', 'life_mem', '', '', 1, '0', ''),
('user', 143, 'Santhosh', 'anantham2004@gmail.com', '1234', '2020-10-31 08:10:16', 'address', '2020-01-01', '1996', NULL, '113', NULL, NULL, NULL, 0, 'Santhosh', '', '500', '9740769579', '', 'Online Transfer', 'MCA', 'life_mem', '', '', 1, '0', '50');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `insert` AFTER INSERT ON `users` FOR EACH ROW INSERT INTO contact(id_user,name,email,city,degree)VALUES(NEW.id_user,NEW.name,NEW.email,NEW.city,NEW.degree)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update1` AFTER UPDATE ON `users` FOR EACH ROW UPDATE contact set contact.name=NEW.name,contact.email=NEW.email WHERE contact.id_user=old.id_user
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_followers`
--

CREATE TABLE `user_followers` (
  `id_follower` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_userfollower` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usn`
--

CREATE TABLE `usn` (
  `id` int(11) NOT NULL,
  `yop` varchar(255) NOT NULL,
  `dept` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usn`
--

INSERT INTO `usn` (`id`, `yop`, `dept`) VALUES
(83, '', 'PUC'),
(84, '', 'BA'),
(85, '', 'BCOM'),
(86, '', 'BSC'),
(87, '', 'BBA'),
(88, '', 'BCA'),
(89, '', 'MSC'),
(90, '', 'MCOM'),
(91, '', '113'),
(92, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appeal`
--
ALTER TABLE `appeal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `caption`
--
ALTER TABLE `caption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contribute to general corpus`
--
ALTER TABLE `contribute to general corpus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conven`
--
ALTER TABLE `conven`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `convenners_description`
--
ALTER TABLE `convenners_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dashboard`
--
ALTER TABLE `dashboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donation_info`
--
ALTER TABLE `donation_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `events1`
--
ALTER TABLE `events1`
  ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `event_calendar`
--
ALTER TABLE `event_calendar`
  ADD PRIMARY KEY (`id_calendar`);

--
-- Indexes for table `event_reg_user`
--
ALTER TABLE `event_reg_user`
  ADD PRIMARY KEY (`id_reg_user`);

--
-- Indexes for table `friendrequest`
--
ALTER TABLE `friendrequest`
  ADD PRIMARY KEY (`id_friendrequest`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id_friend`);

--
-- Indexes for table `friends_comments`
--
ALTER TABLE `friends_comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `friend_posts`
--
ALTER TABLE `friend_posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `fund for honoring achievers`
--
ALTER TABLE `fund for honoring achievers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `infra`
--
ALTER TABLE `infra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id_likes`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`);

--
-- Indexes for table `mid-day meal program_info`
--
ALTER TABLE `mid-day meal program_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `page_comments`
--
ALTER TABLE `page_comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `page_followers`
--
ALTER TABLE `page_followers`
  ADD PRIMARY KEY (`id_follower`);

--
-- Indexes for table `page_likes`
--
ALTER TABLE `page_likes`
  ADD PRIMARY KEY (`id_likes`);

--
-- Indexes for table `page_posts`
--
ALTER TABLE `page_posts`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `publicpost`
--
ALTER TABLE `publicpost`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `purpose`
--
ALTER TABLE `purpose`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsor a student`
--
ALTER TABLE `sponsor a student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `user_followers`
--
ALTER TABLE `user_followers`
  ADD PRIMARY KEY (`id_follower`);

--
-- Indexes for table `usn`
--
ALTER TABLE `usn`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appeal`
--
ALTER TABLE `appeal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `caption`
--
ALTER TABLE `caption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;

--
-- AUTO_INCREMENT for table `contact_info`
--
ALTER TABLE `contact_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `contribute to general corpus`
--
ALTER TABLE `contribute to general corpus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `conven`
--
ALTER TABLE `conven`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `convenners_description`
--
ALTER TABLE `convenners_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dashboard`
--
ALTER TABLE `dashboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `donation_info`
--
ALTER TABLE `donation_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `events1`
--
ALTER TABLE `events1`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_calendar`
--
ALTER TABLE `event_calendar`
  MODIFY `id_calendar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_reg_user`
--
ALTER TABLE `event_reg_user`
  MODIFY `id_reg_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `friendrequest`
--
ALTER TABLE `friendrequest`
  MODIFY `id_friendrequest` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id_friend` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `friends_comments`
--
ALTER TABLE `friends_comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `friend_posts`
--
ALTER TABLE `friend_posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fund for honoring achievers`
--
ALTER TABLE `fund for honoring achievers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `infra`
--
ALTER TABLE `infra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `mid-day meal program_info`
--
ALTER TABLE `mid-day meal program_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_comments`
--
ALTER TABLE `page_comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_followers`
--
ALTER TABLE `page_followers`
  MODIFY `id_follower` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_likes`
--
ALTER TABLE `page_likes`
  MODIFY `id_likes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_posts`
--
ALTER TABLE `page_posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `publicpost`
--
ALTER TABLE `publicpost`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purpose`
--
ALTER TABLE `purpose`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sponsor a student`
--
ALTER TABLE `sponsor a student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `user_followers`
--
ALTER TABLE `user_followers`
  MODIFY `id_follower` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usn`
--
ALTER TABLE `usn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `Clean_Older_Than_90_days_logs` ON SCHEDULE EVERY '0 1' DAY_HOUR STARTS '2020-07-30 09:37:16' ON COMPLETION NOT PRESERVE ENABLE COMMENT 'Clean up log connections at 1 AM.' DO DELETE FROM log
    WHERE log_date < DATE_SUB(NOW(), INTERVAL 90 DAY)$$

CREATE DEFINER=`root`@`localhost` EVENT `delete event_info` ON SCHEDULE EVERY 1 MINUTE STARTS '2020-07-30 11:24:02' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
   delete from EVENTS 
   where DATE(dat) = DATE(NOW() - INTERVAL 1 DAY);
   END$$

CREATE DEFINER=`root`@`localhost` EVENT `delete7DayOldMessages` ON SCHEDULE EVERY 1 SECOND STARTS '2020-07-30 11:26:50' ON COMPLETION PRESERVE DISABLE DO BEGIN
   delete from EVENTS 
   where dat =NOW();
   END$$

CREATE DEFINER=`root`@`localhost` EVENT `delete event_info1` ON SCHEDULE EVERY 1 DAY STARTS '2020-09-14 17:13:00' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM Detroit
WHERE STR_TO_DATE(startDate, '%a, %e %b %Y') < CURDATE()$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
