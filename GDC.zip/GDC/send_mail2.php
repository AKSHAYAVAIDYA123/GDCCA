<?php
//send_mail.php
ob_start();
if(isset($_POST['email_data']))
{
	
	require 'class/class.phpmailer.php';
	require 'class/PHPMailerAutoload.php';
	$output = '';
	foreach($_POST['email_data'] as $row)
	{

		$txt=$row["email1"];
		$txt2=$row["email2"];
		$mail = new PHPMailer;
		$mail->IsSMTP();								//Sets Mailer to send message using SMTP
 $mail ->Host = "smtp.hostinger.in";
   $mail ->Port = 587; // or 587
   		$mail->SMTPAuth = true;							//Sets SMTP 
$mail->IsHTML(true);
$mail ->Username = "gdcaa@alumnigdc.in";
   $mail ->Password = "Gdcaa@2021";
   $mail ->SetFrom("gdcaa@alumnigdc.in","Admin GDCAA");
//$mail->SetFrom('alumni@nmamit-alumni.in','A');
		 $mail->SMTPSecure = 'TLS';							//Sets connection  
		// $mail ->SetFrom("alumni@nmamit-alumni.in","WENAMITAA");
		$mail->AddAddress($row["email"], $row["name"]);	//Adds a "To" address
		$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
		 		
		$mail->Subject = $txt;
		$mail->Body = $txt2;
		
		$mail->AltBody = '';

		$result = $mail->Send();
								//Send an Email. Return true on success or false on error

			if($result["code"] == '400')
		{
			$output .= html_entity_decode($result['full_error']);
		}

	}
	if($output == '')
	{
		echo 'ok';
	}
	else
	{
		echo $output;
	}
}
ob_flush();
?>