<?php
require_once("db.php");

?>
<?php

session_start();
 
//unset ($_SESSION["yop"]);
require_once("db.php");
$search_result = $conn->query("SELECT * FROM `donation_info` where AGREE='YES' and ap='0' and lock_bt='1' order by id desc");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDCAA</title>
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
      <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
     <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
     <link href="dashboard/css/login.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css"
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
      <!--Main Menu File-->
  
</head>
<body onload="myFunction1()">

<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}

.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}

</style>

</style>
 <?php include 'menu1.php';?>
    <!--Menu HTML Code-->
  </div>
  
</div>
<br>
<br>
<br>
 

<section class="inner-bg">
  <div class="container">
    <div class="row">

       <div class="col-sm-9">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">Mid-Day Meal Program</h2>
           <p class="wow fadeInDown">   
          The funds from this program will be used to provide Mid-Day Meal vouchers to the students of Govinda Dasa College. There are many students who come from rural areas or faraway places and are not able to carry their meal to the college and are not in a position to go back home for Lunch. Association will contribute money from this fund to College Mid-Day Meal program to help such students “Not to go hungry” while studying. 
              </p>

              <ul>
              <li class="wow fadeInDown">
                  Contribution Amount: Minimum Rs 1500 (approximate cost for one student for one month)

              </li>
                  <li class="wow fadeInDown">
               Amount of contribution to College’s Mid-Day Meal Program will be decided by Association in consultation with College Principal based on the program requirements 
              </li>

              <li>
  
     
       <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <button type="button" class="btn btn-primary1" data-toggle="modal" data-target="#exampleModal15">
 Click Here to Make Contribute
</button>
<div class="modal fade" id="exampleModal15" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Contribute</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <h5><b>For Online Transfer Transfer</b></h5> 
         <span>
           
            A/c Name: Govinda Dasa College Alumni Association<br>
            A/c Number:3512500146746201<br>
            IFSC Code:KARB0000351<br>
            Bank Name: Karnataka Bank Ltd, Iddya Branch<br>
            </span> 


              <h5><b>For Cheque</b></h5> 
         <span>
           
           Payable to Govinda Dasa College Alumni Association,<br>
            Mail:Attn: President - GDCAA<br>
            C/o Govinda Dasa College<br>
            Iddya, Surathkal 575014<br>
            </span>  

            <hr>
        <div class="container-fluid">
        <form method="POST" action="add-don5.php" enctype="multipart/form-data">
          <div class="row">
            <div class="col-lg-3">
                <label class="control-label" style="position:relative; top:7px;">Type</label>
          </div>
            <div class="col-lg-9">
             <select id="mySelect" onchange="myFunction()" class="form-control"name="mySelect" required>
        <option value="">Please Select Payment Type</option>
        <option value="Cheque">Cheque</option>
            <option value="online">Online Payment</option>
      </select>   
                </div>
          </div>
          <div style="height:10px;"></div>
          <div class="row">
            <div class="col-lg-3">
                <label class="control-label" style="position:relative; top:7px;">Purpose</label>
          </div>
            <div class="col-lg-9">
              <select id="mySelect1" class="form-control" name="mySelect1" required>
        <option value="">Please Select Purpose</option>
        <option value="Sponsor a Student">Sponsor a Student</option>
        <option value="Contribute to General Corpus">Contribute to General Corpus</option>

          <option value="Mid-Day Meal Program">Mid-Day Meal Program</option>
        <option value="Fund for Honoring Achievers">Fund for Honoring Achievers</option>

          <option value="Contribute to Benevolent Fund">Contribute to Benevolent Fund</option>
        <option value="Infra / Long Term Projects">Infra / Long Term Projects</option>
          <option value="Sports/Culturals">Sports/Culturals</option>
        </select> 
            </div>
          </div>
           <div style="height:10px;"></div>
          <div class="row" >
            <div class="col-lg-3">
             <label class="control-label" style="position:relative; top:7px;">Amount</label>
       
            </div>
            <div class="col-lg-9">
             <input type="text" name="amt" id="amt"  class="form-control2" placeholder="Amount" >
          
      
            </div>
          </div>

           <div style="height:10px;"></div>
          <div class="row" >
            <div class="col-lg-3">
             <label class="control-label" style="position:relative; top:7px;">Name</label>
       
            </div>
            <div class="col-lg-9">
             <input type="text" name="name" id="name"  class="form-control2" placeholder="Your Name" >
          
      
            </div>
          </div>
              <div style="height:10px;"></div>
          <div class="row">
            <div class="col-lg-8">
            <label class="control-label" style="position:relative; top:7px;">Agree to report contribution to large group</label>
             </div>
            <div class="col-lg-4">
                   <input type="radio" id="Y" name="report" value="YES">
         <label>Yes</label> 
         <input type="radio" id="N" name="report" value="NO">
         <label  >No</label><br>
            </div>
          </div>
  
          <div style="height:10px;"></div>
          <div class="row" id="row12">
            <div class="col-lg-6">
             <label class="control-label" style="position:relative; top:7px;">Cheque # and Bank Drawn</label>
       
            </div>
            <div class="col-lg-6">
               <!-- <input type="text" name="tran_id"    class="form-control1" placeholder="Online Confirmation" >
         -->
             <input type="text" name="name2" id="name2"  class="form-control2" placeholder="Cheque # and Bank Drawn" >
         
            </div>
          </div>
       <div style="height:10px;"></div>
          <div class="row" id="row13">
            <div class="col-lg-6">
             <label class="control-label" style="position:relative; top:7px;">Online Payment Confirmation</label>
       
            </div>
            <div class="col-lg-6">
                   <input type="text" name="name1" id="name1"  class="form-control2" placeholder="Confirmation" >
        
      
            </div>
          </div>
        </div>
          
 
 
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Exit</button>
        <button type="submit" class="btn btn-primary btn-lg" name="save"><span class="glyphicon glyphicon-floppy-disk"></span> Submit</a>
   
        </div>
        </form>
      </div>
    </div>
  </div> 

    </div>
     
    </div>
        </p>
           

        </div>
       </div>
     
     
    </div>
  </div>
</section>   
<nav class="pushy pushy-left">
<br/>
<br/>
<br/>
<br/>
<?php include 'footer.php';?>
  
<script src="dashboard/js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="dashboard/js/bootstrap.min.js"></script>
<script type="text/javascript" src="dashboard/js/menu.js"></script>
<script type="text/javascript">

  $(function () {
    var myMarquee = $('#myMarquee')[0]; 
    setTimeout(function() {
        myMarquee.stop();
        setTimeout(function(){
            myMarquee.start();
            run();    
        },10);   
    },10);
});
</script>
<script type="text/javascript">    
function myFunction() {
  var x = document.getElementById("mySelect").value; 
 // alert(x);
  if(x=="Cheque")
  {
      document.getElementById("row12").style.display = "block";
document.getElementById("row13").style.display = "none";
  }
  else if(x=="online")
  {
    document.getElementById("row13").style.display = "block";
     document.getElementById("row12").style.display = "none";
  }

}
function myFunction1() {
 
document.getElementById("row12").style.display = "none";
document.getElementById("row13").style.display = "none";

}

</script>


</body>
</html>
