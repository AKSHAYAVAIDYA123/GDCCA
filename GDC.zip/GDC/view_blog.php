<?php

session_start();
$name='';
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");




// function to connect and execute the query
 
$_SESSION['callFrom'] = "eventadd - Copy.php";

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

 

      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>    


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
            
</head>
<body class="hold-transition skin-blue sidebar-mini">
<style type="text/css">
  
 /* .box-widget1 {
    border: inset;
    position: relative;
    border-block-start-color: black;
}*/

.box-widget1 {
  
    /* border-left-style: groove; */
    position: relative;
    border-block-start-color: black;
    border-left-width: thick;
    border-left-color: white;
}
.user-block .username1 {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: orange;
}

.user-block .username2 {
    display: block;
    font-size: 14px;
    
}

@media (min-width: 768px){
.col-sm-6 {
    width: 100%;
}
}
</style>
 <div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="background-color:white;">
 
    <div style="height:50px;">
      
    </div>
  <div class="" style="margin:auto; padding:auto; width:80%;">
  <span style="font-size:25px; color:blue"><center><strong>NEWS FEED</strong></center></span> 

     <div class="col-md-8 col-sm-6 col-xs-12">
        

          <?php

      // $sql = "SELECT * FROM ( SELECT post.id_post, post.id_user, post.description, post.image, post.createdAt, post.video, post.youtube, users.name, users.profileimage, 'user' as type FROM post INNER JOIN users ON post.id_user=users.id_user WHERE post.type='admin' ) posts ORDER BY posts.createdAt DESC";
      
           $sql = "SELECT * from blog b,users u where b.id_user=u.id_user";
           $result = $conn->query($sql);
               

                if($result->num_rows > 0) {
                  $i = 0;
                  while($row =  $result->fetch_assoc()) {
                    $i++;
                    ?>
                      <!-- Box Comment -->
                      <div class="box box-widget1">
                        <div class="box-header with-border">
                          <div class="user-block">
                          
                            <span class="username1">  <h1><b><?php echo $row['cap']; ?></b></h1></span>
                           <span class="username2"><h4 style="    font-size: 14px;">Posted On <?php echo date('d-M-Y h:i a', strtotime($row['createdAt'])); ?>/ Posted By:<?php echo $row['name']; ?></h4></span>
                         </div>
                        </div>
                        <div class="box-body">
                        <?php
                          if($row['image'] != "") {
                            echo '<img class="img-responsive pad" src="uploads/post/'.$row['image'].'" alt="Photo">';
                          }

                          if($row['video'] != "") {
                            ?>
                              <div class="row">
                                <div class="col-xs-12">
                                  <div class="embed-responsive embed-responsive-16by9">
                                    <video src="admin/uploads/post/<?php echo $row['video']; ?>" controls></video>
                                  </div>
                                </div>
                              </div>
                            <?php
                          }

                          if($row['youtube'] != "") {
                            ?>
                              <div class="row">
                                <div class="col-xs-12">
                                  <div class="embed-responsive embed-responsive-16by9">
                                    <iframe src="https://www.youtube.com/embed/<?php echo $row['youtube']; ?>?rel=0&amp;showinfo=0" class="embed-responsive-item"></iframe>
                                  </div>
                                </div>
                              </div>
                            <?php
                          }
                        ?>
                          
                         

                          <p><h3><?php echo $row['description']; ?></h3></p>
                              <!--  <a href="index.php?did=<?php //echo $row['id_post']; ?>" class="btn btn-default btn-xs" ><i class="fa fa-remove"></i>delete</a>  
                    -->   
                        <!-- /.box-footer -->
                  
                        <!-- /.box-footer -->
                      </div>
                      </div>
                      <!-- /.box -->
                    <?php
                  }
                }
                ?>
        </div>
   </div>

 
   
  </div>
  
 
 
</div>
<!-- insert Model -->
  
        </div>
</div>
   </div>
           <script type="text/javascript">
            if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
            </script>
         </div>

   
</script>       
<footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>  
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>


</body>
</html>


