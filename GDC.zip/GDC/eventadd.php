<?php

session_start();
$name='';
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
$a='';
 if(isset($_POST['search']))
{

    $valueToSearch = $_POST['valueToSearch'];
    $search_result = $conn->query("SELECT * FROM `events` WHERE dat LIKE '%".$valueToSearch."%' or dat LIKE '%".$valueToSearch."%' or  dat = '%".$valueToSearch."%'");
    $search_result1 = $conn->query("SELECT * FROM `events` WHERE dat LIKE '%".$valueToSearch."%' or dat LIKE '%".$valueToSearch."%' or  dat = '%".$valueToSearch."%'");
   
}
 else {

        $search_result = $conn->query("SELECT * FROM `events`");
    $search_result1 = $conn->query("SELECT * FROM `events`");
 
      
    

}
 
 $search_result3 = $conn->query("SELECT * FROM `events`");

// function to connect and execute the query
 
$_SESSION['callFrom'] = "eventadd.php";

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

 

      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>     

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
            
</head>
<body class="hold-transition skin-blue sidebar-mini">

 <div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <div class="container">
   <h3 align="center">Event Informations</h3>
   </div>
    <!-- Main content -->
 
  
         <form action="" method="post">
          <div class="input-group col-xs-4">
            <select name="valueToSearch" class="form-control" id="valueToSearch" required>
<option value="" selected="selected">Date</option>
<?php
$sql = "SELECT DISTINCT dat  FROM events";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["dat"]; ?>"><?php echo $rows["dat"]; ?></option>
<?php } ?>
</select>  
              <span class="input-group-btn">

         





  
            <input type="submit" name="search" value="Filter" class="btn btn-info" id ="printbtn">

               <a class="btn btn-success hidden-print"  id ="printbtn" href="javascript:window.print()"><span class="glyphicon glyphicon-print"> Print</span></a>
 
</span>
            </div>
            <div class="table-responsive">
            <br>
               <?php while($row1 = mysqli_fetch_array($search_result1)):?>

             
     <form  method="POST" action="" class="form-horizontal"  enctype="multipart/form-data" >
   
<input type='hidden' name='didval' value="<?php echo $row1['id_user']; ?>" > 
 
 </form>
             <?php endwhile;?>
<div id="SCREEN_VIEW_CONTAINER">
			<div class="col-md-1"></div>
			<div class="col-md-10">
			  <table class="table table-striped table-bordered table-hover" > 
  
             
                <tr>
                    <th>Name</th>
                    <th>Organizor</th>
                    <th>Date</th>
                    <th>Address</th>
					<th>More</th>
                    <th id ="didval">Action</th>
                    
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['ename'];?></td>
                    <td><?php echo $row['conduct'];?></td>
                    <td><?php echo $row['dat'];?></td>
					
                    <td><?php echo $row['addr'];?></td>
					<td><?php echo $row['info'];?></td>
                       <form  method="POST" action="add-event_user.php" class="form-horizontal"  enctype="multipart/form-data" >
        <?php
       $sql = "SELECT * FROM  event_reg_user where id_user='$_SESSION[id_user]' and id_event='$row[id_event]'";
          $result = $conn->query($sql);

                if($result->num_rows > 0) {
                	 ?>
  

                      <td id ="didval"> <a href="delete-event_user.php?id=<?php echo $row['id_event']; ?>" class="btn btn btn-danger">UnRegister</a>
</td>
           
                	 <?php
                }
                else
                {
                	?>
    <td style="display:none;" id ="didval"><input type="hidden" value="<?php echo $row['id_event'];?>" id ="didval" name="didval"></td>

                      <td id ="didval"> <input type="submit" class="btn btn-info" value="Click Here to Register" name="sub" id ="didval"></td>
               <!--  <td>  <a href="#edit<?php echo $row['id_user']; ?>" data-toggle="modal" class="btn btn-warning" hidden><span class="glyphicon glyphicon-edit"></span> Edit</a>
            </td>-->
 </tr>
        <?php
                }
                ?>
                  
                        </form>
                <!--       	<a href="#edit<?php echo $row['id_event']; ?>" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Edit</a>
						</td>-->

  
 
                        
  
      
      <!-- Modal Footer -->
     
				 
  

                <?php endwhile;?>
                 
          
           <script type="text/javascript">
      

            if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
            </script>

   
            </div>
       
                  </div>
  
 
<!-- CSS for the things we DO NOT want to print (web view) -->

 
 
 <style type="text/css">

            table,tr,th,td
            {
                border: 1px solid black;
            }
            @media print {
    #printbtn {
        display :  none;
    }
    #didval {
        display :  none;
    }
    #valueToSearch {
        display :  none;
    }
     #year {
        display :  none;
    }

@media screen {
  #printSection {
      display: none;
  }
}

 

}

        </style>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>

</body>
</html>


