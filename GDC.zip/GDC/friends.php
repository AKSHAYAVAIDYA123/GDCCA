<?php

session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}

require_once("db.php");

$name = $designation ="";

$sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $designation = $row['address'];
  }
}

if(isset($_GET['did']))
{
  
  $sql1 = "DELETE FROM `friendrequest` WHERE `id_user`='$_GET[did]'";  
  if($conn->query($sql1) === TRUE) {
      header("Location: friends.php");
  }
  else
  {

     header("Location: friends.php");

  }

}

 if(isset($_POST['search']))
{

    $valueToSearch = $_POST['searched'];
  //  $option=$_POST['year']; 
    $search_result=$conn->query("SELECT * FROM friends INNER JOIN users ON friends.id_frienduser=users.id_user WHERE friends.id_user='$_SESSION[id_user]'  AND name LIKE '%".$valueToSearch."%'");

}
 else {

        $search_result=$conn->query("SELECT * FROM friends INNER JOIN users ON friends.id_frienduser=users.id_user WHERE friends.id_user='$_SESSION[id_user]'");

      
    

}

$_SESSION['callFrom'] = "friends.php";

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
           <style type="text/css">
 
 
 .holder {
  max-width: 100%;
  background-color: #ecf0f5;
  display: -webkit-flex;
  display: flex;
  -webkit-flex-direction: row;
  -webkit-flex-wrap: wrap;
  font-size: 12px;
}
.item {
  width: 250px;
  border: 1px solid #ecf0f5;
  height: 350px;
 
  text-align: left;
  color: #000; 
      padding: 24px;
    /* display: flex; */
    align-items: center;
    justify-content: flex-start;
    flex-wrap: wrap;
}

/* When the screen is less than 600px wide, stack the links and the search field vertically instead of horizontally */
@media screen and (max-width: 600px) {
  .topnav a, .topnav input[type=text] {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;
  }
} 


        </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

  <section class="content-header">
      <h1>
        Friends 
      </h1>
    </section>
 <span class="input-group-btn">

  
       <form action="" method="post">
<div class="input-group">
     <input type="text" name="searched" id="searched" placeholder="Search" class="form-control" />
            <input type="submit" name="search" value="Search" class="btn btn-info" id ="printbtn">
    </div>
</span>
   
    <!-- Main content -->
   <section class="content">
      <!-- Info boxes -->
          <div class="holder">
 
        <?php
        $i = 0;
// Establish the output variable
            $sql = "SELECT * FROM friends INNER JOIN users ON friends.id_frienduser=users.id_user WHERE friends.id_user='$_SESSION[id_user]'";
      
           $result = $conn->query($sql);

          if($result->num_rows > 0) { 
           // while($row = $result->fetch_assoc()) {
                while($row = mysqli_fetch_array($search_result)){?>
             
                     
                  <div class="item">
                  <div class="box box-widget widget-user" style="background-color:black;color:white;">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header">
              <h3 class="widget-user-username" style="align:left;"><?php echo $row['name']; ?></h3>
              <h5 class="widget-user-desc"><?php echo $row['city']; ?></h5>
            </div>
            <?php if($row['profileimage'] != "") { ?>
            <div class="widget-user-image">
                <a href="view-profile.php?id=<?php echo $row['id_user']; ?>">
                <img type="image" class="img-circle" src="uploads/profile/<?php echo $row['profileimage']; ?>" alt="User Avatar" height="90px" width="90px"></a>
            </div>
            <?php } else { ?>
            <div class="widget-user-image">
                 <a href="view-profile.php?id=<?php echo $row['id_user']; ?> class="img-circle"">
              <img class="img-circle" src="dist/img/avatar5.png" alt="User Avatar" height="90px" width="90px"></a>
            </div>
            <?php } ?>
            <div class="box-footer" style="height:150px">
              <div class="row">
              <div class="description-block" style="display:none;">
                    <a href="view-profile.php?id=<?php echo $row['id_user']; ?>" class="btn bg-maroon bg-flat">View Profile</a>
                  </div>
                    <div class="col-sm-12 border-right">
                  <?php
                $sql1 = "SELECT * FROM friends WHERE id_user='$_SESSION[id_user]' AND id_frienduser='$row[id_user]'";
                  $result1 = $conn->query($sql1);

                  if($result1->num_rows > 0) { 
                                
                ?>
                  <div class="description-block">
                    <a href="messages.php?id=<?php echo $row['id_user']; ?>" class="btn bg-purple bg-flat">Send Message</a>
                  </div>
                  <?php  }

                  else
                  {
                         ?>
                  
                  <?php  }
                   ?>
                  
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                 
                <!-- /.col -->
                <div class="col-sm-12">
                <?php
                $sql1 = "SELECT * FROM friends WHERE id_user='$_SESSION[id_user]' AND id_frienduser='$row[id_user]'";
                  $result1 = $conn->query($sql1);

                  if($result1->num_rows > 0) { 
                                
                ?>
                  <div class="description-block">
                    <a href="remove-friend.php?id=<?php echo $row['id_user']; ?>" class="btn bg-orange bg-flat">Remove Friend</a>
                  </div>
                <?php 
                  } else {
                    $sql2 = "SELECT * FROM friendrequest WHERE id_user='$row[id_user]' AND id_friend='$_SESSION[id_user]'";
                    $result2 = $conn->query($sql2);

                    if($result2->num_rows == 0) { 

                    $sql3 = "SELECT * FROM friendrequest WHERE id_user = '$_SESSION[id_user]' AND id_friend='$row[id_user]'"; 
                      $result3 = $conn->query($sql3);
                      if($result3->num_rows == 0) { 
                    ?>
                    <div class="description-block">
                      <a href="send-request.php?id=<?php echo $row['id_user']; ?>" class="btn bg-green bg-flat block">Add Friend</a>
                    </div>
                  <?php } else { ?>
                  <div class="description-block">
                      <!--<a href="accept-request.php?id=<?php echo $row['id_user']; ?>" class="btn bg-maroon bg-flat">Accept Friend</a>-->
                      <a href="friend-request.php" class="btn bg-maroon bg-flat">Accept Friend</a>
                  </div>
                  <?php } ?>
                    <?php } else {?>
                    <div class="description-block">
                       
                    
                      <a href="users.php?did=<?php echo $row['id_user']; ?>" class="btn bg-red bg-flat">Cancel Request</a>
                    </div>
                    
                  <?php } } ?>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
          </div> 
           </div>   
        <script>history.pushState({}, "", "")</script>


            <?php       
            }
          }
        ?> 
        </div>
      </div>
      <!-- /.row -->
   </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>

</div>
<!-- ./wrapper -->


<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
