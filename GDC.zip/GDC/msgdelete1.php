<?php
/*
session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");

$result5 = $conn->query("SELECT * FROM messages m,users u where  u.id_user=m.id_to AND u.id_user!='$_SESSION[id_user]' AND Rohan='1'");
 
$name = $designation = $email = $degree = $university = $city = $country = $skills = $aboutme = $profileimage = "";

$sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $designation = $row['designation'];
    $email = $row['email'];
    $degree = $row['degree'];
    $university = $row['university'];
    $city = $row['city'];
    $country = $row['country'];
    $skills= $row['skills'];
    $aboutme = $row['aboutme'];
    $profileimage = $row['profileimage'];
  }
}

}
}
 

*/
include "db.php";
//$_SESSION['callFrom'] = "profile.php";
//$a=$_POST["id1"];
//require_once("db.php");
 //$didvalue=$_POST["didval"];
//echo "$didvalue";
//echo "<script>alert('$didvalue')</script>";
if(isset($_POST["sub"]))
{
  //$a=$_POST["id1"];
  $didvalue=$_POST["didval"];
   //  	echo "hhh";
  	//echo "hai '$_GET[link1]'";
  $sql88 = "UPDATE `messages` SET `Se`='0' where `id_message`='$didvalue'";
 // echo $row['id_message']; 
  //echo $_GET['did11'];
  //echo "klh $didvalue";
  if($conn->query($sql88) == TRUE) {
   header("Location: profile.php");
 // echo "yes";

$retrv = $conn->query("SELECT `Rohan`,`Se` FROM `messages` where `id_message`='$didvalue'");
  if($retrv->num_rows > 0) {
  while($row =  $retrv->fetch_assoc()) {
    if($row['Rohan'] == '0' AND $row['re']=='0')
    {
    //  echo "<br>inside<br>";
      $del = $conn->query("DELETE FROM `messages` WHERE `id_message`='$didvalue'");
      if($del == TRUE) {
      header("Location: profile.php");
 // echo "yes123";
  }
  else
  {
    echo "No123";
    // header("Location: profile.php");

  }
    }
  }
 }



  }
  else
  {
    echo "No";
    // header("Location: profile.php");

  }



}
?>

