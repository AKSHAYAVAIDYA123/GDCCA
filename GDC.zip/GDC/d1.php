<?php

session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
//$_SESSION['callFrom'] = "a1.php";

if(isset($_POST["sub"]))
{
 $didval=$_POST["didval"];  
 // $search_result = $conn->query("SELECT * FROM users WHERE id_user=''");
 // mysqli_query($conn,"delete from usn");
  //  mysqli_query($conn,"UPDATE `users` SET status = 'inactive'  WHERE id_user='$_POST[didval]'");
    //  echo("Error description: " . $conn -> error);
       	$sql = "UPDATE users SET lock_act='1',flag='1' WHERE id_user=$didval";

	if($conn->query($sql) === TRUE) {
		header("Location:user-profile.php");
		exit();
	} else {
		echo $conn->error;
	}
 // header("Location: user-profile.php");
 
}
 
 
?>
 