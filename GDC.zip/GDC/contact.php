<?php
require_once("db.php");
$search_result = $conn->query("SELECT * FROM `conven` order by id desc");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDCAA</title>
 
  <!-- Font Awesome -->
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
 <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">



    <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
     <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
    <!-- Animation -->

    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css">
</head>
<body>
<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}
.holder {
  max-width: 100%;
  background-color: #ecf0f5;
  display: -webkit-flex;
  display: flex;
  -webkit-flex-direction: row;
  -webkit-flex-wrap: wrap;
  font-size: 12px;
}
.item {
    width: 210px;
  border: 1px solid #ecf0f5;
  height: 350px;
 
  text-align: left;
  color: #000; 
     padding: 3px;  
    display: flex;
    align-items: center;
    justify-content: flex-start;
    flex-wrap: wrap;
}

/* When the screen is less than 600px wide, stack the links and the search field vertically instead of horizontally */
@media screen and (max-width: 600px) {
  .topnav a, .topnav input[type=text] {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;
  }
} 
.holder1 {
   background-color: #ecf0f5;
  display: -webkit-flex;
  display: flex;
  -webkit-flex-direction: row;
  -webkit-flex-wrap: wrap;
  font-size: 5px;
}
.item1 {
  
  border: 1px solid #ecf0f5;
  padding: 5px;
  text-align: left;
  color: #000; 
     /* display: flex; */
    align-items: center;
    justify-content: flex-start;
    flex-wrap: wrap;
}
.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}
 
@media only screen and (min-width: 992px){
/*.container1{
   max-width: 100%;
    margin-left: 0px;
}
#a{
  background-color: rgb(255,255,255);
}*/

.img1 {
    display: inline-block;
    margin-top: -25px;
}
}
@media only screen and (max-width: 992px){
/*.container1{
   max-width: 100%;
    margin-left: 0px;
}
#a{
  background-color: rgb(255,255,255);
}*/

.img1 {
    display: inline-block;
    margin-top: -5px;
}
}

</style>
 <div class="wsmobileheader clearfix ">
  <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>
  <span class="smllogo">
     <img src="img/rsz_gdc1.png" alt="gdc" class="img1"/>
  
  </span>
  <!-- <a href="tel:09480812310" class="callusbtn"><i class="fas fa-phone-alt" aria-hidden="true"></i></a> -->
   
</div>
<!-- Mobile Header -->
<div class="wsmainfull clearfix top-menu">
  <div class="wsmainwp clearfix">
    <div class="desktoplogo" class="img">
      <a href="index.php">
        <div class="content">
          <img src="img/rsz_gdc.png" alt="GOVINDA DAS COLLEGE" width="100%" height="100" style="" class="img1">
              <div class="logo-accreditation">
            <h2></h2>
          </div>
        </div>
      </a>
    </div>


    <!--Main Menu HTML Code-->
      <nav class="wsmenu clearfix">
      <ul class="wsmenu-list main-menu">
        <!-- <li class="home-i"><a href="index.php" title="home"> <i class="fas fa-home"></i></a></li> -->
        
      <li><a href="index.php"> About Us</a></li>
        <li><a href="login.php">Membership</a></li>
        <li><a href="archieves.php"> Archieves</a></li>
                 <li><a href="http://www.govindadasacollege.edu.in"> GDC Home Page</a></li>
  
       </ul>
      <ul class="wsmenu-list main-menu-nxt" >
        <li ><a href="#">CONTRIBUTION<span class="wsarrow"></span></a>
          <div class="wsmegamenu clearfix" id="a" >
          <style type="text/css">
          @media only screen and (min-width: 992px){
        .container2{
          max-width: 1960px;
    margin-left: 67px;}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}
}</style>
      <!--    <style type="text/css">
         
    </style>-->
            <div class="container2" style="background-color: rgba(34, 45, 50, 0.8);">
              <div class="row" >
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                       </ul>
                </div>
                 <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">Project Funding </li>
                  <li><a href="do1.php"><h3>General Description</h3></a></li>
             <li><a href="do2.php" style="padding-top: 10px;"><h1>Contribute to General Corpus</h1></a></li>
                    <li><a href="do3.php" style="padding-top: 10px;"><h3>Infra and Long Term Project</h3></a></li>
                      <li><a href="do8.php" style="padding-top: 10px;"><h3>Sports and Culturals</h3></a></li>
               
                  </ul>
                </div>
               <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">Contribute to a Cause</li>
                  <li><a href="do4.php"><h3>Sponsor a Student</h3></a></li>
             <li><a href="do5.php"style="padding-top: 10px;"><h1>Mid-Day Meal Program</h1></a></li>
                    <li><a href="do6.php"style="padding-top: 10px;"><h3>Fund for Honoring Achievers</h3></a></li>
                         <li><a href="do7.php"style="padding-top: 10px;"><h3>Contribute to Benevolent Fund</h3></a></li>
               
                  </ul>
                </div>
                
             
              </div>
            </div>
          </div>
        </li>
        <style type="text/css">
  @media only screen and (max-width: 991px){


  #sub {
    padding: 12px 15px 12px 10px !important;
    font-size: 17px !important;
  }

 
}
</style>
   <li ><a href="blog.php" id="sub"><span class="">   Blogs </span></a>
        
        </li>
         <li><a href="contact.php" id="sub">Contact Us <span class=""></span></a>
         
        </li>

     
       

      </ul>
    </nav>
    <!--Menu HTML Code-->
  </div>
  
</div>
<br>
<br>
<br>
 

<section class="inner-bg">
  <div class="container">
    <div class="row">

       <div class="col-sm-12">
       <div class="inner-content-box">
        <h2 class="wow fadeInDown">Contact Us</h2>
       <center><h4><b>GOVINDA DASA COLLEGE ALUMNI ASSOCIATION(R.)</b></h4>
        <h4>GOVINDA DASA COLLEGE,SURATHKAL-575014</h4>
        <h4><i class="fa fa-envelope" aria-hidden="true"></i>GDCAA2019@gmail.com</h4>
        <h4><i class="fa fa-phone" aria-hidden="true"></i>9481916741,6362659243,9480347065</h4></center> 
 </div>
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">Office bearers</h2>
      
   <p class="wow fadeInDown">
     <section class="content">
      <!-- Info boxes -->
      <style type="text/css">
      td, th {
    padding: 3px;
      }</style>
      <div class="holder">
 
        <?php
        $i = 0;
// Establish the output variable
        $sql = "SELECT * FROM contact_info where type='Office Bearers' ORDER BY order1"; // <>   != 
        
           $result = $conn->query($sql);

          if($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
                  ?>      
                  <div class="item">
                  <style type="text/css">
                      .img-circle1{
                        border-radius: 50%;
                        margin-top: 25px;
                      }
                      .widget-user .widget-user-image>img {
    width: 90px;
    height: 75px;
    border: 3px solid #fff;
}
                     </style>
                  <div class="box box-widget widget-user" style="background-color:black;color:white;">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header" style="height:100px">
              <h4 class="widget-user-desc" style="align:left;"><?php echo $row['name']; ?></h4>
              <h5 class="widget-user-desc"><?php echo $row['Position']; ?></h5>
                <h5 class="widget-user-desc" style="display:none;"><?php echo $row['user_type']; ?></h5>
            </div>
            <?php if($row['url'] != "") { ?>
            <div class="widget-user-image">
                 <img type="image" class="img-circle1" src="uploads/profile/<?php echo $row['url']; ?>" alt="User Avatar" height="90px" width="90px" ></a>
            </div>
            <?php } else { ?>
            <div class="widget-user-image">
               <img class="img-circle1" src="dist/img/avatar5.png" alt="User Avatar" height="90px" width="90px"></a>
            </div>
            <?php } ?>
            <br>
            <div class="box-footer" style="height:150px;    margin-top: 10px;">
              <div class="row">
             
                    <div class="col-sm-12 border-right">
                    <div class="description-block">
                       <a href="#" class="btn bg-purple btn-xs"><?php echo $row['email_id']; ?></a>
                       <a href="#" class="btn bg-purple btn-xs"style=" margin-top: 5px;"><?php echo $row['phone']; ?></a>
               
                  </div>
                 
                  
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                 
                <!-- /.col -->
                <div class="col-sm-12">
             
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
          </div> 
           </div>   
        


            <?php       
            }
          }
        ?> 
        </div>
        <div class="container">
  
</div>


  <h2 class="wow fadeInDown">Convener</h2>
        <p class="wow fadeInDown">
          <?php
                 $query=mysqli_query($conn,"select * from `convenners_description`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php 
                    echo $row['des'];  
                  ?><br>
                
            </td>
            
             
          </tr>
          <?php
        }
 
      ?>
 
    
       
      
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
  <!-- Trigger the modal with a button -->
 <center> <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Click Here to view Convener Committee list</button>
</center>
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Convener Committee list</h4>
        </div>
        <div class="modal-body">
          <p>

            <table class="table table-striped table-bordered table-hover">
            
               
                    <th>Name</th>
                      
                    <th>Place</th>
                     <th>Phone</th>
                   
                       
                 
                

      <!-- populate table from mysql database -->
            <?php while($row = mysqli_fetch_array($search_result)):?>
          
                <tr>
                    <td><?php echo $row['name'];?></td>
                     
                    <td><?php echo $row['place'];?></td>
                     <td><?php echo $row['phone'];?></td>
                   
                         </tr>
                          <?php endwhile;?>
                          </table>
             
          </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
    </p>
          <h2 class="wow fadeInDown">Executive Committee Members</h2>
      <section class="content">
      <!-- Info boxes -->
      <style type="text/css">
      td, th {
    padding: 3px;
}</style>
      <div class="holder1">
        <table class="table table-striped table-bordered table-hover">
        <?php
        $i = 0;
// Establish the output variable
        $sql = "SELECT * FROM contact_info where type!='Office Bearers'"; // <>   != 
        
           $result = $conn->query($sql);

          if($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
                  ?>      
                  <div class="item1" >
                  <style type="text/css">
                      .img-circle1{
                        border-radius: 50%;
                        margin-top: 25px;
                      }
                     </style>
                  <div class="" style="color:black; ">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header" >
           <h5 class="widget-user-username" style="align:left;"><?php echo $row['name']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h5>
            </div>
           
            <br>
          
          </div> 
           </div>   
        


            <?php       
            }
          }
        ?> 
        </div>
      </div>
      <!-- /.row -->
      </section>
      </table>
      </div>
      <!-- /.row -->
      </div>
    </section>
 
  <!-- Modal -->
  
        </p>
           

         <div class="clearfix"></div>
      </div>
       </div>
         <div class="col-sm-0" style="display:none;">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">Events</h2>
        <marquee direction="up"  scrollamount="5" onmouseover="stop()" name="myMarquee" id="myMarquee" onmouseout="start()">
        <p class="wow fadeInDown">
        	<?php
        				 $query=mysqli_query($conn,"select * from `events`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><b>Event Name: </b><?php echo $row['ename']; ?><br></td>
             <td><b>Venue: </b><?php echo $row['addr']; ?><br></td>
              <td><b>Date: </b><?php echo $row['dat']; ?><br></td>
                <td><b>More: </b><?php echo $row['info']; ?><br></td>
                 <td> <?php echo '<a href="'.$row['notice'].'">Click Here</a>';?>
              <br></td>
              <td>------------------------------------------<br></td>
           
             
          </tr>
          <?php
        }
 
      ?>

       
        </p></marquee>
        <div class="clearfix"></div>
      </div>
       </div>
     
    </div>
  </div>
</section>   
<nav class="pushy pushy-left">
<br/>
<br/>
<br/>
<br/>
<script src="dashboard/js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="dashboard/js/bootstrap.min.js"></script>
<script type="text/javascript" src="dashboard/js/menu.js"></script>
<script type="text/javascript">
  $(function () {
    var myMarquee = $('#myMarquee')[0]; 
    setTimeout(function() {
        myMarquee.stop();
        setTimeout(function(){
            myMarquee.start();
            run();    
        },10);   
    },10);
});
</script>

 
<?php include 'footer.php';?>

</body>
</html>
