<?php
	require_once("db.php");
 session_start();
	$id=$_GET['id'];

	$firstname=$_POST['a'];
	$lastname=$_POST['b'];
	$address=$_POST['c'];
 	$ed=$_POST['d'];
	 $more1=$_POST['info'];
	 echo $more1;
 	$sql = "UPDATE events SET ename='$firstname', conduct='$lastname',dat='$address',addr='$ed',info='$more1' WHERE id_event=$id";
	if($conn->query($sql)===TRUE) {
		header("Location: eventadd - Copy.php");
		 
		exit();
	} else {
		 
		header("Location: eventadd - Copy.php");
	}  exit();
 
	
?>