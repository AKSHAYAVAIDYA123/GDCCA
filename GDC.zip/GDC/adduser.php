<?php

session_start();

require_once("db.php");

if(isset($_POST)) {

	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
$address = mysqli_real_escape_string($conn, $_POST['address']);
$dob = mysqli_real_escape_string($conn, $_POST['dob']);

	//$password = base64_encode(strrev(md5($password)));
	$department = mysqli_real_escape_string($conn,$_POST['dept']);
	$passout = mysqli_real_escape_string($conn,  $_POST['yop']);
   $phone = mysqli_real_escape_string($conn,  $_POST['phone']);
   $quali = mysqli_real_escape_string($conn,  $_POST['quali']);
    $mode = mysqli_real_escape_string($conn,  $_POST['mode']);
     $tran_id = mysqli_real_escape_string($conn,  $_POST['tran_id']);
    

 $result =  mysqli_query($conn, "SELECT * FROM users WHERE email='".$email."'");
   if(mysqli_num_rows($result) > 0)
  { echo "<script>
alert('Email ID Already Exist');
window.location.href='login.php';
</script>";
  }
  else
  {

if(strlen($phone)==10)
{
	if(strlen($passout)==4)
	{
			$sql = "INSERT INTO users(name, email,address ,password,name1,degree,city,phone,tran_id,current_qualification,mode_pay,DOB) VALUES ('$name', '$email','$address' ,'$password','$name','$passout','$department','$phone','$tran_id','$quali','$mode','$dob')";
	//$sql2 = "INSERT INTO search(name, email, degree,designation) VALUES ('$name', '$email','$passout','$department')";
	
	if($conn->query($sql)===TRUE) {
		//$_SESSION['registeredSuccessfully'] = true;
		//echo "ok";

   if(!empty($email))
   {
   	require 'class/class.phpmailer.php';
  $output = '';
 
      
  

    
    $mail = new PHPMailer;
    $mail->IsSMTP();                //Sets Mailer to send message using SMTP
    $mail ->Host = "smtp.hostinger.in";
      $mail ->Port = 587; // or 587
      $mail->SMTPAuth = true;             //Sets SMTP authentication. Utilizes the Username and Password variables
  $mail->Username = 'gdcaa@alumnigdc.in';
$mail->Password = 'Gdcaa@2021';
$mail->SetFrom('gdcaa@alumnigdc.in','GDCAA');
     $mail->SMTPSecure = 'TSL';             //Sets connection prefix. Options are "", "ssl" or "tls"
    //$mail->From = 'info@webslesson.com';      //Sets the From email address for the message
    //$mail->FromName = 'Webslesson';         //Sets the From name of the message
    $mail->AddAddress($email, $name); //Adds a "To" address
    $mail->WordWrap = 50;             //Sets word wrapping on the body of the message to a given number of characters
    $mail->IsHTML(true);              //Sets message type to HTML  
 
    //$mail->Subject = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'; //Sets the Subject of the message
    //An HTML or plain text message body
    $mail->Subject = "Thank you for Registering..";
    $mail->Body = nl2br("Thank you for showing interest in becoming the Life member of Govinda dasa College Alumni Association. Your request is sent to Admin for the approval. Use the same credentials used while registering, to login to the social network once the admin approves it.\n\n\n\n\nWith Regards\n Govinda Dasa College Alumni Association(R.)\nGovinda Dasa College,Surathkal-575014\nEmail :GDCAA2019@gmail.com\nContact Number : 9481916741,6362659243,9480347065");
    
    $mail->AltBody = '';

    $result = $mail->Send();            //Send an Email. Return true on success or false on error

    if($result["code"] == '400')
    {
      $output .= html_entity_decode($result['full_error']);
    }

   }
    




  echo "<script>
alert('Your Request has been sent to admin for Appoval.');
window.location.href='login.php';
</script>"; 
		//header('location:login.php');
	} else {
		echo "<script>
alert('Error Please Try Again...');
window.location.href='login.php';
</script>";
			}
	}
	else
	{
echo "<script>
alert('Please Enter Year of Passout in Specified format(1996)...');
window.location.href='login.php';
</script>";
	}	
 
}
else
{
	echo "<script>
alert('Please Enter 10 digit Phone Number');
window.location.href='login.php';
</script>";
}

  }

   

}