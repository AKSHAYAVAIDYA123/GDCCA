<?php

session_start();
 
//unset ($_SESSION["yop"]);
require_once("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDCAA</title>

 <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

            <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
     <!--Main Menu File-->
    <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
      <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
     <link href="dashboard/css/login.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css">
</head>
<body onload="myFunction1()">
<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}

.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}

.text{

  height: 50px;
  width: 490px;
    margin: 0;
    padding: 0 20px;
    vertical-align: middle;
    background: #fff;
    border: 3px solid #fff;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    font-weight: 300;
    line-height: 50px;
    color: #888; 
    color: #888;
    -moz-border-radius: 4px;
    -webkit-border-radius: 4px;
    border-radius: 4px;
    
}

/*@media only screen and (max-width: 991px){
.container1{
   max-width: 100%;
    margin-left: 0px;
        background-color: black;
    margin-left: 15px;
}
#a{
  background-color: rgb(0,0,0);
}

}*/
 @media only screen and (min-width: 992px){
        .container1{
          max-width: 1960px;
    margin-left: 67px;}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}

img{
  margin: -20px;
}

}
 
</style>

    
   <?php include 'menu.php';?>
<br>
<br>
<br>
 
<style type="text/css">
  @media (max-width: 768px){
.inner-content-box {
    margin: 0;
    margin-left: 15px;
    width: 90%;
}
}
</style>
<section class="inner-bg">
  <div class="container">
    <div class="row">
    <div class="col-sm-6">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">Appeal to Alumni</h2>
        <p class="wow fadeInDown">   
          <?php
                 $query=mysqli_query($conn,"select * from `appeal`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php 
                  if ($row['appeal']=="Objectives"||$row['appeal']=="Alumni Outreach") {
                    # code...
                    ?>
                    <b><?php echo $row['appeal']; ?></b>
                    
                <br>
                <?php
                  }
                  else
                  {
                        echo $row['appeal']; ?>
                <br>
                <?php
                  }
                  ?>
                
            </td>
            
             
          </tr>
          <?php
        }
 
      ?>

       
      

        </p>

        <div class=""></div>
        <div class="clearfix"></div>
      </div>

    </div>
    <div class="col-sm-6">
<div class="container">
      <div class="row">
      <div class="col-md-12">
        <div class="panel panel-login">
          <div class="panel-heading">
            <div class="row">
              <div class="col-xs-4">
                <a href="#" class="active" id="login-form-link">Member Login</a>
              </div>
              <div class="col-xs-4">
                <a href="#" id="register-form-link">Register As a Life Member</a>
              </div>
              <div class="col-xs-4">
                <a href="#" id="as-form-link">Register As a Associative Member</a>
              </div>
            </div>
            <hr>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-lg-12">

       <form id="as-form" method="post" action="adduser1.php"  style="display: none;">
          <h4 style="color:red;"><b>'Applicable only for GDC Staff'</b></h4>

    <div class="form-group has-feedback">
      <h4 style="color:red;"><b>'Fields marked with * are mandatory'</b></h4>

        <input type="text"  id="Name" name="Name" placeholder="Full Name*" class="form-first-name form-control1"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email*" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>

      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password*" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
         <div class="form-group">
                    <input type="text" name="dob" id="dob" class="form-control1" placeholder="DOB"  onfocus="(this.type='date')">
                    </div>

         <div class="form-group">
                    <input type="text" name="address" id="address" class="form-control1" placeholder="Address*"  required>
                    </div>

           
         <div class="form-group">
                    <input type="text" name="phone" id="phone" class="form-control1" placeholder="phone*"  required>
                    </div>

   <div class="form-group">
                    <input type="text" name="dept" id="dept"  class="form-control1" placeholder="Department*"required>
                  </div>
  <select id="mySelect" onchange="myFunction()"  class="form-control1" name="mySelect" required>
  <option value="">Please Select Any One *</option>
  <option value="work">In Service</option>
  <option value="retired">Retired from Service</option>
 
</select>
 

                    <div id="row1">
                    <div class="form-group">
                    <input type="text" name="yop" id="yop"  class="form-control1" placeholder="Year of Retire from GDC*" >
                  </div>

                 
                  </div>

      <div class="row">
    
        <div class="col-xs-12">

          <button type="submit" class="btn btn-info btn-lg button1">Register</button>          
        </div>
        <!-- /.col -->
      </div>
      <div class="row">
        <div class="col-xs-12">
            <span id="loginError" class="color-red hide-me">Invalid Email/Password!</span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>

    </form>


      <form id="login-form" method="post" action="checklogin.php" target="_blank">
      <div class="form-group has-feedback">
        <input type="text"  id="email" name="email" placeholder="Registered Email-ID/Contact Number" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
    
        <div class="col-xs-12">

          <button type="submit" class="btn btn-info button1"formtarget="_blank">Sign In</button>   
                   <a href="#" data-toggle="modal" data-target="#donate" style="color:red;"><h4>Forgot Password</h4></a>
            </div>
            </div>

      <div class="row">
        <div class="col-xs-12">
            <span id="loginError" class="color-red hide-me">Invalid Email/Password!</span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form>
    
                  <form id="register-form" action="adduser.php" method="post" style="display: none;">
                      <h4 style="color:red;"><b>'Fields marked with * are mandatory'</b></h4>

      <div class="form-group has-feedback">
        <input type="text" id="name" name="name" class="form-control1" placeholder="Full name*"required>
        <span id="nameError" class="color-red hide-me">Name Error</span>
      </div>


        <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email*" class="form-first-name form-control"  required>
             <span id="emailError" class="color-red hide-me">Email Error</span>
        <span id="emailExistsError" class="color-red hide-me">Email Error</span>
      </div>
       
                  <div class="form-group">
                    <input type="password" name="password" id="password" class="form-control1" placeholder="Password*" required>
                  </div>
                 
          <div class="form-group">
                    <input type="text" name="quali" id="quali"  class="form-control1" placeholder="Enter Your Qualification*"required>
                  </div>


                  <div class="form-group">
                    <input type="text" name="address" id="address" class="form-control1" placeholder="Address*" required>
                    </div>



                  <div class="form-group">
                    <input type="text" name="dob" id="dob" class="form-control1" placeholder="DOB"  onfocus="(this.type='date')">
                    </div>
                
                    <div class="form-group">
                    <input type="text" name="phone" id="phone"  class="form-control1" placeholder="Contact Number *"required>
                  </div>
         

                    <div class="form-group">
                    <input type="text" name="yop" id="yop"  class="form-control1" placeholder="Year of Passout(Eg.1996) from GDC*"required>
                  </div>


                    <div class="form-group">

                       <select name="dept" class="form-control1" id="dept" required>
<option value="" selected="selected">Select Qualification from Govinda dasa College *</option>
<?php
$sql = "SELECT DISTINCT dept FROM usn  where dept !='' order by dept";

$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["dept"]; ?>"><?php echo $rows["dept"]; ?></option>
<?php } ?>
</select>       


                    </div>

                    <div class="form-group">
                     <select name="mode" class="form-control1" id="mode" required>
<option value="" selected="selected">Mode of Life Membership Fee *</option>   

<option value="Online Transfer">Online Transfer (Please Enter Transaction Id in Transaction Information field)</option>
<option value="Check Payment">Check Payment(Please Enter Cheque Number in Transaction Information field)</option>
<option value="Cash Payment">Cash Payment</option> 
                    </div>


                    <div class="form-group">
                    <input type="text" name="tran_id" id="tran_id"  class="form-control1" placeholder="Enter Transaction Information*">
                  </div>

                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-12 ">
                        <button id="sbtBtn" type="submit" class="btn btn-info btn-lg" style="width: 100%;
    font-size: 15px;">Register</button>
                 </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


    </div>
     
    </div>
  </div>
</section>   
<style type="text/css">
  
 .a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
} 
</style>
<br>
<br>
<br>
<?php include_once 'footer.php';?>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/menu.js"></script>

<script type="text/javascript">
  $(function() {

    $('#login-form-link').click(function(e) {
    $("#login-form").delay(100).fadeIn(100);
    $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $("#as-form").fadeOut(100);
    $('#as-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });
  $('#register-form-link').click(function(e) {
    $("#register-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
    $('#login-form-link').removeClass('active');
     $("#as-form").fadeOut(100);
    $('#as-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });


    $('#as-form-link').click(function(e) {
    $("#as-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
      $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $('#login-form-link').removeClass('active');

    $(this).addClass('active');
    e.preventDefault();
  });

    //onchange radio
   $('#working').click(function(e) {
    $("#working").delay(100).fadeIn(100);
      $('#a').removeClass('active');
    $('#a').removeClass('active');
    console.log('s');
    $(this).addClass('active');
    e.preventDefault();
  });

});

</script>

   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
<div class="modal fade" id="donate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Password Reset</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form class="form-horizontal" action="send-password.php"  method="post" enctype="multipart/form-data">
        <style type="text/css">
         
          .form-control1 {
     display: block;
    width: 100%;
    height: calc(1.5em + .75rem + 2px);
    padding: .375rem .75rem;
    /* font-size: 1rem; */
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: .25rem;
      
          }</style>
      <div class="modal-body">
   <div class="card">
         <div class="card-body">
          <div class="form-group">
          <input type="text" class="form-control1" name="email" placeholder="Enter the Registerd Mail ID"> 
      </div>
               
          </div>
        </div>
      </div>

     
         <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Send</a>
        </form>
        </div>
        </form>
      </div>
    </div>
    </div>
        </div>
        <!-- /.col -->
      </div>

<script src="dashboard/js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="dashboard/js/bootstrap.min.js"></script>
<script type="text/javascript" src="dashboard/js/menu.js"></script>

<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
<script>
  $('#registerForm').on("submit", function(e) {
    e.preventDefault();

    var errors = false;

    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

    //Minimum 8 Characters with at least 1 letter and 1 number
    var passwordReg = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
 
    if($("#cpassword").val() === $("#password").val()) {
      $("#cpasswordError").hide();
    } else {
        $("#cpasswordError").text("Password Mismatch");
        $("#cpasswordError").show();
        errors = true;
    }

    if(errors == false) {
      if(emailReg.test($("#email").val())) {
        $("#emailError").hide();
        $.post("checkemail.php", { email: $("#email").val()}).done(function(data) {
          var result = $.trim(data);
          if(result == "Error") {
            $("#emailExistsError").text("This email is already registered with us. Choose Different Email.");
            $("#emailExistsError").show();
          } else {
            $("#emailExistsError").hide();
            adduser();
          } 
        });
      } else {
          $("#emailError").text("Email should be of format example@example.com");
          $("#emailError").show();
      }
    }
    



  });
</script>
<!--<script>
  function adduser() {
     $.post("adduser1.php", $("#registerForm").serialize() ).done(function(data) {
        var result = $.trim(data);
        if(result == "ok") {
          window.location.href = "login.php";
        }
      });
  }
</script>-->
<script>
  $(function() {
    $("#registeredSuccessfully:visible").fadeOut(8000);
  });
</script>
 <script type="text/javascript"> 
function myFunction() {
  var x = document.getElementById("mySelect").value; 
 // alert(x);
  if(x=="work")
  {
document.getElementById("row1").style.display = "none";
  }
  else if(x=="retired")
  {
    document.getElementById("row1").style.display = "block";
  }

}
function myFunction1() {
 
document.getElementById("row1").style.display = "none";

}

</script>
<style type="text/css">
  .row1{
    position: absolute;
  }
</style>

</body>
</html>
