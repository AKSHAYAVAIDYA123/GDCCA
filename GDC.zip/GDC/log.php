<?php

session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");


 $sql7 = "SELECT * FROM friends WHERE id_user='$_SESSION[id_user]'";
$result7 = $conn->query($sql7);

//if($result7->num_rows >= 0) { 
  while($row7 = $result7->fetch_assoc()) {
    $a=$row7['id_frienduser']; 
  } 





//$result511 = $conn->query("SELECT * FROM messages m,users u where  u.id_user=m.id_from AND u.id_user!='$_SESSION[id_user]' AND Rohan='1'");
$result511 = $conn->query("SELECT * FROM messages m,users u where id_to=id_user AND id_from='$_SESSION[id_user]' AND Rohan='1'");
$name = $designation = $email = $degree = $university = $city = $country = $skills = $aboutme = $profileimage = "";
$result512 = $conn->query("SELECT * FROM messages m,users u where id_from=id_user AND id_to='$_SESSION[id_user]' AND Se='1'");
$name = $designation = $email = $degree = $university = $city = $country = $skills = $aboutme = $profileimage = "";

$sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $designation = $row['city'];
    $email = $row['email'];
    $degree = $row['degree'];
    $university = $row['university'];
    $city = $row['city'];
    $country = $row['address'];
    $skills= $row['skills'];
    $aboutme = $row['aboutme'];
    $profileimage = $row['profileimage'];
  }
}

$sql12 = "SELECT * FROM contact  WHERE id_user='$_SESSION[id_user]'";
$result12 = $conn->query($sql12);

if($result12->num_rows > 0) { 
  while($row12 = $result12->fetch_assoc()) {
    $name1 = $row12['name'];
    $id1 = $row12['id_user'];
    $email1 = $row12['email'];
    $phone1 = $row12['phone'];
    $fb1 = $row12['fb'];
    $insta1 = $row12['insta'];
    $linkd1 = $row12['linkd'];
    
  }
}


 
if(isset($_GET['did']))
{
  
 $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]' and id_user='$_SESSION[id_user]'";  
 //  $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]'";  
 // $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]' ";  
 
  if($conn->query($sql1) === TRUE) {

     
      ?>
<script type="text/javascript">
  alert('Your post was succesfully deleted');
</script>

      <?php
       header("Location: profile.php");
  }
  else
  {

     header("Location: profile.php");

  }

}


if(isset($_GET['id']))
{
  
 $sql1 = "DELETE FROM `messages` WHERE `id_from`='$_GET[id]' ";  
 //  $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]'";  
 // $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]' ";  
 
  if($conn->query($sql1) === TRUE) {

     
      ?>
<script type="text/javascript">
  alert('Your post was succesfully deleted');
</script>

      <?php
       header("Location: profile.php");
  }
  else
  {

     header("Location: profile.php");

  }

}

if(isset($_GET['did']))
{
  
  $sql1 = "DELETE FROM `post` WHERE `id_post`='$_GET[did]' AND id_user='$_SESSION[id_user]'";  
  if($conn->query($sql1) === TRUE) {
      header("Location: profile.php");
  }
  else
  {

     header("Location: profile.php");

  }

}


 

$_SESSION['callFrom'] = "log.php";

?>

<!DOCTYPE html>
<html>
<head>
<div class="wrapper">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>WENAMITAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css"> -->
  <!-- jvectormap -->
  <!-- <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css"> -->
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <link rel="stylesheet" href="dist/css/custom.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content-header">
      <h1>
      Activity Logs
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
            <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['profileimage'] != '') {
                    echo '<img src="uploads/profile/'.$row['profileimage'].'" class="profile-user-img img-responsive img-circle" alt="User Image">';
                  } else {
                     echo '<img src="dist/img/avatar5.png" class="profile-user-img img-responsive img-circle" alt="User Image">';
                  }
                }
                ?>

              <h3 class="profile-username text-center"><?php echo $name; ?></h3>

              <p class="text-muted text-center"><?php echo $designation; ?></p>

             

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab"><b>Post</b></a></li>
               <li><a href="#contact" data-toggle="tab"><b>Posting Comment</b></a></li>
                <li><a href="#activity1" data-toggle="tab"><b>Receiving Comment</b></a></li>
                <li><a href="#log" data-toggle="tab"><b>Sent Messages</b></a></li>
              <li><a href="#log1" data-toggle="tab"><b>Received Messages</b></a></li>
              
              <li><a href="#FC1" data-toggle="tab"><b>FriendsTimeLine Post</b></a></li>
              <li><a href="#Fpost2" data-toggle="tab"><b>FriendsReceivingPost</b></a></li>
               <li><a href="#Fpost1" data-toggle="tab"><b>FriendsTimeLine Comment</b></a></li>
              <li><a href="#FC2" data-toggle="tab"><b>FriendsReceivingComment</b></a></li>
            </ul>
 
          <div class="tab-content">
<div class="tab-pane" id="Fpost1">
      <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>Comment</th>
        <th>Description</th>
          <th>Date</th>
        <th>Action</th>
         </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"select c.id_comment,c.comment,c.createdAt,u.name from `friends_comments` c,friend_posts p,users u where c.id_post=p.id_post and p.id_user=u.id_user and c.id_user='$_SESSION[id_user]'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['comment']; ?></td> 
            <td>You will be comment <?php echo $row['name'];?> post</td>
<td><?php echo $row['createdAt']; ?></td> 
         
            <td id ="printbtn">
         <!--      <a href="#del4<?php echo $row['id_comment']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
       -->
             <A href="comment-del2.php?didval=<?php echo $row['id_comment']; ?>" class="btn btn-danger"> Delete </A>
  
       <?php include('button3.php'); ?>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
    </div>
 
 
<div class="tab-pane" id="FC2">
      <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>Comment</th>
        <th>Description</th>
          <th>Date</th>
        <th>Action</th>
         </thead>
      <tbody>
      <?php
        
   $query=mysqli_query($conn,"select c.id_comment,c.comment,c.createdAt,u.name from `friends_comments` c,friend_posts p,users u where c.id_post=p.id_post and c.id_user=u.id_user and p.id_user='$_SESSION[id_user]'");
     
          while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['comment']; ?></td> 
            <td>You will be comment <?php echo $row['name'];?> post</td>
<td><?php echo $row['createdAt']; ?></td> 
         
            <td id ="printbtn">
      <!--         <a href="#del4<?php echo $row['id_comment']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
     -->
        <A href="comment-del2.php?didval=<?php echo $row['id_comment']; ?>" class="btn btn-danger"> Delete </A>
         
     <?php include('button3.php'); ?>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
    </div>
   

  <div class="tab-pane" id="contact">
                <!-- The timeline -->
                                         <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>Comment</th>
        <th>Description</th>
          <th>Date</th>
        <th>Action</th>
         </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"select c.id_comment,c.comment,c.createdAt,u.name from `comments` c,post p,users u where c.id_post=p.id_post and p.id_user=u.id_user and c.id_user='$_SESSION[id_user]'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['comment']; ?></td> 
            <td>You will be comment <?php echo $row['name'];?> post</td>
<td><?php echo $row['createdAt']; ?></td> 
       
          
        <td id ="printbtn">
               <a href="#del1<?php echo $row['id_comment']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
             <?php include('button3.php'); ?>
            </td>
               </td>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
    
              </div>


<div class="tab-pane" id="activity1">
                <!-- The timeline -->
                                         <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>Comment</th>
        <th>Description</th>
          <th>Date</th>
        <th>Action</th>
         </thead>
      <tbody>
      <?php
        
 
         $query=mysqli_query($conn,"select c.id_comment,c.comment,c.createdAt,u.name from `comments` c,post p,users u where c.id_post=p.id_post and p.id_user=u.id_user and p.id_user='$_SESSION[id_user]'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['comment']; ?></td> 
            <td>You will be comment <?php echo $row['name'];?> post</td>
<td><?php echo $row['createdAt']; ?></td> 
       
           <td id ="printbtn">
            <A href="comment-del1.php?didval=<?php echo $row['id_comment']; ?>" class="btn btn-danger"> Delete </A>
               </td>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
    
              </div>


              <div class="active tab-pane" id="activity">
                <div class="box box-info">
                  <div class="box-header with-border">
                   <!-- <h3 class="box-title">Wall</h3>-->
                    <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>Post</th>
        <th>Image</th>
        <th>Youtube</th>
        <th>Date</th>
         
        <th id ="printbtn">Action</th>
      </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"select * from `post` where id_user='$_SESSION[id_user]'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['image']; ?></td>
            <td><?php echo $row['youtube'];?></td>
            <td><?php echo $row['createdAt']; ?></td>
         
            <td id ="printbtn">
               <a href="#del<?php echo $row['id_post']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
             <?php include('button3.php'); ?>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
                  </div>
                  <!-- /.box-header -->
                  <!-- form start -->
                  

                </div>

                
                </div>


             

                       <div class="tab-pane" id="log">
                        <div class="box box-info">
                  <div class="box-header with-border">
                   <center><h3 class="box-title"> <b>Sent Messages Details</b></h3></center> 
                  </div>
                  <br>
                              <div class="box-body box-profile">
        
     <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>TO</th>
        <th>Message</th>
      <!--  <th>Date</th>-->
        <th>Delete</th>
        </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"SELECT * FROM messages m,users u where id_to=id_user AND id_from='$_SESSION[id_user]' AND Rohan='1'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['message']; ?></td>
            <!--<td><?php //echo $row['createdAt'];?></td>-->
                <td>
   <form  method="POST" action="msgdelete.php" class="form-horizontal"  enctype="multipart/form-data" >
   <input type='hidden' name='didval' value="<?php echo $row['id_message']; ?>" > 

<input type="submit" name="sub" class="btn btn-danger" value="Delete">
               </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
            </div>
       
                  </div>
                  </div>




                       <div class="tab-pane" id="FC1">
                        <div class="box box-info">
                  <div class="box-header with-border">
                   <center><h3 class="box-title"> <b>Sent FriendsTimeLinePost Details</b></h3></center> 
                   </div>
                           <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>Friend</th>
        <th>Post</th>
        <th>Image</th>
        <th>Youtube</th>
        <th>Date</th>
         
        <th id ="printbtn">Action</th>
      </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"select u.name,f.id_post,f.description,f.image,f.youtube,f.createdAt from `friend_posts`f,users u where f.id_friend=u.id_user and f.id_user='$_SESSION[id_user]'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
             <td><?php echo $row['name']; ?></td>  
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['image']; ?></td>
            <td><?php echo $row['youtube'];?></td>
            <td><?php echo $row['createdAt']; ?></td>
         
            <td id ="printbtn">
               <a href="#del2<?php echo $row['id_post']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
             <?php include('button3.php'); ?>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
                   </div>
                   </div>
      
                    <div class="tab-pane" id="Fpost2">
                        <div class="box box-info">
                  <div class="box-header with-border">
                   <center><h3 class="box-title"> <b>Receive FriendsTimeLinePost Details</b></h3></center> 
                   </div>
                           <table class="table table-striped table-bordered table-hover">
      <thead>
        <th>From</th>
        <th>Post</th>
        <th>Image</th>
        <th>Youtube</th>
        <th>Date</th>
         
        <th id ="printbtn">Action</th>
      </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"select * from `friend_posts`f,users u where f.id_user=u.id_user and f.id_friend='$_SESSION[id_user]'");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
             <td><?php echo $row['name']; ?></td>  
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['image']; ?></td>
            <td><?php echo $row['youtube'];?></td>
            <td><?php echo $row['createdAt']; ?></td>
         
            <td id ="printbtn">
               <a href="#del2<?php echo $row['id_post']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
             <?php include('button3.php'); ?>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
                   </div>
                   </div>
      






              <div class="tab-pane" id="log1">
                        <div class="box box-info">
                  <div class="box-header with-border">
                   <center><h3 class="box-title"><b>Received Messages Details</b></h3></center> 
                  </div>
                  <br>
                              <div class="box-body box-profile">
                    
          <!--  <form name="frmUser" method="post" action="">       -->    
            <?php if(isset($message)) { echo $message; } ?>           
           <table class="table table">
            <tr>
           <th ><span ><font size="4">From</font></span> </th>
            
            <th><span ><font size="4">Message</font></span></th>
           <!----- <th><span ><font size="4">Date</font></span></th>-->
            <th><span ><font size="4">Delete</font></span></th>
            </tr>
            <?php
            $i=0;
                   if (isset($_POST['name'])) {
    $name = $_POST['name'];
}
            while($row1 = mysqli_fetch_array($result512)) {
            if($i%2==0)
            $classname="evenRow";
            else
            $classname="oddRow";

            ?>
           
            <tr class="<?php if(isset($classname)) echo $classname;?>">
            <td><?php echo $row1["name"]; ?></td>
           
            <!-- <td><?php //echo $_SESSION['name']; ?></td>-->
           
               
            <td><?php echo $row1["message"]; ?></td>
              
    <td>
   <form  method="POST" action="msgdelete1.php" class="form-horizontal"  enctype="multipart/form-data" >
  <!-- <?php echo "$row1[id_message]"; ?>-->
<input type='hidden' name='didval' value="<?php echo $row1['id_message']; ?>" > 

<input type="submit" name="sub" class="btn btn-danger" value="Delete">
               </td>
            </tr></form>
<!--<script type="text/javascript">
  function fun()
  {
    alert("<?php //echo $row1['id_message'] ?>");
  }

</script>
 -->  <?php 
 
    ?>
  <!--  </form>
-->
               </td>
            </tr>


            <?php
            $i++;

            }
           // echo "hhhhh '$_GET[did11]' ";
  
            ?>
            </table>
 
            </form>




            </div>
                  </div>

</form>
              
           
              </div>













              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                
           
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="settings">
                
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->

   



          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
    <div class="modal fade" id="del1<?php echo $row['id_comment']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Delete</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($conn,"select * from comments where id_comment='".$row['id_comment']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5><center><strong><?php echo $row['id_comment']; ?></strong>Comment Will be Deleted?...</center></h5> 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="delete-post.php?id=<?php echo $row['id_comment']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
    </form>
    </td>
    </tr>
    </tbody>
    </table>
    </div>
<footer class="footer">
    <div>
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2016-2017 <a href="#">Social Network</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

<script>
  $("#addLike").on("click", function() {
    var id_post = $(this).attr("data-id");
    $.post("addlike.php", {id:id_post}).done(function(data) {
      var result = $.trim(data);
      if(result == "ok") {
        location.reload();
      }
    });
  });
</script>
<script>
  function checkInput(e, t) {
    //13 means enter
    if(e.keyCode === 13) {
      var id_post = $(t).attr("data-id");
      var type = $(t).attr("data-type");
      var comment = $(t).val();
      var user = '<?php echo $_SESSION["id_user"]; ?>';
      if(type=="friend") {
        $.post("add-friends-comments.php", {id:id_post, comment:comment, user:user}).done(function(data) {
          var result = $.trim(data);
          if(result == "ok") {
            location.reload();
          }
        });
      } else {
        $.post("addcomment.php", {id:id_post, comment:comment, user:user}).done(function(data) {
          var result = $.trim(data);
          if(result == "ok") {
            location.reload();
          }
        });
      }
      return false;
    }
  }
</script>

</body>
</html>
