<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname='';
    $add='';
    
  if (isset($_POST['mySelect1'])) {
   $firstname=$_POST['mySelect1'];

}
 if (isset($_POST['name1'])) {
   $add=$_POST['name1'];
 //   echo $add;

}
    $lastname=$_POST['mySelect'];//PaymentType

    $address=$_POST['amt'];

    $bday=$_POST['report'];
    
       $name=$_POST['name'];

     $add=$_POST['name1'];
       $name2=$_POST['name2'];
   // echo $add;
       if($lastname=='Cheque')
       {
            if (empty($name2)) {
                echo "<script>
alert('Please Enter Cheque and Drawn Details');
window.location.href='do3.php';
</script>";
            }
            else
            {
                $sql = "INSERT INTO donation_info(purpose,payment_type,amount,Agree,confirmation,name,chq_info) VALUES ('$firstname', '$lastname', '$address', '$bday', '$add', '$name', '$name2')";
   
    if($conn->query($sql)===TRUE) {
        //$_SESSION['registeredSuccessfully'] = true;
        //echo "ok";
 echo "<script>
alert(' Thank you for your contribution towards $firstname');
window.location.href='do3.php';
</script>";
        //header('location:login.php');
    } else {
    echo "<script>
 alert('Error Please Try Again...');
 window.location.href='do3.php';
 </script>";
         echo("Error description: " . $conn -> error);
            }
            }
       }
       else
       {
if (empty($add)) {
                echo "<script>
alert('Please Enter Online Transaction Details');
window.location.href='do3.php';
</script>";
            }
            else
            {
                $sql = "INSERT INTO donation_info(purpose,payment_type,amount,Agree,confirmation,name,chq_info) VALUES ('$firstname', '$lastname', '$address', '$bday', '$add', '$name', '$name2')";
   
    if($conn->query($sql)===TRUE) {
        //$_SESSION['registeredSuccessfully'] = true;
        //echo "ok";
 echo "<script>
alert(' Thank you for your contribution towards $firstname');
window.location.href='do3.php';
</script>";
        //header('location:login.php');
    } else {
    echo "<script>
 alert('Error Please Try Again...');
 window.location.href='do3.php';
 </script>";
         echo("Error description: " . $conn -> error);
            }
            } 
       }
 
 
    //Purpose/*/
  
       
	 ?>