<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from appeal where id='$id'");
	header('location:appeal_us_db.php');

?>