<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['ename'];
	$lastname=$_POST['conduct'];
	$address=$_POST['about'];
 
 	  $add=$_POST['address'];
      $order=$_POST['order'];
 	$a=$_SESSION['id_user'];
 	$b=$_SESSION['name'];
 	     $filename = $_FILES['myfile']['name'];

    // destination of the file on the server
    $destination = 'uploads/profile/' . $filename;

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (in_array($extension, ['zip', 'pdf', 'docx'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['myfile']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO contact_info (name,Position,email_id,phone,url,type,order1) VALUES ('$firstname','$lastname','$address','$add','$filename','Office Bearers','$order')";
            if (mysqli_query($conn, $sql)) {
              //  echo "File uploaded successfully";
            		header('location:add-office-br.php');
						exit();
            }
        } else {
          echo "Not uploaded because of error #".$_FILES["myfile"]["error"];
          
        }
           echo "Failed to upload file.";
           header('location:add-office-br.php');
                        exit();

    }
	 ?>