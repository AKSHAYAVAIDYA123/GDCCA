<?php
	require_once("db.php");
 session_start();
	$id=$_GET['id'];

	$firstname=$_POST['a'];
 
 	$sql = "UPDATE convenners_description SET des='$firstname' WHERE id=$id";
	if($conn->query($sql)===TRUE) {
		header("Location: con-des.php");
		 
		exit();
	} else {
		 
		header("Location: con-des.php");
	}  exit();
 
	
?>