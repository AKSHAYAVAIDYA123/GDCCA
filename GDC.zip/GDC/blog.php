<?php
require_once("db.php");

?>
<?php

session_start();
 
//unset ($_SESSION["yop"]);
require_once("db.php");
$search_result = $conn->query("SELECT * FROM `donation_info` where AGREE='YES' and ap='0' and lock_bt='1' order by id desc");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDCAA</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
   <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
     <!--Main Menu File-->
    <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
     <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
     <link href="dashboard/css/login.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css"
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
     <!--Main Menu File-->
  
</head>
<body onload="myFunction1()">

<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}

.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}

</style>
<style type="text/css">
  
 /* .box-widget1 {
    border: inset;
    position: relative;
    border-block-start-color: black;
}*/

.box-widget1 {
  
    /* border-left-style: groove; */
    position: relative;
    border-block-start-color: black;
    border-left-width: thick;
    border-left-color: white;
}
.user-block .username1 {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: orange;
}

.user-block .username2 {
    display: block;
    font-size: 14px;
    
}

@media (min-width: 768px){
.col-sm-6 {
    width: 100%;
}
}
</style>
</style>
 <?php include 'menu2.php';?>
    <!--Menu HTML Code-->
  </div>
  
</div>
<br>
<br>
<br>
 

<section class="inner-bg">
  <div class="container">
    <div class="row">

       <div class="col-sm-12">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">BLOGS</h2>


  </div> 
  <style type="text/css">


@media only screen and (min-width: 600px) {

  .inner-content-box1 {
    margin: 0px 20px;
    padding: 20px;
    width: 100%;
    background: rgba(255,255,255,1);
    position: relative;
    margin-top: -50px;
}}
@media only screen and (max-width: 600px) {

.inner-content-box1 {
    /* margin: 0px 20px; */
    padding: 20px;
    width: 100%;
    background: rgba(255,255,255,1);
    position: relative;
    margin-top: -50px;
}}</style>
  <div class="inner-content-box1 col-xs-12">
        

          <?php

      // $sql = "SELECT * FROM ( SELECT post.id_post, post.id_user, post.description, post.image, post.createdAt, post.video, post.youtube, users.name, users.profileimage, 'user' as type FROM post INNER JOIN users ON post.id_user=users.id_user WHERE post.type='admin' ) posts ORDER BY posts.createdAt DESC";
       $results_per_page = 2;  
  
    //find the total number of results stored in the database  
    $query = "select *from blog";  
    $result = mysqli_query($conn, $query);  
    $number_of_result = mysqli_num_rows($result);  
  
    //determine the total number of pages available  
    $number_of_page = ceil ($number_of_result / $results_per_page);  
  
    //determine which page number visitor is currently on  
    if (!isset ($_GET['page']) ) {  
        $page = 1;  
    } else {  
        $page = $_GET['page'];  
    }  
  
    //determine the sql LIMIT starting number for the results on the displaying page  
    $page_first_result = ($page-1) * $results_per_page;  
  
           $sql = "SELECT u.name,b.type,b.id_post,b.id_user,b.cap,b.description,b.image,b.video,b.file,b.youtube,b.createdAt from blog b,users u where b.id_user=u.id_user and b.status='Approved' ORDER BY b.createdAt desc LIMIT " . $page_first_result . ',' . $results_per_page; 
           $result = $conn->query($sql);
               

                if($result->num_rows > 0) {
                  $i = 0;
                  while($row =  $result->fetch_assoc()) {
                    $i++;
                    ?>
                      <!-- Box Comment -->
                      <div class="box box-widget1">
                        <div class="box-header with-border">
                          <div class="user-block">
                          
                            <span class="username1">  <h1><b><?php echo $row['cap']; ?></b></h1></span>
                                <span class="username2"><h4 style="    font-size: 14px;">Posted On <?php echo date('d-M-Y', strtotime($row['createdAt'])); ?>/ Posted By:<?php echo $row['name']; ?></h4></span>
            
                   <!--        <span class="username2"><h4 style="    font-size: 14px;">Posted On <?php //echo date('d-M-Y h:i a', strtotime($row['createdAt'])); ?>/ Posted By:<?php echo $row['name']; ?></h4></span>
                   -->      </div>
                        </div>
                        <div class="box-body">
                        <?php
                          if($row['image'] != "") {
                            echo '<img class="img-responsive pad" src="uploads/post/'.$row['image'].'" alt="Photo">';
                          }

                          if($row['video'] != "") {
                            ?>
                              <div class="row">
                                <div class="col-xs-12">
                                  <div class="embed-responsive embed-responsive-16by9">
                                    <video src="admin/uploads/post/<?php echo $row['video']; ?>" controls></video>
                                  </div>
                                </div>
                              </div>
                            <?php
                          }

                          if($row['youtube'] != "") {
                            ?>  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
                              <div class="row">
                                <div class="col-xs-12">
                                  <div class="">
                                    <iframe src="https://www.youtube.com/embed/<?php echo $row['youtube']; ?>?rel=0&amp;showinfo=0" class="embed-responsive-item"></iframe>
                                  </div>
                                </div>
                              </div>
                            <?php
                          }
                        ?>
                          
                         <style type="text/css">
                         .a2 {
    color: brown;
    margin-left: 15px;
    background-color: transparent;
    text-decoration: none;
}</style>

                          <p><h3>
                          <?php 
  if($row['youtube'] == "") {
                            
                          echo $row['description'];
}
  if($row['file'] != "") {
                            ?>  
                              <div class="row">
                                <?php echo '<a class="a2" href="'.$row['file'].'">Click Here to View</a>';?>
                              </div>
                            <?php
                          }
                        ?>

                           </h3></p>
                         <!--       <a href="index.php?did=<?php //echo $row['id_post']; ?>" class="btn btn-default btn-xs" ><i class="fa fa-remove"></i>delete</a>  
                    -->   
                        <!-- /.box-footer -->
                  
                        <!-- /.box-footer -->
                      </div>
                      </div>
                      <style type="text/css">
                      .a1{

                        font-size: 18px;
                        }</style>
                      <!-- /.box -->
                    <?php
                  }
                }
                ?><div style="text-align:center"> <?php

for($page = 1; $page<= $number_of_page; $page++) {  
        echo '<a class="a1" href = "blog.php?page=' . $page . '">' . $page . ' </a>';  
    }  
    ?></div>
        </div>

    </div>
      
    </div>
        </p>
           

        </div>
       </div>
     
     
    </div>
  </div>
</section>   
 <br/>
<br/>
<br/>
<br/>
<br/>
<br/>
 <style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #e7e625;
   color: white;
  
}
</style>
 <div class="footer">
 <div class="container-fluid pad0 copy-bg">
      <div class="copy">
        <div class="container">
          <div class="row">
            <div class="col-md-6 wow fadeInDown"> <b>© 2020-21 GDCAA. All Rights Reserved</b></div>
            <div class="col-md-6 wow fadeInDown">
               <div class="pull-right"> <b> Developed By | Anantha Murthy ,Alumni(2004),GDC,Surathkal</b> </div>
              </div>
          </div>
        </div>
      </div>
  </div>
</div>
<script src="dashboard/js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="dashboard/js/bootstrap.min.js"></script>
<script type="text/javascript" src="dashboard/js/menu.js"></script>


</body>
</html>
