<?php

session_start();

require_once("db.php");

if(isset($_POST)) {

 
		
	$sub = mysqli_real_escape_string($conn, $_POST['name1']);
	$phone1 = mysqli_real_escape_string($conn, $_POST['msg']);
	 
	$sql = "UPDATE users SET name1='$sub', msg='$phone1'";

	if($conn->query($sql) === TRUE) {
		header("Location: email.php");
		exit();
	} else {
		echo $conn->error;
	}


	}
	 