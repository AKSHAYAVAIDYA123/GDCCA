<?php

session_start();

require_once("db.php");

if(isset($_POST)) {

 
		
	$status = mysqli_real_escape_string($conn, $_POST['sta']);
	$id = mysqli_real_escape_string($conn, $_POST['id_user']);
	echo $status;
	 
	 $sql = "UPDATE blog SET status='$status' where  id_post='$id'";

	if($conn->query($sql) === TRUE) {
		header("Location: blog_approval.php");
		exit();
	} else {
		echo $conn->error;
	}


	}
	 