<?php

session_start();

require_once("db.php");
if ($_SERVER['REQUEST_METHOD'] != 'POST') { 
	    echo "<script>
window.location.href='add_blog_content.php';
</script>";

}
if(isset($_POST)) {



	$title = mysqli_real_escape_string($conn, $_POST['cap']);

	$uploadOk = true; 

	$folder_dir = "uploads/post/";

	$base = basename($_FILES['image']['name']); // mydocs/images/myprofile.jpg -> myprofile.jpg

	$imageFileType = pathinfo($base, PATHINFO_EXTENSION); // .png .jpg

	$file = "";

	if(file_exists($_FILES['image']['tmp_name'])) {
		if($imageFileType == 'jpg' || $imageFileType == 'png') {
			if($_FILES['image']['size'] < 5000000) {
					
				$file = uniqid() . "." . $imageFileType;  

				$filename = $folder_dir . $file;  

				move_uploaded_file($_FILES['image']['tmp_name'], $filename);
			} else {
				$_SESSION['uploadError'] = "Wrong Size. Max Size Allowed: 5MB";
				$uploadOk = false;
			}
		} else {
			$_SESSION['uploadError'] = "Wrong Format. Only jpg or png allowed.";
			$uploadOk = false;
		}
	}


	if($uploadOk == false) {
	      echo "<script>
alert('Error');
window.location.href='add_blog_content.php';
</script>";
		 

	}
     if ($title != '')
     {

echo $title;
	$sql = " INSERT INTO blog (type,id_user,cap,description, image, video,youtube,createdAt) VALUES ('blog','$_SESSION[id_user]','$title', '','$file', '','',now())";
	if($conn->query($sql)===TRUE) {
	header("Location: "  . $_SESSION['callFrom']);
		 
			  
}
else
{
	 
 echo 'Error: '. $conn->error;
}
}
else
{
	  echo "<script>
alert('Please Enter Title of the Image');
window.location.href='add_blog_content.php';
</script>";
}
}
 