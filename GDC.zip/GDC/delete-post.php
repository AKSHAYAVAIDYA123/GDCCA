<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from post where id_post='$id'");
	header('location:log.php');

?>