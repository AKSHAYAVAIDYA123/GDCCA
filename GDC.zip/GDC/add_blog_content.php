<?php

session_start();
$name='';
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");

// function to connect and execute the query
 
$_SESSION['callFrom'] = "add_blog_content.php";

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

 

      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>     

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
            
</head>
<body class="hold-transition skin-blue sidebar-mini">

 <div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <div class="container">
   <h3 align="left">Blog News Feed</h3>
   </div>
    <!-- Main content -->
 
      <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-8 col-sm-6 col-xs-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Wall</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" action="blog-addpost.php" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="cap" placeholder="Caption?" name="cap" style="margin-bottom: 5px;"></textarea>
           
                   <textarea class="form-control" name="description" placeholder="What's on your mind?" name="message"></textarea>
                                 <input type="file" name="image" class="form-control-file"  accept=".png, .jpg, .jpeg" style="display:none;" />  
       
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
             
                   <button type="submit" class="btn btn-info">Post</button> 
  
                <div class="pull-right margin-r-5">
                  
                       
 <a href="#feedback-modal1" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-plus"></span> Add New Image</a>
                       
 <a href="#feedback-modal" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-plus"></span> Add Youtube</a>

               
                </div>
                  <div class="pull-right margin-r-5">
                  
                       
 <a href="#myModal" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-plus"></span> Add Article</a>
   

                </div>
 
                <div>
                  <?php if(isset($_SESSION['uploadError'])) { ?>
                    <p><?php echo $_SESSION['uploadError']; ?></p>
                  <?php unset($_SESSION['uploadError']); } ?>
                </div>
              </div>

               <!-- /.box-footer -->
   
   <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                   <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Video</h4></center>
                </div>
                
                 <div class="modal-body">
        <div class="container-fluid">
                <form class="form-horizontal" action="blog-addpost.php" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                 <center>
                    <input type="file" name="video" class="form-control-file" accept=".jpg,.mp4"   />  
                 </center>
                </div>
              </div>
                </div>
                        <div class="box-footer">
               
                  </div>
          </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
         </form>
                </form>

                </div>
                </div>

                </div>
                </div>
              <div id="feedback-modal" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">       
        <div class="modal-header">
          <a class="close" data-dismiss="modal">×</a>
          <h3>Copy and Paste Youtube link</h3>
        </div>        
        <div class="modal-body"> 
         <form class="form-horizontal" action="blog-addpost2.php" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="cap" placeholder="Caption?" name="cap" style="margin-bottom: 5px;"></textarea>
           
                   <textarea class="form-control" name="description" placeholder="Paste Youtube Link Here....." name="message"></textarea>
                  </div>
                </div>
              </div>

        </div>      
        <div class="modal-footer">
          <button class="btn btn-success" id="submit"  onclick="javascript:window.location.reload()">Send</button>
          <a href="#" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button></a>
        </div>
      </div>
      </form>
    </div>
  </div>
     
          
          </div>

                 
          
            </div>
       
                  </div>

                     <div class="modal fade" id="feedback-modal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Image</h4></center>
                </div>
                <div class="modal-body">
        <div class="container-fluid">
                <form class="form-horizontal" action="blog-addpost1.php" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                          <input type="text" class="form-control" name="cap" placeholder="Caption?" name="cap" style="margin-bottom: 5px;"></textarea>
           
             
                    <input type="file" name="image" class="form-control-file"  accept=".png, .jpg, .jpeg"/>  
                  
                </div>
              </div>
              <!-- /.box-body -->
          
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
      
                </div>
 
            </div>
        </div>

</form>

          </div>
          <!-- /.nav-tabs-custom -->
        </div>

        <!-- /.col -->
      </div>
   <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                   <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Upload Article</h4></center>
                </div>
                
                 <div class="modal-body">
        <div class="container-fluid">
              <form method="POST" action="add-blog-doc.php" enctype="multipart/form-data">
          <div class="row">
           
            <div class="col-lg-10">
              <input type="text" class="form-control" name="ename" placeholder="Enter a Title" required>
            </div>
          </div>
          
          <div style="height:10px;"></div>
          <div class="row">
            
            <div class="col-lg-10">
              <input type="file" name="myfile"> <br>
      
            </div>
          </div>
              
        </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary" name="save"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
        </form>
                </div>
                </div>
</div>
                </div>
                </div>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>

</body>
</html>


