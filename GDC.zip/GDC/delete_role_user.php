<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from users where id_user='$id'");
	header('location:user_role_admin.php');

?>