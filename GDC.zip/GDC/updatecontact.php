<?php

session_start();

require_once("db.php");

if(isset($_POST)) {

 
		
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$phone1 = mysqli_real_escape_string($conn, $_POST['phone1']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$fb = mysqli_real_escape_string($conn, $_POST['fb']);
	$insta = mysqli_real_escape_string($conn, $_POST['insta']);
	$linkd = mysqli_real_escape_string($conn, $_POST['linkd']);

	$sql = "UPDATE contact SET name='$name', phone='$phone1', email='$email', fb='$fb', insta='$insta', linkd='$linkd' WHERE id_user='$_SESSION[id_user]'";

	if($conn->query($sql) === TRUE) {
		header("Location: profile.php");
		exit();
	} else {
		echo $conn->error;
	}


	}
	 