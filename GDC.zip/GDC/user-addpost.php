<?php

session_start();

require_once("db.php");
if ($_SERVER['REQUEST_METHOD'] != 'POST') { 
	    echo "<script>
window.location.href='user-index.php';
</script>";

}
if(isset($_POST)) {

	 preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $_POST['description'], $match);

	if($match[1] == "") {
		$youtube = "";
	} else {
		$youtube = $match[1];
	} 


	$description = mysqli_real_escape_string($conn, $_POST['description']);

	$uploadOk = true; 

	$folder_dir = "uploads/post/";

	$base = basename($_FILES['image']['name']); // mydocs/images/myprofile.jpg -> myprofile.jpg

	$imageFileType = pathinfo($base, PATHINFO_EXTENSION); // .png .jpg

	$file = "";

	if(file_exists($_FILES['image']['tmp_name'])) {
		if($imageFileType == 'jpg' || $imageFileType == 'png') {
			if($_FILES['image']['size'] < 5000000) {
					
				$file = uniqid() . "." . $imageFileType;  

				$filename = $folder_dir . $file;  

				move_uploaded_file($_FILES['image']['tmp_name'], $filename);
			} else {
				$_SESSION['uploadError'] = "Wrong Size. Max Size Allowed: 5MB";
				$uploadOk = false;
			}
		} else {
			$_SESSION['uploadError'] = "Wrong Format. Only jpg or png allowed.";
			$uploadOk = false;
		}
	}

	$uploadOk1 = true; 

	$base = basename($_FILES['video']['name']); 

	$videoFileType = pathinfo($base, PATHINFO_EXTENSION); // .png .jpg

	$file1 = "";

	if(file_exists($_FILES['video']['tmp_name'])) {
		if($videoFileType == 'mp4'||$videoFileType == 'MP4') {
			if($_FILES['video']['size'] < 25000000) {
					
				$file1 = uniqid() . "." . $videoFileType;  

				$filename = $folder_dir . $file1;  

				move_uploaded_file($_FILES['video']['tmp_name'], $filename);
			} else {
				$_SESSION['uploadError'] = "Wrong Size. Max Size Allowed: 25MB";
				$uploadOk = false;
			}
		} else {
			$_SESSION['uploadError'] = "Wrong Format. Only mp4 allowed.";
			$uploadOk = false;
		}
	}

	if($uploadOk == false || $uploadOk1 == false) {
	      echo "<script>
alert('Error');
window.location.href='user-index.php';
</script>";
		 

	}
     if ($description != ''||$file != ''||$file1 != ''||$youtube != '')
     {


	$sql = " INSERT INTO post (type,id_user, description, image, video,youtube) VALUES ('admin','17', '$description', '$file', '$file1','$youtube')";
	if($conn->query($sql)===TRUE) {
		header("Location: "  . $_SESSION['callFrom']);
		 
			     $sql = "SELECT * FROM users  WHERE id_user <> '$_SESSION[id_user]'";
$result = $conn->query($sql);
require 'class/class.phpmailer.php';
  $output = '';
 foreach ($result as $data) {
      ?>
  <!--      <td><?php echo $data['name'];?></td><br>
         <td><?php echo $data['email'];?></td><br>
      
    
      <td><?php echo $data['msg'];?></td><br>
      <td><?php echo $data['name1'];?></td><br>-->
      <?php 
      
  

    
    $mail = new PHPMailer;
    $mail->IsSMTP();                //Sets Mailer to send message using SMTP
   $mail ->Host = "smtp.hostinger.in";
   $mail ->Port = 587; // or 587
      $mail->SMTPAuth = true;             //Sets SMTP authentication. Utilizes the Username and Password variables
$mail ->Username = "gdcaa@alumnigdc.in";
   $mail ->Password = "Gdcaa@2021";
   $mail ->SetFrom("gdcaa@alumnigdc.in","Admin GDCAA");
//$mail->SetFrom('alumni@nmamit-alumni.in','A');
		 $mail->SMTPSecure = 'TLS';	          //Sets connection prefix. Options are "", "ssl" or "tls"
    //$mail->From = 'info@webslesson.com';      //Sets the From email address for the message
    //$mail->FromName = 'Webslesson';         //Sets the From name of the message
    $mail->AddAddress($data["email"], $data["name"]); //Adds a "To" address
    $mail->WordWrap = 50;             //Sets word wrapping on the body of the message to a given number of characters
    $mail->IsHTML(true);              //Sets message type to HTML
    //$mail->Subject = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'; //Sets the Subject of the message
    //An HTML or plain text message body
    $mail->Subject = "From GDCAA ";
   $mail->Body =   nl2br("Dear Alumni, you have a new message from Admin, GDCAA. Please login to https://alumnigdc.in/login.php to view the new post.\n\n\n\n\nWith Regards\n Govinda Dasa College Alumni Association(R.)\nGovinda Dasa College,Surathkal-575014\nEmail :GDCAA2019@gmail.com\nContact Number : 9481916741,6362659243,9480347065");
    
    $mail->AltBody = '';

    $result = $mail->Send();            //Send an Email. Return true on success or false on error

    if($result["code"] == '400')
    {
      $output .= html_entity_decode($result['full_error']);
    }

    }
		
		
		exit();
	} else {
	  echo "<script>
alert('Error');
window.location.href='user-index.php';
</script>";
	}
	   }
	   else
	   {
	    echo "<script>
alert('Error');
window.location.href='user-index.php';
</script>";
 	   }
}
 