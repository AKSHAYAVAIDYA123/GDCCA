<?php

session_start();

require_once("db.php");
if ($_SERVER['REQUEST_METHOD'] != 'POST') { 
	    echo "<script>
window.location.href='add_blog_content.php';
</script>";

}
if(isset($_POST)) {
$youtube = "";
	 preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $_POST['description'], $match);
   if(isset($match[1])) { 
   
	if($match[1] == "") {
		$youtube = "";;
	} else {
		$youtube = $match[1];
	}

}


	$description = mysqli_real_escape_string($conn, $_POST['description']);

	$title = mysqli_real_escape_string($conn, $_POST['cap']);

	
     if ($title != '')
     {

//echo $title;
	$sql = " INSERT INTO blog (type,id_user,cap,description, image, video,youtube,createdAt) VALUES ('blog','$_SESSION[id_user]','$title', '$description','', '','$youtube',now())";
	if($conn->query($sql)===TRUE) {
	header("Location: "  . $_SESSION['callFrom']);
		 
			  
}
else
{
 echo 'Error: '. $conn->error;
}
}
else
{
	 echo "<script>
alert('Please Enter Caption');
window.location.href='add_blog_content.php';
</script>";
}
}
 