<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['ename'];
	$lastname=$_POST['conduct'];
	$address=$_POST['about'];
 
 	$bday=$_POST['bday'];
	 $add=$_POST['address'];
 	$a=$_SESSION['id_user'];
 	$b=$_SESSION['name'];
 	     $filename = $_FILES['myfile']['name'];

    // destination of the file on the server
    $destination = 'uploads/' . $filename;

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['myfile']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO events (id_user,ename,conduct,dat,addr,info,notice) VALUES ('$_SESSION[id_user]','$firstname','$lastname','$bday','$add','$address','$destination')";
            if (mysqli_query($conn, $sql)) {
              //  echo "File uploaded successfully";
            		header("Location: "  . $_SESSION['callFrom']);
						exit();
            }
        } else {
            echo "Failed to upload file.";
        }
    }
	 ?>