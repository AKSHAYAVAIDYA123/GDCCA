<style type="text/css">
  
 .a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
} 
</style>
<footer>
  
    <div class="">
<style type="text/css">
  .footer-list1 h3  {
  
  }
</style>
  
   
  </div>
  </div>
  <div class="container-fluid pad0 copy-bg">
      <div class="copy">
        <div class="container">
          <div class="row">
            <div class="col-md-6 wow fadeInDown"> <b>© 2020-21 GDCAA. All Rights Reserved</b></div>
            <div class="col-md-6 wow fadeInDown">
              <div class="pull-right"> <b>Developed By | Anantha Murthy ,Alumni GDCAA Surathkal |9743702262</b> </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</footer>
