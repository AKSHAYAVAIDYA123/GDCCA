<?php
session_start();

require_once("db.php");
  include('db.php');
 $a= $_POST["caption"];
if($_FILES["upload_file"]["name"] != '')
{
 $data = explode(".", $_FILES["upload_file"]["name"]);
 $extension = $data[1];
 $allowed_extension = array("jpg", "png", "gif");
 if(in_array($extension, $allowed_extension))
 {
  $new_file_name = rand() . '.' . $extension;
  $path = $_POST["hidden_folder_name"] . '/' . $new_file_name;
  //echo $path;

  if(move_uploaded_file($_FILES["upload_file"]["tmp_name"], $path))
  {
          $sql = "INSERT INTO images(image,caption) VALUES ('$path', '$a')";
   
    if($conn->query($sql)===TRUE) {
   echo 'Image Uploaded';
    }
  }
  else
  {
   echo 'There is some error';
   ?>

    <script type="text/javascript">alert('There is some error');</script>

   <?php
  }
 }
 else
 {
  echo 'Invalid Image File';
   ?>

    <script type="text/javascript">alert('Invalid Image File');</script>

   <?php
 }
}
else
{
 echo 'Please Select Image';
}
?>