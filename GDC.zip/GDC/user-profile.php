<?php

session_start();
$name='';
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");


 

 if(isset($_POST['search']))
{

    $valueToSearch = $_POST['valueToSearch'];
    if($valueToSearch=="ALL")
    {
  $option=$_POST['year'];
  //   $search_result = $conn->query("SELECT * FROM `users` WHERE name LIKE '%".$valueToSearch."%' or designation LIKE '%".$valueToSearch."%' or  email = '%".$valueToSearch."%'");
   //$search_result1 = $conn->query("SELECT * FROM `users` WHERE name LIKE '%".$valueToSearch."%' or designation LIKE '%".$valueToSearch."%' or  email = '%".$valueToSearch."%'");
    $search_result=$conn->query("SELECT * FROM `users` where user_Type='$_POST[year]'");
  $search_result1= $conn->query("SELECT * FROM `users` where user_Type='$_POST[year]'");
 
    }
    else
    {
        $option=$_POST['year'];
  //   $search_result = $conn->query("SELECT * FROM `users` WHERE name LIKE '%".$valueToSearch."%' or designation LIKE '%".$valueToSearch."%' or  email = '%".$valueToSearch."%'");
   //$search_result1 = $conn->query("SELECT * FROM `users` WHERE name LIKE '%".$valueToSearch."%' or designation LIKE '%".$valueToSearch."%' or  email = '%".$valueToSearch."%'");
    $search_result=$conn->query("SELECT * FROM `users` where user_Type='$_POST[year]' and city='$_POST[valueToSearch]'");
  $search_result1= $conn->query("SELECT * FROM `users` where user_Type='$_POST[year]' and city='$_POST[valueToSearch]'");
 
    }
  
}
 else {

        $search_result = $conn->query("SELECT * FROM `users` where flag='0'");
    $search_result1 = $conn->query("SELECT * FROM `users` where flag='0'");
 
      
    

}
 
 $search_result3 = $conn->query("SELECT * FROM `users`");

// function to connect and execute the query
 
$_SESSION['callFrom'] = "user-profile.php";

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
            
</head>
<body class="hold-transition skin-blue sidebar-mini">

 <div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <div class="container">
   <h3 align="center">User Informations</h3>
   </div>
    <!-- Main content -->
  <style type="text/css">

            table,tr,th,td
            {
                border: 1px solid black;
            }
            @media print {
    #printbtn {
        display :  none;
    }
    #didval {
        display :  none;
    }
    #valueToSearch {
        display :  none;
    }
     #year {
        display :  none;
    }

@media screen {
  #printSection {
      display: none;
  }
}

 

}

        </style>
  
         <form action="" method="post">
          <div class="input-group col-xs-4">
            <select name="valueToSearch" class="form-control" id="valueToSearch" required>
<option value="" selected="selected">STREAM</option>
<option value="ALL">ALL</option>
<?php
$sql = "SELECT DISTINCT city FROM users";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));

while( $rows = mysqli_fetch_assoc($resultset) ) {
?>

<option value="<?php echo $rows["city"]; ?>"><?php echo $rows["city"]; ?></option>
<?php } ?>
</select>  
              <span class="input-group-btn">

                <select name="year" class="form-control" id="year" required>>
<option value="" selected="selected">Select User Type</option>
 <?php
$sql = "SELECT DISTINCT user_Type FROM users where id_user!='17'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["user_Type"]; ?>"><?php echo $rows["user_Type"]; ?></option>
<?php } ?>
</select>  




           
  
            <input type="submit" name="search" value="Filter" class="btn btn-info" id ="printbtn">

               <a class="btn btn-success hidden-print"  id ="printbtn" href="javascript:window.print()"><span class="glyphicon glyphicon-print"> Print</span></a>
 
</span>
            </div>
            <div class="table-responsive">
            <br>
               <?php while($row1 = mysqli_fetch_array($search_result1)):?>

             
     <form  method="POST" action="" class="form-horizontal"  enctype="multipart/form-data" >
   
<input type='hidden' name='didval' value="<?php echo $row1['id_user']; ?>" > 
 
 </form>
             <?php endwhile;?>

            <table class="table table-striped table-bordered table-hover">
            
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                     
                    <th>Qualification of GDCC</th>
                     <th>Education</th>
                      <th>Address</th>
                        <th>User_type</th>
                         <th>Mode of Payment</th>
                          <th>Tran_ID</th>
                    <th>Year of Passout</th>
                    <th>Current User Status</th>
                     <th>Recipt Number</th>
                    <th>Change status to</th>
                    <th id ="didval" style="display:none;">Action</th>
                    
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['email'];?></td>
                   
                    <td><?php echo $row['city'];?></td>
                     <td><?php echo $row['current_qualification'];?></td>
                     <td><?php echo $row['address'];?></td>
                      <td><?php echo $row['user_type'];?></td>
                       <td><?php echo $row['mode_pay'];?></td>
                        <td><?php echo $row['tran_id'];?></td>
                    

                    <td><?php echo $row['degree'];?></td>
<style type="text/css">
 
.btn1{
    display: inline-block;
    padding: 6px 12px;
    width: 75px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
</style>

                     <?php if($row['lock_act']=="0")
                              {

                                ?>
 
                      
<td>  Approve  </td>
                     <?php

                                }
                                else
                                {
                                    ?>
                                    
                               <td>    Reject </td>

                                    <?php
                                  
                                }

?>
     <?php if($row['flag']=="0")
                            {
                              if($row['lock_act']=="1")
                              {
  ?>
                                  <td>No Recipt</td>
<td>  <form  method="POST" action="d1.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval" name="didval">
             <input type="submit" class="btn1 btn-danger" value="Reject" name="sub" id ="didval" onclick="return confirm('Are you sure you want to Reject?')"> 
             </form>
     <form  method="POST" action="d21.php" class="form-horizontal"  enctype="multipart/form-data" >
           <input type="text" name="recipt" id="recipt" placeholder="Enter Recipt Number before Approve"required>
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval1" name="didval1">
             <input type="submit" class="btn1 btn-success" value="Approve" name="sub1" id ="didval" onclick="return confirm('Are you sure you want to Approve')"> 
             </form>          </td>
                                  <?php
                              }
                              else
                              {
  ?>
                                  <td>Recipt</td>
<td>  <form  method="POST" action="d1.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval" name="didval">
             <input type="submit" class="btn1 btn-danger" value="Reject" name="sub" id ="didval" onclick="return confirm('Are you sure you want to Reject?')"> 
             </form>
     <form  method="POST" action="d2.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval1" name="didval1">
             <input type="submit" class="btn1 btn-success" value="Approve" name="sub1" id ="didval" onclick="return confirm('Are you sure you want to Approve')"> 
             </form>          </td>
                                  <?php
                              }
                            }
                            else
                            {
                              if($row['lock_act']=="1")
                              {
                                  ?>
                                  <td>Recipt</td>
<td>  <form  method="POST" action="d1.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval" name="didval">
             <input type="submit" class="btn1 btn-danger" value="Reject" name="sub" id ="didval" onclick="return confirm('Are you sure you want to Reject?')"> 
             </form>
     <form  method="POST" action="d2.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval1" name="didval1">
             <input type="submit" class="btn1 btn-success" value="Approve" name="sub1" id ="didval" onclick="return confirm('Are you sure you want to Approve')"> 
             </form>          </td>
                                  <?php
                              }
                              else
                              {
                                ?>
<td>Recipt</td>
<td>  <form  method="POST" action="d1.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval" name="didval">
             <input type="submit" class="btn1 btn-danger" value="Reject" name="sub" id ="didval" onclick="return confirm('Are you sure you want to Reject?')"> 
             </form>
     <form  method="POST" action="d2.php" class="form-horizontal"  enctype="multipart/form-data" >
             <input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval1" name="didval1">
             <input type="submit" class="btn1 btn-success" value="Approve" name="sub1" id ="didval" onclick="return confirm('Are you sure you want to Approve')"> 
             </form>          </td>
                                <?php

                              }
                            }
   
                  ?>
             
                <form  method="POST" action="a1.php" class="form-horizontal"  enctype="multipart/form-data" >
                    <td style="display:none;" id ="didval"><input type="hidden" value="<?php echo $row['id_user'];?>" id ="didval" name="didval"></td>
                      <td id ="didval"  style="display:none;"> <input type="submit" class="btn btn-info" value="View" name="sub" id ="didval"></td>
               <!--  <td>  <a href="#edit<?php echo $row['id_user']; ?>" data-toggle="modal" class="btn btn-warning" hidden><span class="glyphicon glyphicon-edit"></span> Edit</a>
            </td>-->
         
 <!-- <style type="text/css">
  @media screen {
  #printSection {
      display: none;
  }
}

@media print {
  body * {
    visibility:hidden;
  }
  #printSection, #printSection * {
    visibility:visible;
  }
  #printSection {
    position:absolute;
    left:0;
    top:0;
  }
}
</style>-->

                        </form>
                        <div id="printThis">
<div id="edit<?php echo $row['id_user']; ?>"  class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  
  <div class="modal-dialog modal-lg">
    
    <!-- Modal Content: begins -->
    <div class="modal-content">
      
      <!-- Modal Header -->
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="gridSystemModalLabel">Your Headings</h4>
      </div>
    
      <!-- Modal Body -->  
      <div class="modal-body">
        <div class="body-message">
       <?php  
       $a=$row['id_user'];
       $search_result3 = $conn->query("SELECT * FROM users where id_user='$a'");

       
    
 while($row = mysqli_fetch_array($search_result3))

  echo $row['name']."<br>".$row['id_user']; 
          
 ?>
        </div>
      </div>
    
      <!-- Modal Footer -->
      <div class="modal-footer">
       <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
      <button id="btnPrint" type="button" class="btn btn-default">Print</button>
      </div>
    
    </div>
    <!-- Modal Content: ends -->
    
  </div>
    </div>
</div>

   
                <?php endwhile;?>
                 
          
           <script type="text/javascript">
      

            if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
            </script>
           
            </div>
       
                  </div>
  
 
<!-- CSS for the things we DO NOT want to print (web view) -->

<script type="text/javascript">
  document.getElementById("btnPrint").onclick = function () {
    printElement(document.getElementById("printThis"));
}

function printElement(elem) {
    var domClone = elem.cloneNode(true);
    
    var $printSection = document.getElementById("printSection");
    
    if (!$printSection) {
        var $printSection = document.createElement("div");
        $printSection.id = "printSection";
        document.body.appendChild($printSection);
    }
    
    $printSection.innerHTML = "";
    $printSection.appendChild(domClone);
    window.print();
}
</script>
<style type="text/css" media="screen">

   #PRINT_VIEW{
      display: none;
   }
.other_web_layout{
        background-color:#E0E0E0;
    }
</style> 
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>
</body>
</html>


