<?php
session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
//$_SESSION['callFrom'] = "a1.php";

 if(isset($_POST["sub1"]))
{

 $didval=$_POST["didval"];  
 // $search_result = $conn->query("SELECT * FROM users WHERE id_user=''");
 // mysqli_query($conn,"delete from usn");
     	$sql = "UPDATE donation_info SET ap='0',lock_bt='1',updated_at=now() WHERE id=$didval";

  if($conn->query($sql) === TRUE) {
    header("Location:donation.php");
    exit();
  } else {
    echo $conn->error;
  }
 
}

?>