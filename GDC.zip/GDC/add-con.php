<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['ename'];
	$lastname=$_POST['conduct'];
	 
 	  $add=$_POST['address'];
    echo $add;
    
    $sql = "INSERT INTO conven (name,place,phone) VALUES ('$firstname','$lastname','$add')";
            if (mysqli_query($conn, $sql)) {
              //  echo "File uploaded successfully";
                header('location:add-conven.php');
            exit();
            }
            else
            {
                   header('location:add-conven.php');
            exit();
            } 
     
	 ?>