<?php
	require_once("db.php");
 session_start();
	$id=$_GET['id'];

	$firstname=$_POST['a'];
 
 	$sql = "UPDATE dashboard SET about_us='$firstname' WHERE id=$id";
	if($conn->query($sql)===TRUE) {
		header("Location: about_us_db.php");
		 
		exit();
	} else {
		 
		header("Location: about_us_db.php");
	}  exit();
 
	
?>