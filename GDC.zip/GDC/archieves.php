<?php
require_once("db.php");

$sql = "SELECT * FROM caption";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $capt = $row['cap'];
   
  }
}
$result511 = $conn->query("SELECT * FROM caption");

?>
<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDCAA</title>
   
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
     <!--Main Menu File-->
    <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
     <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css">
        <link rel="stylesheet" href="gallery/style.css">
    <script src="gallery/jquery-3.4.1.min.js"></script>
    <script src="gallery/script.js"></script>
    
     <script src="dist1/js/lightbox-plus-jquery.min.js"></script>
     
 <link rel="stylesheet" href="dist1/css/lightbox.min.css">
</head>
<body>
<!-- Mobile Header -->
<style type="text/css">
  <style type="text/css">
  *{
  margin:0;
  padding:0;
  
}
body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}

.tabs {
  li {
    list-style:none;
    float:left;
    width:20%;
  }
  a {
    display:block;
    text-align:center;
    text-decoration:none;
    position:relative;
    text-transform:uppercase;
    color:#fff;
    height:70px;
    line-height:90px;
    background:linear-gradient(165deg,transparent 29%, #98927C 30%);
    
    &:hover, &.active {
       background: linear-gradient(165deg,transparent 29%, #F2EEE2 30%);
       color:#98927C;
    }
    
    &:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.1);
      border-right: 7px solid transparent;
    }
    &.active:before{
      content:'';
      position:absolute;
      z-index:11;
      left:100%;
      top:-100%;
      height:70px;
      line-height:90px;
      width:0;
      border-bottom: 70px solid rgba(0,0,0,.2);
      border-right: 20px solid transparent;
    }
    // &:last-child:before, &.active:last-child:before{
    //   border: none;
    // }
  }
}
.tabgroup {
  box-shadow:2px 2px 2px 2px rgba(0,0,0,.1);;
  div {
    padding:30px;
    background:#F2EEE2;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
}
.clearfix:after {
  content:"";
  display:table;
  clear:both;
}

@media only screen and (min-width: 992px){
/*.container1{
   max-width: 100%;
    margin-left: 0px;
}
#a{
  background-color: rgb(255,255,255);
}*/

.img1 {
    display: inline-block;
    margin-top: -10px;
}
}
@media only screen and (max-width: 992px){
/*.container1{
   max-width: 100%;
    margin-left: 0px;
}
#a{
  background-color: rgb(255,255,255);
}*/

.img1 {
    display: inline-block;
    margin-top: -5px;
}
}

</style>
 <div class="wsmobileheader clearfix ">
  <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>
  <span class="smllogo">
     <img src="img/rsz_gdc1.png" alt="gdc" class="img1"/>
  
  </span>
  <!-- <a href="tel:09480812310" class="callusbtn"><i class="fas fa-phone-alt" aria-hidden="true"></i></a> -->
   
</div>
<!-- Mobile Header -->
<div class="wsmainfull clearfix top-menu">
  <div class="wsmainwp clearfix">
    <div class="desktoplogo" class="img">
      <a href="index.php">
        <div class="content">
          <img src="img/rsz_gdc.png" alt="GOVINDA DAS COLLEGE" width="100%" height="100" style="" class="img1">
              <div class="logo-accreditation">
            <h2></h2>
          </div>
        </div>
      </a>
    </div>


    <!--Main Menu HTML Code-->
      <nav class="wsmenu clearfix">
      <ul class="wsmenu-list main-menu">
        <!-- <li class="home-i"><a href="index.php" title="home"> <i class="fas fa-home"></i></a></li> -->
        
      <li><a href="index.php"> About Us</a></li>
        <li><a href="login.php">Membership</a></li>
        <li><a href="archieves.php"> Archieves</a></li>
                    <li><a href="http://www.govindadasacollege.edu.in"> GDC Home Page</a></li>
  
  
       </ul>
      <ul class="wsmenu-list main-menu-nxt" >
        <li ><a href="#">Project Funding<span class="wsarrow"></span></a>
          <div class="wsmegamenu clearfix" id="a" >
          <style type="text/css">
          .container2{
          max-width: 1960px;
    margin-left: 67px;}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}
    </style>
            <div class="container2" style="background-color: rgba(34, 45, 50, 0.8);">
              <div class="row" >
                <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                       </ul>
                </div>
                 <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">Project Funding </li>
                  <li><a href="do1.php"><h3>General Description</h3></a></li>
             <li><a href="do2.php" style="padding-top: 10px;"><h1>Contribute to General Corpus</h1></a></li>
                    <li><a href="do3.php" style="padding-top: 10px;"><h3>Infra and Long Term Project</h3></a></li>
                  </ul>
                </div>
               <div class="col-lg-4 col-md-12 col-xs-12">
                  <ul class="link-list">
                    <li class="title">Contribute to a Cause</li>
                  <li><a href="do4.php"><h3>Sponsor a Student</h3></a></li>
             <li><a href="do5.php"style="padding-top: 10px;"><h1>Mid-Day Meal Program</h1></a></li>
                    <li><a href="do6.php"style="padding-top: 10px;"><h3>Fund for Honoring Achievers</h3></a></li>
                         <li><a href="do7.php"style="padding-top: 10px;"><h3>Contribute to Benevolent Fund</h3></a></li>
               
                  </ul>
                </div>
                
             
              </div>
            </div>
          </div>
        </li>
       
        <li><a href="#">Blogs <span class=""></span></a>
        
        </li>
         <li><a href="contact.php">Contact Us <span class=""></span></a>
         
        </li>
     
       

      </ul>
    </nav>
    <!--Menu HTML Code-->
  </div>
   
</div>
<br>
<br>
<br>
 

<section class="inner-bg">
  <div class="container1">
    <div class="row">
      <div class="inner-content-box">
      <?php
            $i=1;
            while($row1 = mysqli_fetch_array($result511)) {
                    
            ?>
        <div class="box">
            <div class="titleHolder">
            <h1><?php echo $row1["cap"]; ?></h1>
                <div class="btn">show</div>
            </div>
                
              <div class="ImageHolder" style="display:none;">
            <?php
$a=$row1["folder"];
$folder_path = $a; //image's folder path

$num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);

$folder = opendir($folder_path);
 
if($num_files > 0)
{
    while(false !== ($file = readdir($folder))) 
    {
        $file_path = $folder_path.$file;
        $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
        if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp') 
        {
            ?>
            <!--<a href="" height="100" width="100"><img src="<?php echo $file_path; ?>"  height="150" width="150" /></a>
              <img class="images" src="<?php echo $file_path; ?>" alt="">-->
              <style>
                  .zoom {
  
  transition: transform .2s; /* Animation */
  width: 150px;
  height: 150px;
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
img{
    margin:10px;
}
</style>
              </style>
            <a href="<?php echo $file_path; ?>" data-lightbox="<?php echo $row1["cap"]; ?>" height="100" width="100" data-title="<?php echo $file; ?>"><img src="<?php echo $file_path; ?>"  class="zoom"height="150" width="150" /></a>
 
            <?php
        }
    }
}
else
{
    echo "the folder was empty !";
}
closedir($folder);
?>
            <!--    <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">
                <img src="b.webp" alt="">-->
            </div>
        </div>
  <?php
            

            }

?>
         
    </div>

    <div class="popBox">
        <div class="butn-Holders">
            <!--Close button-->
            <div class="butn btn-Close">X</div>
            <!--Prev button-->
            <div class="butn btn-Prev" style="display:none;"><</div>
            <!--Next button-->
            <div class="butn btn-Next" style="display:none;">></div>
        </div>

        <img src="" alt="images"/>
    </div>
        </div>
    </div>
  </div>
</section>   
<nav class="pushy pushy-left">
<br/>
<br/>
<br/>
<br/>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/menu.js"></script>
 <style type="text/css">
  
 .a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
} 
</style>
 <style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #e7e625;
   color: white;
  
}
</style>
 <div class="footer">
 <div class="container-fluid pad0 copy-bg">
      <div class="copy">
        <div class="container">
          <div class="row">
            <div class="col-md-6 wow fadeInDown"> <b>© 2020-21 GDCAA. All Rights Reserved</b></div>
            <div class="col-md-6 wow fadeInDown">
              <div class="pull-right"> <b>Developed By | Anantha Murthy ,Alumni GDCAA Surathkal |9743702262</b> </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</div>


</body>
</html>
