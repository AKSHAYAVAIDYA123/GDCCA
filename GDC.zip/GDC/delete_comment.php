<?php
session_start();
require_once("db.php");
 $a= $_SESSION['id_user'];

 $id_post='';
 $name='';
 $name1='';
 $id='';

    $filename=$_GET['did'];

    $sql = "SELECT * FROM comments WHERE id_comment=$filename";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['id_post'];
    $id=$row['id_user'];
    //echo $name; 

  }

  
 // echo $_SESSION['name'];
}

    $sql = "SELECT * FROM post WHERE id_post=$name";
$result = $conn->query($sql);

if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name1 = $row['id_user'];
  //  echo $name1; 

  }

  
 // echo $_SESSION['name'];
}
//echo $_SESSION['id_user'];
echo $a;
echo $name1;
if($a==$name1||$id==$a)
  {
  		 $sql1 = "DELETE FROM `comments` WHERE `id_comment`='$_GET[did]'";  
 //  $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]'";  
 // $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did]' ";  
 
  if($conn->query($sql1) === TRUE) {

     
      ?>
<script type="text/javascript">
  alert('Your post was succesfully deleted');
</script>

      <?php
       header("Location: profile.php");
  }
  }
  else
  {
  ?>
<script type="text/javascript">
alert("Error in Deleting");
window.location.href = "profile.php";
</script>
<?php
          //header("Location: profile.php");

  }

     //echo $filename; 
?>	