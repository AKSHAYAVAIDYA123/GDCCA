<?php
	require_once("db.php");
 session_start();
	$id=$_GET['id'];

	$name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
 
 	$sql = "UPDATE users SET name='$name',email='$email',password='$password' WHERE id_user=$id";
	if($conn->query($sql)===TRUE) {
		header("Location: user_role_admin.php");
		 
		exit();
	} else {
		 
		header("Location:user_role_admin.php");
	}  exit();
 
	
?>