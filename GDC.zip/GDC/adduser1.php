<?php

session_start();

require_once("db.php");

if(isset($_POST)) {

	$name = mysqli_real_escape_string($conn, $_POST['Name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$dob = mysqli_real_escape_string($conn, $_POST['dob']);
	$address = mysqli_real_escape_string($conn, $_POST['address']);


	$password = mysqli_real_escape_string($conn, $_POST['password']);
	//$password = base64_encode(strrev(md5($password)));
	$department = mysqli_real_escape_string($conn,$_POST['dept']);
	$passout = mysqli_real_escape_string($conn,  $_POST['yop']);
	 $mySelect = mysqli_real_escape_string($conn,  $_POST['mySelect']);
   $phone = mysqli_real_escape_string($conn,  $_POST['phone']);
    
    
   
  $result =  mysqli_query($conn, "SELECT * FROM users WHERE email='".$email."'");
   if(mysqli_num_rows($result) > 0)
  { echo "<script>
alert('Email ID Already Exist');
window.location.href='login.php';
</script>";
  }
  else
  {
      if(strlen($phone)==10)
{

try {
    $sql = "INSERT INTO users(name,email,city,degree,DOB,address,password,retire,ass_work_status,phone,user_type) VALUES
    ('$name','$email','$department','','$dob','$address','$password','$passout','$mySelect','$phone','Associative Member')";
	//$sql2 = "INSERT INTO search(name, email, degree,designation) VALUES ('$name', '$email','$passout','$department')";
//	$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

	if($conn->query($sql)===TRUE) {
		//$_SESSION['registeredSuccessfully'] = true;
   if(!empty($email))
   {
   	require 'class/class.phpmailer.php';
  $output = '';
 
      
  

    
    $mail = new PHPMailer;
    $mail->IsSMTP();                //Sets Mailer to send message using SMTP
    $mail ->Host = "smtp.hostinger.in";
      $mail ->Port = 587; // or 587
      $mail->SMTPAuth = true;             //Sets SMTP authentication. Utilizes the Username and Password variables
      $mail->Username = 'gdcaa@alumnigdc.in';
      $mail->Password = 'Gdcaa@2021';
      $mail->SetFrom('gdcaa@alumnigdc.in','GDCAA');
      $mail->SMTPSecure = 'TSL';             //Sets connection prefix. Options are "", "ssl" or "tls"
    //$mail->From = 'info@webslesson.com';      //Sets the From email address for the message
    //$mail->FromName = 'Webslesson';         //Sets the From name of the message
    $mail->AddAddress($email, $name); //Adds a "To" address
    $mail->WordWrap = 50;             //Sets word wrapping on the body of the message to a given number of characters
    $mail->IsHTML(true);              //Sets message type to HTML  
 
    //$mail->Subject = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'; //Sets the Subject of the message
    //An HTML or plain text message body
    $mail->Subject = "Thank you for Registering..";
    $mail->Body = nl2br("Thank you for showing interest in becoming the Associative member of Govinda dasa College Alumni Association. Your request is sent to Admin for the approval. Use the same credentials used while registering, to login to the social network once the admin approves it.\n\n\n\n\nWith Regards\n Govinda Dasa College Alumni Association(R.)\nGovinda Dasa College,Surathkal-575014\nEmail :GDCAA2019@gmail.com\nContact Number : 9481916741,6362659243,9480347065");
    
    $mail->AltBody = '';

    $result = $mail->Send();            //Send an Email. Return true on success or false on error

    if($result["code"] == '400')
    {
      $output .= html_entity_decode($result['full_error']);
    }

   }
    
		// echo "ok";
 echo "<script>
alert('Your Request has been sent to admin for Appoval');
window.location.href='login.php';
</script>";
		//header('location:login.php');
	} else {
	 	echo "<script>
alert('Error Please Try Again...');
window.location.href='login.php';
</script>";	 
 
}
} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}



	
}
else
{
	echo "<script>
alert('Please Enter 10 digit Phone Number');
window.location.href='login.php';
</script>";
}
  }



   

}