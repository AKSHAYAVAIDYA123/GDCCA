<?php

session_start();
require_once("db.php");
if(isset($_GET['did1']))
{
  
  
  $sql1 = "DELETE FROM `friend_posts` WHERE `id_post`='$_GET[did1]' AND id_user='$_SESSION[id_user]' OR id_friend='$_SESSION[id_user]'";  
  if($conn->query($sql1) === TRUE) {
    //  header("Location: profile.php");
   
header('location:view-profile - Copy.php');

  }
  else
  {

       echo "<script>
alert('You Don't have Permission to Delete the Post');
window.location.href='view-profile - Copy.php';
</script>";
  }

}

?>
