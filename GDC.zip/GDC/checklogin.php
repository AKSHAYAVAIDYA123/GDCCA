<?php

session_start();

require_once("db.php");
require 'class/class.phpmailer.php';
	$output = '';
if(isset($_POST)) {

 
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
//decode
	//$password = base64_encode(strrev(md5($password)));

	if($email == "admin@gmail.com")
	{
		
		$sql = "SELECT * FROM users WHERE email='$email' AND password='$password' AND lock_act='0'";
	$result = $conn->query($sql);

	if($result->num_rows > 0) {
		echo "string";
		$row = $result->fetch_assoc();

		$sql1 = "UPDATE users SET online='1' WHERE id_user='$row[id_user]'";
		$conn->query($sql1);

		$_SESSION['id_user'] = $row['id_user'];
		$_SESSION['name'] = $row['name'];
		$_SESSION['createdAt'] = $row['createdAt'];
		$_SESSION['designation'] = 'admin';
		$_SESSION['degree'] = $row['degree'];
		$_SESSION['email'] = $row['email'];
		$_SESSION['type'] = $row['user_type'];

		 
	  header('location:user-profile.php');
	  exit();
	 	 
	}
	}else{

          if(is_numeric($email))
          {

			 
				 $sql = "SELECT * FROM users WHERE phone='$email' AND password='$password' AND lock_act='0'";
						ob_start();
				$result = $conn->query($sql);

				if($result->num_rows > 0) {
					$row = $result->fetch_assoc();
				$six_digit_random_number = mt_rand(100000, 999999);
					$sql1 = "UPDATE users SET online='1' WHERE id_user='$row[id_user]'";
					$conn->query($sql1);

					$_SESSION['id_user'] = $row['id_user'];
					$_SESSION['name'] = $row['name'];
					$_SESSION['createdAt'] = $row['createdAt'];
					$_SESSION['designation'] = $row['city'];
					$_SESSION['type'] = $row['user_type'];
					    header('location:uindex.php');
				exit();
		//echo "ok";


			}
	 
			else
			{  
				 
		      header('location:login.php');
		      exit();
			 
			}
          }
          else
          {

			 
	 $sql = "SELECT * FROM users WHERE email='$email' AND password='$password' AND lock_act='0'";
			ob_start();
	$result = $conn->query($sql);

	if($result->num_rows > 0) {
		$row = $result->fetch_assoc();
$six_digit_random_number = mt_rand(100000, 999999);
		$sql1 = "UPDATE users SET online='1' WHERE id_user='$row[id_user]'";
		$conn->query($sql1);

		$_SESSION['id_user'] = $row['id_user'];
		$_SESSION['name'] = $row['name'];
		$_SESSION['createdAt'] = $row['createdAt'];
		$_SESSION['designation'] = $row['city'];
		$_SESSION['type'] = $row['user_type'];
 	    header('location:uindex.php');
	exit();
		//echo "ok";


	}
	 
	else
	{  
		 
      header('location:login.php');
      exit();
	 
	}     	
          }
}
 
 
}
?>
 