<?php
session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}


require_once("db.php");

$sql2 = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
$result = $conn->query($sql2);
if($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $designation = $row['address'];
    $email = $row['email'];
    $degree = $row['degree'];
    $university = $row['university'];
    $city = $row['city'];
    $country = $row['address'];
    $skills= $row['skills'];
    $aboutme = $row['aboutme'];
    $profileimage = $row['profileimage'];
  }
}

if(count($_POST)>0) {
  $sql = "UPDATE company set company='" . $_POST["company"] . "', place='" . $_POST["place"] . "', start='" . $_POST["start"] . "', position='" . $_POST["position"] . "', till='" . $_POST["till"] . "'  WHERE Id='" . $_POST["Id"] . "'";
  mysqli_query($conn,$sql);
  $message = "Record Modified Successfully";
}

$sql = "SELECT * FROM company where Id='" . $_GET["Id"] . "'";
$result2 = mysqli_query($conn,$sql);
$row1 = mysqli_fetch_array($result2);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Social Network</title>
  <link rel="stylesheet" type="text/css" href="styles.css" />
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css"> -->
  <!-- jvectormap -->
  <!-- <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css"> -->
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <link rel="stylesheet" href="dist/css/custom.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

</head>
<body class="hold-transition skin-blue sidebar-mini">
  <?php 
  ?>
<div class="wrapper">


  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content-header">
      <h1>
        User Profile
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
            <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['profileimage'] != '') {
                    echo '<img src="uploads/profile/'.$row['profileimage'].'" class="profile-user-img img-responsive img-circle" alt="User Image">';
                  } else {
                     echo '<img src="dist/img/avatar5.png" class="profile-user-img img-responsive img-circle" alt="User Image">';
                  }
                }
                ?>

              <h3 class="profile-username text-center"><?php echo $name; ?></h3>

              <p class="text-muted text-center"><?php echo $designation; ?></p>

              <ul class="list-group list-group-unbordered">
            
                
                <li class="list-group-item">
                   <?php
                   $sql1 = "SELECT * FROM friends WHERE id_user='$_SESSION[id_user]'";
                    $result1 = $conn->query($sql1);
                    if($result1->num_rows > 0) {
                      $totalno = $result1->num_rows;
                    } else {
                      $totalno = 0;
                    }
                  ?>
                  <b>Friends</b> <a class="pull-right"><?php echo $totalno; ?></a>
                </li>
              </ul>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
           <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Education</strong>
              
              <?php   ?>
              <p class="text-muted">
                <?php echo $city; ?> from <?php  echo $university; ?>
              </p>
              <?php     ?> 

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>

              <p class="text-muted"><?php echo $country; ?></p>

              <hr>

              <strong><i class="fa fa-pencil margin-r-5"></i> Skills</strong>
              
              <p>
              <?php 

              $arr = explode(" ", $skills);

              $colors = array("label-danger", "label-success", "label-info", "label label-warning", "label-primary");

              foreach ($arr as $key => $value) {
                $c = array_rand($colors);
                $v = $colors[$c];
                ?>
                <span class="label <?php echo $v; ?>"><?php echo $value; ?></span>
                <?php
              } 
              ?>
              </p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> About Me</strong>

              <p><?php echo $aboutme; ?></p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

            <div class="col-md-9">
          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
   <center>          <h3>Update Working Information</h3>             

          	<form name="frmUser" method="post" action="">
<div style="width:500px;">
<div class="message"><?php if(isset($message)) { echo $message; } ?></div>
 <table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">
<br>
 <tr>
<td style="display:none;"><label>Username</label></td>
<td><input type="hidden" name="Id"  class="form-control" value="<?php echo $row1['Id']; ?>">
<input type="text" name="name"  class="form-control" value="<?php echo $row1['name']; ?>" style="display:none;"></td><br>
</tr> 
<tr>
<td><label>Company</label></td>
<td><input type="text" name="company" class="form-control" value="<?php echo $row1['company']; ?>"></td>
</tr>
<td><label>Position</label></td>
<td><input type="text" name="position" class="form-control" value="<?php echo $row1['position']; ?>"></td>
</tr>
<tr>
<td><label>place</label></td>
<td><input type="text" name="place" class="form-control" value="<?php echo $row1['place']; ?>"></td>
</tr>
<tr>
<td><label>start</label></td>
<td><input type="date" name="start" class="form-control" value="<?php echo $row1['start']; ?>"></td>
</tr>
<td><label>till</label></td>
<td><input type="text" name="till" class="form-control" value="<?php echo $row1['till']; ?>"></td>

</tr>
<tr>
<td colspan="2"></td>
</tr>
</table>
</div>
<br>
<input type="submit" name="submit" value="Submit" class="btn btn-info"> 
</form>
<button onclick="location.href = 'view%20company.php';" id="myButton" class="btn bg-maroon bg-flat" >Back To Profile</button>


			<center>  </center>
<!-- ./wrapper -->
<br>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>

        <!--,sdjklsf-->






        </div>        
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

</body>
</html>
