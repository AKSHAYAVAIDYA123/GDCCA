<?php 


session_start();

require_once("db.php");
$id=$_GET['id'];
	mysqli_query($conn,"delete from contact_info where id='$id'");
	header('location:member-add.php');

?>