<?php

session_start();

require_once("db.php");
  include('db.php'); 
if(isset($_POST["sub"]))
{
 $c=$_POST["didval"];  

	//mysqli_query($conn,"INSERT INTO events (id_user, name, conduct) 
//VALUES ('Glenn','Quagmire',33)");
	 $sql = "INSERT INTO event_reg_user (id_event,id_user,name) VALUES ('$_POST[didval]','$_SESSION[id_user]','$_SESSION[name]')";
	if($conn->query($sql)===TRUE) {
		?>
		<script type="text/javascript">
		alert('You Have Successfully Registerd the Event');</script>
		<?php
		header("Location: "  . $_SESSION['callFrom']);
		exit();
	} else {
		echo $conn->error;
	}  
}
