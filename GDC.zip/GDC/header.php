  <header id="header" class="main-header" >

    <!-- Logo -->
    <a href="#" class="logo" style="background-color:orange;color: white" >
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>G</b>D</span>
      <!-- logo for regular state and mobile devices -->
     <span class="logo-lg"><b>GDCAA</b></span>
    </a>


    <?php

    $sql = "SELECT id_from, COUNT(id_from) as total FROM messages WHERE id_to='$_SESSION[id_user]' AND viewed='0' GROUP BY id_from";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
      $totalUnreadMessages =  $result->num_rows;
    } else {
      $totalUnreadMessages = 0;
    }




    ?>

    <?php

      $sql1 = "SELECT id_user, COUNT(id_friend) as total FROM friendrequest WHERE id_user='$_SESSION[id_user]' AND viewed='0' GROUP BY id_friend";
    $result1 = $conn->query($sql1);
    if($result1->num_rows > 0) {
      $totalUnreadMessages1 =  $result1->num_rows;
    } else {
      $totalUnreadMessages1 = 0;
    }



    

    ?>
 
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color:orange; height: 50px; color: white">
      <!-- Sidebar toggle button-->
       <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu  <img src="images/logo.png"  style="padding-left: 180px;" height="55px" >
  -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
                   <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <?php if($totalUnreadMessages > 0) { ?>
              <span class="label label-warning"><?php echo $totalUnreadMessages; ?></span>
              <?php } ?>
            </a>
            <?php if($totalUnreadMessages > 0) { ?>
            <ul class="dropdown-menu">
              <li class="header">You have <?php echo $totalUnreadMessages; ?> notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <?php
                  while($row = $result->fetch_assoc()) {
                    $sqlUser = "SELECT name FROM users WHERE id_user='$row[id_from]'";
                    $resultUser = $conn->query($sqlUser);
                    $rowName = $resultUser->fetch_assoc();
                  ?>

                  <li>
                    <a href="messages.php?id=<?php echo $row['id_from']; ?>" style="white-space: inherit;">
                      <i class="fa fa-user text-red"></i> You have <?php echo $row['total']; ?> unread message(s) from <?php echo $rowName['name']; ?>
                    </a>
                  </li>
                  <?php } ?>
                </ul>
              </li>
            </ul>
            <?php } else { ?>
            <ul class="dropdown-menu">
              <li class="header">You have 0 notifications</li>
            </ul>
            <?php } ?>
          </li>

           <li class="dropdown notifications-menu" >
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <?php if($totalUnreadMessages1 > 0) { ?>
              <span class="label label-warning"><?php echo $totalUnreadMessages1; ?></span>
              <?php } ?>
            </a>
            <?php if($totalUnreadMessages1 > 0) { ?>
            <ul class="dropdown-menu">
              <li class="header">You have <?php echo $totalUnreadMessages1; ?> Friend Request</li>
                <li class="header"> <a href="friend-request.php" style="white-space: inherit;">You have Pending <?php echo $totalUnreadMessages1; ?> FriendRequest to accept</li> </a>
              <li>
               
                <ul class="menu">
                  <?php
                  while($row = $result->fetch_assoc()) {
                    $sqlUser = "SELECT name FROM users WHERE id_user='$row[id_user]'";
                    $resultUser = $conn->query($sqlUser);
                    $rowName = $resultUser->fetch_assoc();
                  ?>

                  <li>
               
                      
                  </li>
                  <?php } ?>
                </ul>
              </li>
            </ul>
            <?php } else { ?>
            <ul class="dropdown-menu">
              <li class="header">You have 0 notifications</li>
            </ul>
            <?php } ?>
          </li>

          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['profileimage'] != '') {
                    echo '<img src="uploads/profile/'.$row['profileimage'].'" class="img-circle" alt="User Image" style="width: 25px; height: 25px;">';
                  } else {
                     echo '<img src="dist/img/avatar5.png" class="img-circle" alt="User Image" style="width: 25px; height: 25px;">';
                  }
                  $username = $row['name'];
                  $createdAt1 = strtotime($_SESSION['createdAt']);
                  $createdAt = date('m/d/Y', $createdAt1);

                  $a=$_SESSION['designation'];

                 

             //     $timestamp = strtotime($N_datetime);
//$N_date = date('m/d/Y', $timestamp);
                }
                ?>
              <span class="hidden-xs"><?php echo $username; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">

              <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  $row = $result->fetch_assoc();
                  if($row['profileimage'] != '') {
                    echo '<img src="uploads/profile/'.$row['profileimage'].'" class="img-circle" alt="User Image">';
                  } else {
                    echo '<img src="dist/img/avatar5.png" class="img-circle" alt="User Image">';
                  }
                }
                ?>
             

                <p>
                 
                  <?php echo  $_SESSION['name']; ?> - <?php echo $a; ?>
                  <small><?php echo $createdAt; ?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="password_update.php" class="btn btn-default btn-flat">Password Update</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>

    </nav>
  </header>