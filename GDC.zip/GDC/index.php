<?php
require_once("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GDCAA</title>
   
    <link rel="shortcut icon" href="img/icon.ico"/>
    <link href="dashboard/css/bootstrap.min.css" rel="stylesheet"/>
     <!--Main Menu File-->
    <link id="effect" rel="stylesheet" type="text/css" media="all" href="dashboard/css/dropdown-effects/fade-down.css" />
    <link rel="stylesheet" type="text/css" media="all" href="dashboard/css/menu.css" />
       <link id="theme" rel="stylesheet" type="text/css" media="all" href="dashboard/css/color-skins/white-red.css" />
    <!-- FontAwesome -->
    <link href="dashboard/css/all.css" rel="stylesheet"/>
    <!-- Animation -->
    <link rel="stylesheet" href="dashboard/css/animate.css">
    <link rel="stylesheet" href="dashboard/css/magnific/magnific-popup.css">
</head>
<body>
<!-- Mobile Header -->
<style type="text/css">

 
 
  *{
  margin:0;
  padding:0;
  
}



  


body{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
}
.wrapper {
  margin:100px auto;
  width:80%;
  font-family:sans-serif;
  color:#98927C;
  font-size:14px;
  line-height:24px;
  max-width:600px;
  min-width:340px;
  overflow:hidden;
}
#a{ background:url('https://westfieldcc.files.wordpress.com/2011/10/simple-blur-ipad-background.jpg') no-repeat center center fixed;
   background-size: cover;
    opacity: 0.95;
}

/*@media only screen and (max-width: 991px){

#a{   background-color: black;
}


}
@media only screen and (min-width: 991px){



}*/

</style>

</style>
<style type="text/css">
	img{
		    margin: -10px;
	}
</style>
<?php include 'menu.php';?>

<section class="inner-bg">
  <div class="container">
  <br>
<br>
    <div class="row">


       <div class="col-sm-9">
 <div class="inner-content-box">
        <h2 class="wow fadeInDown">About Us</h2>
      
   <p class="wow fadeInDown">
        	<?php
        				 $query=mysqli_query($conn,"select * from `dashboard`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php 
            			if ($row['about_us']=="Objectives"||$row['about_us']=="Alumni Outreach") {
            				# code...
            				?>
            				<b><?php echo $row['about_us']; ?></b>
            				
            		<br>
            		<?php
            			}
            			else
            			{
            						echo $row['about_us']; ?>
            		<br>
            		<?php
            			}
            			?>
            		
              
            </td>
            
             
          </tr>
          <?php
        }
 
      ?>
  <h6> <b>To become Life Member/Associative Member  of this wonderful journey  <a href="login.php" id="firstname">Click Here</a>  </b>
      </h6> 
        </p>
           

       
        <div class="clearfix"></div>
      </div>
       </div>
         <div class="col-sm-3">
 <div class="inner-content-box">
 <?php 
 $result =  mysqli_query($conn, "SELECT * FROM events");
   if(mysqli_num_rows($result) > 0)
   {
   		?>

   			   <h2 class="wow fadeInDown">Events</h2>
        <marquee direction="up"  scrollamount="5" onmouseover="stop()" name="myMarquee" id="myMarquee" onmouseout="start()">
        <p class="wow fadeInDown">
        	<?php
        				 $query=mysqli_query($conn,"select * from `events`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><b>Event Name: </b><?php echo $row['ename']; ?><br></td>
             <td><b>Venue: </b><?php echo $row['addr']; ?><br></td>
              <td><b>Date: </b><?php echo $row['dat']; ?><br></td>
                <td><b>More: </b><?php echo $row['info']; ?><br></td>
                 <td> <?php echo '<a href="'.$row['notice'].'">Click Here</a>';?>
              <br></td>
              <td>------------------------------------------<br></td>
           
             
          </tr>
          <?php
        }
 
      ?>

       
        </p></marquee>
        <div class="clearfix"></div>

   		<?php
   }
   else
   {
   		?>
   		 <h2 class="wow fadeInDown">Member Login</h2>
   			      <form id="login-form" method="post" action="checklogin.php" target="_blank">
      <div class="form-group has-feedback">
        <input type="text"  id="email" name="email" placeholder="Registered Email-ID/Contact Number" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
       <div class="form-group has-feedback">

          <button type="submit" class="btn btn-info button1"  formtarget="_blank">Sign In</button>          
   <button class="btn btn-info button1" 
    onclick="window.location.href = 'login.php';"> 
      Enroll
    </button> 
                    <a href="#" data-toggle="modal" data-target="#donate" style="color:red;"><h6><b>forgot my password</b></h6></a>
 
        </div>
      <div class="row">
    
        <div class="col-xs-12">
      </div>
        <!-- /.col -->
      </div>
      
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form>

   		<?php
   }


 ?>
     
      </div>

   			<div>
   				<pre>
   				</pre>
   			 
   			</div>
      <div class="inner-content-box" style="display:none;">
 <?php 
 $result =  mysqli_query($conn, "SELECT * FROM events");
   if(mysqli_num_rows($result) > 0)
   {
   		?>

   			   <h2 class="wow fadeInDown">Events</h2>
        <marquee direction="up"  scrollamount="5" onmouseover="stop()" name="myMarquee" id="myMarquee" onmouseout="start()">
        <p class="wow fadeInDown">
        	<?php
        				 $query=mysqli_query($conn,"select * from `events`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><b>Event Name: </b><?php echo $row['ename']; ?><br></td>
             <td><b>Venue: </b><?php echo $row['addr']; ?><br></td>
              <td><b>Date: </b><?php echo $row['dat']; ?><br></td>
                <td><b>More: </b><?php echo $row['info']; ?><br></td>
                 <td> <?php echo '<a href="'.$row['notice'].'">Click Here</a>';?>
              <br></td>
              <td>------------------------------------------<br></td>
           
          </tr>
          <?php
        }
       
      ?>

       
        </p></marquee>
        <div class="clearfix"></div>

   		<?php
   }
   else
   {
   		?>
   		 <h2 class="wow fadeInDown">Member Login</h2>
   			      <form id="login-form" method="post" action="checklogin.php">
      <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
       <div class="form-group has-feedback">

          <button type="submit" class="btn btn-info button1">Sign In</button>          
   <button class="btn btn-info button1" 
    onclick="window.location.href = 'login.php';"> 
      Enroll
    </button> 
                    <a href="#" data-toggle="modal" data-target="#donate" style="color:red;"><h6><b>forgot my password</b></h6></a>
 
        </div>
      <div class="row">
    
        <div class="col-xs-12">
      </div>
        <!-- /.col -->
      </div>
      
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form>

   		<?php
   }


 ?>
     
      </div>
       </div>
     
    </div>
  </div>
</section>  
   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
<div class="modal fade" id="donate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Password Reset</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form class="form-horizontal" action="send-password.php"  method="post" enctype="multipart/form-data">
        <style type="text/css">
         
          .form-control1 {
     display: block;
    width: 100%;
    height: calc(1.5em + .75rem + 2px);
    padding: .375rem .75rem;
    /* font-size: 1rem; */
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: .25rem;
      
          }</style>
      <div class="modal-body">
   <div class="card">
         <div class="card-body">
          <div class="form-group">
          <input type="text" class="form-control1" name="email" placeholder="Enter the Registerd Mail ID"> 
      </div>
               
          </div>
        </div>
      </div>

     
         <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Submit</a>
        </form>
        </div>
        </form>
      </div>
    </div>
    </div> 
<nav class="pushy pushy-left">
<br/>
<br/>
<br/>
<br/>
<script src="dashboard/js/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="dashboard/js/bootstrap.min.js"></script>
<script type="text/javascript" src="dashboard/js/menu.js"></script>
<script type="text/javascript">
  $(function () {
    var myMarquee = $('#myMarquee')[0]; 
    setTimeout(function() {
        myMarquee.stop();
        setTimeout(function(){
            myMarquee.start();
            run();    
        },10);   
    },10);
});
</script>
 <?php include 'footer.php';?>
</body>
</html>
