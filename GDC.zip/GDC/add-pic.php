<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['cap'];
	$type=$_POST['type'];
	$lastname=$_POST['folder'];
	$a='add.php';
 	 $lastname .= "/";

 	 $folder_name="admin1/".$type."/".$lastname;
 //	 echo $folder_name;
	$sql = "INSERT INTO caption (cap,folder,test) VALUES ('$firstname','$folder_name','$type')";
	if($conn->query($sql)===TRUE) {
		header("Location: "  . $a);
		exit();
	} else {
		echo $conn->error;
	}