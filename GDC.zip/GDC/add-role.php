<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['ename'];
	$lastname=$_POST['conduct'];
 	$bday=$_POST['bday'];
	 
 	$a=$_SESSION['id_user'];
 	$b=$_SESSION['name'];
    $sql = "INSERT INTO users (type,name,email,password,DOB,degree,city,user_type,flag,lock_act) VALUES ('admin','$firstname','$lastname','$bday','','','','Media_admin','1','0')";
            if (mysqli_query($conn, $sql)) {
              //  echo "File uploaded successfully";
                     header("Location: user_role_admin.php");
            }
            else
            {
                echo 'Error: '. $conn->error;
            }
	 ?>