<?php

session_start();

require_once("db.php");
  include('db.php');
	$firstname=$_POST['about'];
	 
 	//$lastname=$_SESSION['id_user'];
	//$address=$_POST['address'];
	//mysqli_query($conn,"INSERT INTO events (id_user, name, conduct) 
//VALUES ('Glenn','Quagmire',33)");
	$sql = "INSERT INTO dashboard (about_us) VALUES ('$firstname')";
	if($conn->query($sql)===TRUE) {
		//header("Location: "  . $_SESSION['callFrom']);
		?>
		<script type="text/javascript">
		 window.location.href = "about_us_db.php";</script>
		<?php
		exit();
	} else {
		?>
		<script type="text/javascript">
		 window.location.href = "about_us_db.php";</script>
		<?php	exit();
	}