<?php

session_start();

if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");


 if(isset($_POST['search']))
{

    $valueToSearch = $_POST['valueToSearch'];
      
    $search_result = $conn->query("SELECT * FROM `event_reg_user` e,events s,users u,contact c where e.id_event=s.id_event and e.id_user=u.id_user and u.id_user=c.id_user and s.ename='$_POST[valueToSearch]'");
   $search_result1 = $conn->query("SELECT * FROM `event_reg_user` e,events s,users u,contact c where e.id_event=s.id_event and e.id_user=u.id_user and u.id_user=c.id_user and s.ename='$_POST[valueToSearch]'");

     // $search_result = $conn->query("SELECT * FROM `users` u,events e, contact c,event_reg_user r WHERE r.id_event=e.id_event and u.id_user=c.id_user and u.id_user=r.id_user and e.ename='$_POST[valueToSearch]'");
  //  $search_result1 = $conn->query("SELECT * FROM `users` u,events e,contact c,event_reg_user r WHERE r.id_event=e.id_event  and u.id_user=c.id_user and u.id_user=r.id_user and e.ename='$_POST[valueToSearch]'");
   
//    $search_result = $conn->query("SELECT * FROM `users` u,events e,event_reg_user r WHERE r.id_event=e.id_event and u.id_user=r.id_user name LIKE '%".$valueToSearch."%' or designation LIKE '%".$valueToSearch."%' or  email = '%".$valueToSearch."%'");
   //$search_result1 = $conn->query("SELECT * FROM `users` WHERE name LIKE '%".$valueToSearch."%' or designation LIKE '%".$valueToSearch."%' or  email = '%".$valueToSearch."%'");
    //$search_result=$conn->query("SELECT * FROM `users` where degree='$_POST[year]' and designation='$_POST[valueToSearch]'");
//  $search_result1= $conn->query("SELECT * FROM `users` where degree='$_POST[year]' and designation='$_POST[valueToSearch]'");
 
}
 else {

//      $search_result = $conn->query("SELECT * FROM `users` u,events e, contact c,event_reg_user r WHERE r.id_event=e.id_event and u.id_user=c.id_user and u.id_user=r.id_user ");
 //   $search_result1 = $conn->query("SELECT * FROM `users` u,events e,contact c,event_reg_user r WHERE r.id_event=e.id_event  and u.id_user=c.id_user and u.id_user=r.id_user ");
  $search_result = $conn->query("SELECT * FROM `users` where id_user='420'");

$search_result1 = $conn->query("SELECT * FROM `users` where id_user='420'");

      
    

}
 
 $search_result3 = $conn->query("SELECT * FROM `users` where id_user='420'");

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
 <script type="text/javascript" src="dist\js\jquery-3.2.1.min.js.js"></script>
 


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
   
          <form action="" method="post">
          <div class="input-group col-xs-4">
            <select name="valueToSearch" class="form-control" id="valueToSearch" required>
<option value="" selected="selected">Events</option>
<?php
$sql = "SELECT DISTINCT ename FROM events where id_user='$_SESSION[id_user]'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["ename"]; ?>"><?php echo $rows["ename"]; ?></option>
<?php } ?>
</select>  
              <span class="input-group-btn">

               




  
            <input type="submit" name="search" value="Filter" class="btn btn-info" id ="printbtn">

               <a class="btn btn-success hidden-print"  id ="printbtn" href="javascript:window.print()"><span class="glyphicon glyphicon-print"> Print</span></a>
 
</span>
            </div>


    <!-- Main content -->
       <br>

   <!--<div class="well" style="margin:auto; padding:auto; width:100%;">
     <span style="font-size:25px; color:blue"><center><strong>EVENTS</strong></center></span>
    <span class="pull-left"><a href="#feedback-modal" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add New</a></span>
    --> <div style="height:50px;"></div>

 
     <div class="table-responsive">
            <br>
               <?php while($row1 = mysqli_fetch_array($search_result1)):?>

             
     <form  method="POST" action="" class="form-horizontal"  enctype="multipart/form-data" >
   
<input type='hidden' name='didval' value="<?php echo $row1['id_user']; ?>" > 
 
 </form>
             <?php endwhile;?>


<div class="col-md-12">
              <center><caption><big><b>Registered Alumnies</b></big></caption></center>
             <table class="table table-striped table-bordered table-hover" > 
            
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                     <th>Department</th>
                     <th>Batch</th>
                    <th>Event Name</th>
                    <th>Phone</th>
                    
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['city'];?></td>
                     <td><?php echo $row['degree'];?></td>
<td><?php echo $row['ename'];?></td>
<td><?php echo $row['phone'];?></td>
                   
                  
              
               </tr>
                       

   
                <?php endwhile;?>
</table>   </div>              
          <div class="col-md-3">
          </div>
           <script type="text/javascript">
      

            if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
            </script>
           
            </div>
       
                  </div>
  </div>
      

    <!-- /.content -->
  </div>
  <!-- /.
  <!-- /.content-wrapper -->

 
</div>
<!-- ./wrapper -->
    <footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
