  <header id="header" class="main-header" style="background-color:#99b3ff;height:70px;">

    <!-- Logo -->
      <a href="index.html" class="logo" style="background-color:#99b3ff;color: black" >
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>C</span>
      <!-- logo for regular state and mobile devices --><link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
     <span class="logo-lg" style="backgro"><b><h2 style="font-family: 'Audiowide';font-size: 32px">Home</h2></b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color:#99b3ff;">
      <!-- Sidebar toggle button--><link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
   <h2 style="font-family: 'Audiowide';font-size: 28px"><b><i>NMAMIT ALUMNI ASSOCIATION-WENAMITAA</i></b></h2>
      <!-- Navbar Right Menu -->
     
                   <!-- Notifications: style can be found in dropdown.less -->

         </ul>
       </div>
          
      </div>

    </nav>
  </header>