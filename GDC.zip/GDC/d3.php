<?php

session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");
//$_SESSION['callFrom'] = "a1.php";

if(isset($_POST["sub"]))
{
 $didval=$_POST["didval"];  
 // $search_result = $conn->query("SELECT * FROM users WHERE id_user=''");
 // mysqli_query($conn,"delete from usn");
  //  mysqli_query($conn,"UPDATE `users` SET status = 'inactive'  WHERE id_user='$_POST[didval]'");
    //  echo("Error description: " . $conn -> error);
      // 	$sql = "DELETE from donation_info WHERE id=$didval";
  	$sql = "UPDATE donation_info SET ap='1',lock_bt='1',updated_at=now() WHERE id=$didval";

	if($conn->query($sql) === TRUE) {
		header("Location:donation.php");
		exit();
	} else {
		echo $conn->error;
	}
 // header("Location: user-profile.php");
 
}
 
 
?>
 