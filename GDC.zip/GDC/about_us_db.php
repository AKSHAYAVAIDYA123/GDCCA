<?php

session_start();
$name='';
if(empty($_SESSION['id_user'])) {
  header("Location: login.php");
  exit();
}
require_once("db.php");




// function to connect and execute the query
 
$_SESSION['callFrom'] = "about_us_db.php";

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>
  <title>GDCAA</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>

  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

 

      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>    


  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
            
</head>
<body class="hold-transition skin-blue sidebar-mini">

 <div class="wrapper">

  <!-- Header -->
  <?php include_once("header.php"); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once("sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
 <!-- <div class="container">
          <h1 ><center><b>Event ADD</b></center></h1>
   </div>-->
    <style type="text/css">
 
            @media print {
    #printbtn {
        display :  none;
    }
    #didval {
        display :  none;
    }
    #valueToSearch {
        display :  none;
    }
     #year {
        display :  none;
    }

@media screen {
  #printSection {
      display: none;
  }
}

 

}

        </style>
    <div style="height:50px;"></div>
  <div class="well" style="margin:auto; padding:auto; width:80%;">
  <span style="font-size:25px; color:blue"><center><strong>Dashboard Data</strong></center></span> 
    <span class="pull-left" id="didval"><a href="#feedback-modal" data-toggle="modal" class="btn btn-primary" id="printbtn"><span class="glyphicon glyphicon-plus"></span> Add New</a></span>
   <br>
 
    <table class="table table-striped table-bordered table-hover">
      <thead style="display:none;">
        <th>Name</th>
        <th>Organizer</th>
        <th>Date</th>
        <th>Address</th>
          <th>More Information</th>
        <th id ="printbtn">Action</th>
      </thead>
      <tbody>
      <?php
        
 
        $query=mysqli_query($conn,"select * from `dashboard`");
        while($row=mysqli_fetch_array($query)){
          ?>
          <tr>
            <td><?php echo $row['about_us']; ?></td>
            <td id ="printbtn">
            <a href="#edit<?php echo $row['id']; ?>" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Edit</a>
              <a href="#del<?php echo $row['id']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
             <?php include('button4.php'); ?>
            </td>
          </tr>
          <?php
        }
 
      ?>
      </tbody>
    </table>
  </div>
  
 

<!-- insert Model -->
  <div class="modal fade" id="feedback-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New</h4></center>
                </div>
                <div class="modal-body">
        <div class="container-fluid">
        <form method="POST" action="add-about.php">
          <div class="row">
            <div class="col-lg-2">
              <label class="control-label" style="position:relative; top:7px;">About Us</label>
            </div>
            <div class="col-lg-10">
              <input type="text" class="form-control" name="about" placeholder="Paste about us paragraph" required>
            </div>
          </div>
          <div style="height:10px;"></div>
             
   
           
        </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
        </form>
                </div>
 
            </div>
        </div>
</div>

   </div>
   <footer class="footer">
    <div>
       </div>
    <strong>Copyright &copy; 2020-21 <a href="#">GDCAA</a>.</strong> All rights
    reserved.
  </footer>

  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>
           <script type="text/javascript">
            if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
            </script>
         </div>

       <script>

  $( function() {

      $( "#datepicker" ).datepicker();

  } );

  </script>
</script>         
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

</body>
</html>


