<?php 


session_start();

require_once("db.php");
$id=$_GET['didval']; 
 mysqli_query($conn,"delete from comments where id_comment='$id'");
 header('location:log.php');
//echo $id;
?>