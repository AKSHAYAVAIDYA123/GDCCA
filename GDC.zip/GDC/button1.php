<!-- Delete -->
    <div class="modal fade" id="del<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Delete</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($conn,"select * from caption where id='".$row['id']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5><center><strong><?php echo $row['folder']; ?></strong> Are you Deleted this?...</center></h5> 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="delete-pic.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Edit</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$edit=mysqli_query($conn,"select * from caption where id='".$row['id']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="edit1.php?id=<?php echo $erow['id']; ?>">
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Caption:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="a" class="form-control" value="<?php echo $erow['cap']; ?>">
						</div>
					</div>
					<div style="height:10px;"  style="display:none;"></div>
					<div class="row"  style="display:none;">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Folder:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="b" class="form-control" value="<?php echo $erow['folder']; ?>">
						</div>
					</div>
		 
					 <div class="row" style="display:none;">
            <div class="col-lg-2">
              <label class="control-label" style="position:relative; top:7px;" required>Photo Type:</label>
            </div>
            <div class="col-lg-10">
                <select name="type" class="form-control" id="type" required>
<option value="" selected="selected">Select Categories</option>
 <?php
$sql = "SELECT * FROM blog_categories";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
while( $rows = mysqli_fetch_assoc($resultset) ) {
?>
<option value="<?php echo $rows["cat_name"]; ?>" <?php if($erow['test']==$rows['cat_name'])
       {
       	?>selected="selected"
       	<?php
       }
       ?> ><?php echo $rows["cat_name"]; ?></option>
<?php } ?>
</select>  
            </div>
          </div>
           
					 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-check"></span> Save</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->