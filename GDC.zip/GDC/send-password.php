<?php
 
session_start();
 
require_once("db.php");

$sql12 = "SELECT * FROM users WHERE email='$_POST[email]'";
$result12 = $conn->query($sql12);

if($result12->num_rows > 0) { 

 
//send_mail.php
ob_start();
 
	
	require 'class/class.phpmailer.php';
	$output = '';
	 

		$txt=$_POST['email'];
		$txt2=$_POST['email'];
		$mail = new PHPMailer;
		$mail->IsSMTP();								//Sets Mailer to send message using SMTP
	$mail ->Host = "smtp.hostinger.in";
   $mail ->Port = 587; // or 587
   		$mail->SMTPAuth = true;							//Sets SMTP 
$mail->IsHTML(true);
$mail ->Username = "gdcaa@alumnigdc.in";
   $mail ->Password = "Gdcaa@2021";
   $mail ->SetFrom("gdcaa@alumnigdc.in","Admin GDCAA");
//$mail->SetFrom('alumni@nmamit-alumni.in','A');
		 $mail->SMTPSecure = 'TLS';					
		$mail->AddAddress($txt,$txt2);	//Adds a "To" address
		$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
		$mail->IsHTML(true);							//Sets message type to HTML
		//$mail->Subject = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit'; //Sets the Subject of the message
		//An HTML or plain text message body
		$mail->Subject = "Password Recovery";
		$mail->Body = "Click the below link to Update the Password  https://localhost/GDC/password_update-link.php";
		
		$mail->AltBody = '';

		$result = $mail->Send();						//Send an Email. Return true on success or false on error

		if($result["code"] == '400')
		{
			$output .= html_entity_decode($result['full_error']);
		}

	if($output == '')
	{
	//	echo 'ok';
			  echo "<script>
alert('Please Check You Email ID for Reset Password Link');
window.location.href='login.php';
</script>";
	}
	else
	{
		echo $output;
	}

ob_flush();
 
}
else
{
	echo "Error";
}
 
?>