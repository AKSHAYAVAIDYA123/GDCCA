<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Socail Network | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
  

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
</style>

<!-- Google Analytics -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-PFK425"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PFK425');</script>
<!-- /Google Analytics -->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body ></body>

    
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <header style="background-color:black;color: white;height:80px;" >

    <!-- Logo -->
    <nav class="navbar navbar-inverse" >
  <div class="container-fluid">
    <div class="navbar-header">
    <br>
      <h3>WebSiteName</h3>
    </div>
   
     <ul class="nav navbar-nav navbar-right">
      <li class="active"><a href="login.php">Home</a></li>
      <li><a href="#test1">About Us</a></li>
      <li><a href="#test2">Contact Us</a></li>
      <li><a href="#">SignUp</a></li>
      <li><a href="#">SignIn</a></li>
    </ul>
  </div>
</nav>
  
 </header>
 <style type="text/css">
 a {
    color: #000;
    font-size: 25px;
    text-decoration: none;
}

a:hover 
{
     color:#000; 
      font-size: 25px;
     text-decoration:none; 
     cursor:pointer;  
}</style>


     
  </header>
  </style>
 
  <div id="slider"   >
<figure>
<img src="images/p5.jpg" height="602" width="602">
<!--<img src="images/p6.jpg" title="wewaeff" height="700" width="100%">
<img src="images/p2.jpg" height="700" width="100%" width="100%">
<img src="images/p3.jpg" height="700" width="100%">
<img src="images/p4.jpg" height="700" width="100%">-->
<img src="images/p6.jpg" title="wewaeff" height="602" width="100%">
<img src="images/p2.jpg" height="602" width="100%" width="100%">
<img src="images/p3.jpg" height="602" width="100%">
<img src="images/p4.jpg" height="602" width="100%">-->
</figure> 
 
 <!--
                            <div class="form-top" style="background-color: maroon; padding: 0 25px 0px 25px; border-color: black;">
                              <div class="form-top-left">
                                <h3>Login to our site</h3>
                                  <p>Enter username and password to log on:</p>
                              </div>
                              <div class="form-top-right">
                                <i class="fa fa-lock"></i>
                              </div>
                              </div>
                              <div class="form-bottom" style="background-color: maroon; padding: 25px 25px 1px 25px;">
                     
                           
    <form id="loginForm" method="post">
      <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
       
        <div class="col-xs-4">

          <button type="submit" class="btn btn-info">Sign In</button>          
        </div>
        
      </div>
      <div class="row">
        <div class="col-xs-12">
            <span id="loginError" class="color-red hide-me">Invalid Email/Password!</span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form> 
    <a href="#" data-toggle="modal" data-target="#myModal">I forgot my password</a><br>
    <a href="#" class="text-center " data-toggle="modal" data-target="#myModal1">Create an account</a>
</div>-->
</div>
</script>
<section  style="background-color:black;color:white;font-size:35px" >
 <br>
    <br>
    <br>
<center><h3 class="mbr-fonts-style mbr-text display-5" id="test1"><b>About Alumini Connect</b></h3></center>
   

    <div class="mbr-overlay" style="background-color: rgb(70, 80, 82); opacity: 0.7;" id="test2" onclick="window.location.hash='back'; "></div>

    <div class="container">
        <div class="content text-white">
             <div class="mbr-fonts-style display-7">
                <h4>
                  <i> Using Alumini Connect We can easly Communicate with Our Classmates and Share Our Ideas them and Make a friendship with other Department Aluminies.</i>
                </h4>
                <p class="mbr-text">
                   
                  
                         <div class="container" >
    <center>  <caption><h3><b>Developed By:</h3></b></caption>
        <div class="row">
          <div  class="col-md-3">
          </div>
          <div class="col-md-3">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             &nbsp&nbsp&nbsp&nbsp 
               <img src="log_asset/images/index.jpg" height="120" width="120">
                  &nbsp&nbsp&nbsp&nbsp<h4>Anantha Murthy
                
                  Ass. Professor<br>Department of MCA<br>NMAMIT NITTE<br>9743702262</li>
         
              </div>
            </div>
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             
                  </h3>
        
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             &nbsp&nbsp&nbsp&nbsp 
               <img src="log_asset/images/index.jpg" height="120" width="120">
                  &nbsp&nbsp&nbsp&nbsp<h4>Anantha Murthy
                
                  Ass. Professor<br>Department of MCA<br>NMAMIT NITTE<br>9743702262</li>
         
              </div>
            </div>
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             
                  </h3>
        
                </ul>
              </div>
            </div>
          </div>
         
          <div class="col-md-3"></div>
        </div>
      </div>
                    </footer>
                </p>
            </div>
        </div>
       <br><br>
    </div>
</section>
<section class="cid-qv5AKsQ6xL" id="footer2-3g" data-rv-view="8784">

    

    <center><h3 style="color:black;"><i><b>Contact Us</b></i></h3></center>

    <div class="container" id="test3"  >
     <br>
      <br> <br>
      
      <br>
      <div >
        <div class="media-container-row content mbr-white" >

            <div class="col-12 col-md-3 mbr-fonts-style display-7" id="test3" >
                <p class="mbr-text">
                    <strong>Address</strong>
                    <br>
                    <br>1234 Street Name
                    <br>City, AA 99999
                    <br>
                    <br>
                    <br><strong>Contacts</strong>
                    <br>
                    <br>Email: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="45363035352a373105282a272c372c36206b262a28">[email&#160;protected]</a>
                    <br>Phone: +1 (0) 000 0000 001
                    <br>Fax: +1 (0) 000 0000 002
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <p class="mbr-text">
                    <strong>Connectivity</strong>
                    <br>
                    <br><a class="text-white" href="#">Facebook</a>
                    <br><a class="text-white" href="#">Instagram</a>
                    <br><a class="text-white" href="#">Youtube</a>
                    <br>
                      </p>
            </div>
            <div class="col-12 col-md-6">
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0Dx_boXQiwvdz8sJHoYeZNVTdoWONYkU&amp;q=place_id:ChIJW17YWkFWuzsR-sev9sZ6txA" allowfullscreen=""></iframe></div>
            </div>
        </div>
        </div>
        
    </div>
</section>
 
<section style="background-color:black">
  <footer class="main-footer" style="background-color:black;color:white;">
  
   <h4> <b><strong>Alumini Connect</strong> All rights
    reserved.</b></h4>
  </footer>
    </section>

    

    
       <div class="modal fade" id="auth_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                   <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Authentication</h4></center>
                </div>
                
                 <div class="modal-body">
        <div class="container-fluid">
                <form class="form-horizontal" action="verifyotp.php"  method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                
                 
    <input type="text" class="form-control" name="aut" placeholder="Enter the 6 digit Password"> 
                  </label>
                </div>
              </div>
                </div>
                        <div class="box-footer">
               
                  </div>
          </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Send</a>
        </form>
                </div>
                </div>
                </form>
                </div>
                </div>



       <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                   <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Passout Recovery</h4></center>
                </div>
                
                 <div class="modal-body">
        <div class="container-fluid">
                <form class="form-horizontal" action="send-password.php"  method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                
                 
    <input type="text" class="form-control" name="email" placeholder="Enter the Registerd Mail ID"> 
                  </label>
                </div>
              </div>
                </div>
                        <div class="box-footer">
               
                  </div>
          </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Send</a>
        </form>
                </div>
                </div>
                </form>
                </div>
                </div>


       <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
            <div class="modal-content">
                   <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Verification</h4></center>
                </div>
                
                 <div class="modal-body">
        <div class="container-fluid">
                <form class="form-horizontal" action="verifyusn.php"  method="post" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                <div class="form-group ">
       <input type="text" class="form-control" name="usn" placeholder="Enter the University Serial Number">
       <br>
 <input type="text" class="form-control" name="yop" placeholder="Year of Passout">
       <br>

      <select name="Department" class="form-control">
         

        <option>MCA</option>
        <option>a</option>
        <option>b</option>
      </select>
    </div>
                 
                   </label>
                </div>
              </div>
                </div>
                        <div class="box-footer">
               
                  </div>
          </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Send</a>
        </form>
                </div>
                </div>
                </form>
                </div>
                </div>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
</div>


<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
<script>
  $(function() {
    $("#registeredSuccessfully:visible").fadeOut(8000);
  });
</script>
<script>
  $("#loginForm").on("submit", function(e) {
    e.preventDefault();
    $.post("checklogin.php", $(this).serialize() ).done(function(data) {
        var result = $.trim(data);
        if(result == "ok") {
             $('#auth_model').modal('show');
           //window.location.href = "index.php";
        }else if(result == "okay") {
          window.location.href = "user-profile.php";
        } else {
          $("#loginError").show();
        }
      });
  });


</script>
 

</body>
</html>
