
<!DOCTYPE html>
<html>
<head>
  <!-- Site made with Mobirise Website Builder v4.3.5, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.3.5, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/logo2.png" type="image/x-icon">
  <meta name="description" content="Responsive Footer Template - Free Download">
  <title>Alumini Connect</title>
  <link rel="stylesheet" href="log_asset/assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="log_asset/assets/tether/tether.min.css">
  <link rel="stylesheet" href="log_asset/assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="log_asset/assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="log_asset/assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="log_asset/assets/socicon/css/styles.css">
  <link rel="stylesheet" href="log_asset/assets/dropdown/css/style.css">
  <link rel="stylesheet" href="log_asset/assets/theme/css/style.css">
  <link rel="stylesheet" href="log_asset/assets/mobirise/css/mbr-additional.css" type="text/css">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Custom -->
  <link rel="stylesheet" href="dist/css/custom.css">
  <link rel="stylesheet" href="dist/css/slider.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
  

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
</style>

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  
  
<style>
.mySlides {display:none;}
</style>
  
</head>
<body>

<!-- Google Analytics -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-PFK425"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PFK425');</script>
<!-- /Google Analytics -->


<section class="menu cid-qv1frvgcz3" once="menu" id="menu1-3e" data-rv-view="8776">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent" style="background-color:black;">
       
        <div class="menu-logo">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="https://mobirise.com/bootstrap-template/">
                        ALUMINI CONNECT</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" >
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="false"><li class="nav-item"><a class="nav-link link text-white  display-4" href="index.php"  aria-expanded="false">
                        
                        Home</a>  </li><li class="nav-item"><a class="nav-link link text-white  display-4" href="#test2"  aria-expanded="false">
                        
                        About Us</a>  </li><li class="nav-item"><a class="nav-link link text-white  display-4" href="#test3"  aria-expanded="false">
                        
                        Contact Us</a>  </li><li class="nav-item"><a class="nav-link link text-white  display-4"  href="#" data-toggle="modal" data-target="#myModal1"  aria-expanded="false">
                        
                        SignIn</a>  </li> </li><li class="nav-item"><a class="nav-link link text-white  display-4" href="#test4"  aria-expanded="false">
                        
                        SignUp</a>  </li>
                       </ul></div>
             
        </div>
    </nav>
</section>
    
<section  id="header11-43" >
 
<style>
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 5s;
  animation-name: fade;
  animation-duration: 5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
</head>
<body>
 
 <br>
 <br>
 <br>

<div class="slideshow-container">

<div class="mySlides fade">
  <img src="log_asset/images/1.jpg" height="590" width="100%">
  
  
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="log_asset/images/2.jpg" height="590" width="100%">
 
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="log_asset/images/3.jpg" height="590" width="100%">
  
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>

</body>
</html> 



</div>
</section>
<section class="footer4 cid-qv5AL7fBTQ" id="footer4-3i" data-rv-view="8790">

    

    

    <div class="container">
        <div class="media-container-row content mbr-white">
           
                   <div class="form-top" style="background-color: maroon; padding: 0 25px 0px 25px; border-color: black;">
                              <div class="form-top-left">
                                <h3>Login to our site</h3>
                                  <p>Enter username and password to log on:</p>
                              </div>
                              
                                <i class="fa fa-lock"></i>
                              </div>
                              </div>
                              <div class="form-bottom" style="background-color: maroon; padding: 25px 25px 1px 25px;">
                     
                           
    <form id="loginForm" method="post">
      <div class="form-group has-feedback">
        <input type="email"  id="email" name="email" placeholder="Email" class="form-first-name form-control"  required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">

          <button type="submit" class="btn btn-info">Sign In</button>          
        </div>
        <!-- /.col -->
      </div>
      <div class="row">
        <div class="col-xs-12">
            <span id="loginError" class="color-red hide-me">Invalid Email/Password!</span>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <?php if(isset($_SESSION['registeredSuccessfully'])) { ?>
            <span id="registeredSuccessfully" class="color-green">You Have Registered Successfully!</span>
          <?php unset($_SESSION['registeredSuccessfully']); } ?>
        </div>
      </div>
    </form>
    <!-- /.social-auth-links -->
    <a href="#" data-toggle="modal" data-target="#myModal">I forgot my password</a><br>
    <a href="#" class="text-center " data-toggle="modal" data-target="#myModal1">Create an account</a>

            </div>
            <div class="col-md-4 col-sm-8">
               
            </div>
  
        </div>
        
    </div>
</section>
<section class="cid-qv5AKCViO2" id="footer1-3f" data-rv-view="8781">
 <br>
    <br>
    <br>
<center><h4 class="mbr-fonts-style mbr-text display-5"><b>About Alumini Connect</b></h4></center>
   

    <div class="mbr-overlay" style="background-color: rgb(70, 80, 82); opacity: 0.7;" id="test2" onclick="window.location.hash='back'; "></div>

    <div class="container">
        <div class="content text-white">
             <div class="mbr-fonts-style display-7">
                <h5 class="mbr-text">
                  <i> Using Alumini Connect We can easly Communicate with Our Classmates and Share Our Ideas them and Make a friendship with other Department Aluminies.</i>
                </h5>
                <p class="mbr-text">
                   
                  
                         <div class="container">
    <center>  <caption><h3><b>Developed By:</h3></b></caption>
        <div class="row">
          <div  class="col-md-3">
          </div>
          <div class="col-md-3">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             &nbsp&nbsp&nbsp&nbsp 
               <img src="log_asset/images/index.jpg" height="120" width="120">
         
              </div>
            </div>
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                &nbsp&nbsp&nbsp&nbsp<h5>Anantha Murthy</h5>
                
                  Ass. Professor<br>Department of MCA<br>NMAMIT NITTE<br>9743702262</li>
                  
        
                </ul>
              </div>
            </div>
          </div>
         <div class="col-md-3">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             &nbsp&nbsp&nbsp&nbsp 
               <img src="log_asset/images/index.jpg" height="120" width="120">
         
              </div>
            </div>
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                &nbsp&nbsp&nbsp&nbsp<h5>AKSHAY VAIDYA U</h5>
                
                 5th Sem<br>4NM17MCA03<br>MCA<br>NMAMIT NITTE</li>
                  
        
                </ul>
              </div>
            </div>
          </div>
       
         
          <div class="col-md-3"></div>
        </div>
      </div>
                    </footer>
                </p>
            </div>
        </div>
       <br><br>
    </div>
</section>

<section class="cid-qv5AKsQ6xL" id="footer2-3g" data-rv-view="8784">

    

    <center><h3 style="color:white;"><i><b>Contact Us</b></i></h3></center>

    <div class="container" id="test3"  >
     <br>
      <br> <br>
      
      <br>
      <div >
        <div class="media-container-row content mbr-white" >

            <div class="col-12 col-md-3 mbr-fonts-style display-7" id="test3" >
                <p class="mbr-text">
                    <strong>Address</strong>
                    <br>
                    <br>1234 Street Name
                    <br>City, AA 99999
                    <br>
                    <br>
                    <br><strong>Contacts</strong>
                    <br>
                    <br>Email: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="45363035352a373105282a272c372c36206b262a28">[email&#160;protected]</a>
                    <br>Phone: +1 (0) 000 0000 001
                    <br>Fax: +1 (0) 000 0000 002
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <p class="mbr-text">
                    <strong>Connectivity</strong>
                    <br>
                    <br><a class="text-white" href="#">Facebook</a>
                    <br><a class="text-white" href="#">Instagram</a>
                    <br><a class="text-white" href="#">Youtube</a>
                    <br>
                      </p>
            </div>
            <div class="col-12 col-md-6">
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0Dx_boXQiwvdz8sJHoYeZNVTdoWONYkU&amp;q=place_id:ChIJW17YWkFWuzsR-sev9sZ6txA" allowfullscreen=""></iframe></div>
            </div>
        </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                     
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                       <br>
                       <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!--
<section class="footer3 cid-qv5AKCViO2" id="footer3-3h" data-rv-view="8787">

    

    <div class="mbr-overlay" style="background-color: rgb(255, 255, 255); opacity: 0.9;"></div>

    <div class="container">
        <div class="media-container-row content">
            <div class="col-md-2 col-sm-4">
                <div class="mb-3 img-logo">
                    <a href="https://mobirise.com/">
                         <img src="assets/images/logo2.png" alt="Mobirise" media-simple="true">
                    </a>
                </div>
                <p class="mbr-fonts-style foot-logo display-7">
                    Footer Template
                </p>
            </div>
            <div class="col-md-3 col-sm-4">
                <p class="mb-4 mbr-fonts-style foot-title display-7">
                    RECENT NEWS
                </p>
                <p class="mbr-text mbr-links-column mbr-fonts-style display-7">
                    <a href="#" class="text-black">About us</a>
                    <br><a href="#" class="text-black">Services</a>
                    <br><a href="#" class="text-black">Selected Work</a>
                    <br><a href="#" class="text-black">Get In Touch</a>
                    <br><a href="#" class="text-black">Careers</a>
                </p>
            </div>
            <div class="col-md-3 col-sm-4">
                <p class="mb-4 mbr-fonts-style foot-title display-7">
                    CATEGORIES
                </p>
                <p class="mbr-text mbr-fonts-style mbr-links-column display-7">
                    <a href="#" class="text-black">Business</a>
                    <br><a href="#" class="text-black">Design</a>
                    <br><a href="#" class="text-black">Real life</a>
                    <br><a href="#" class="text-black">Science</a>
                    <br><a href="#" class="text-black">Tech</a>
                </p>
            </div>
            <div class="col-md-4 col-sm-12">
                <p class="mb-4 mbr-fonts-style foot-title display-7">
                    SUBSCRIBE
                </p>
                <p class="mbr-text form-text mbr-fonts-style display-7">
                    Get monthly updates and free resources.
                </p>
                <div class="media-container-column" data-form-type="formoid">
                    <div data-form-alert="" hidden="" class="align-center">
                        Thanks for filling out the form!
                    </div>

                    <form class="form-inline" action="https://mobirise.com/" method="post" data-form-title="Mobirise Form">
                        <input type="hidden" value="z5SepRB/mUb69FjL0TH5DB/WVJx38pLLA1OClb4pCHcPR4ZKG8nzWzpij5S+oyArIY14489ArzC+WrTd3csn/29MDHNq389JO9sezeq6/5EF1/O3JIej49ChnB+h7Hb3" data-form-email="true">
                        <div class="form-group">
                            <input type="email" class="form-control input-sm input-inverse my-2" name="email" required="" data-form-field="Email" placeholder="Email" id="email-footer3-3h">
                        </div>
                        <div class="input-group-btn m-2">
                            <button href="" class="btn btn-primary display-4" type="submit" role="button">Subscribe</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row">
                <div class="col-sm-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                        © Copyright 2018 Footer Template - All Rights Reserved
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                        <div class="soc-item">
                            <a href="https://twitter.com/mobirise" target="_blank">
                                <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                                <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.youtube.com/c/mobirise" target="_blank">
                                <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://instagram.com/mobirise" target="_blank">
                                <span class="socicon-instagram socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://plus.google.com/u/0/+Mobirise" target="_blank">
                                <span class="socicon-googleplus socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.behance.net/Mobirise" target="_blank">
                                <span class="socicon-behance socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
-->

    <!--

<section class="cid-qv5ALrxDIE" id="footer5-3j" data-rv-view="8793">


    

    <div class="container">
        <div class="media-container-row">
            <div class="col-md-3">
                <div class="media-wrap">
                    <a href="https://mobirise.com/">
                       <img src="assets/images/logo2.png" alt="Mobirise" media-simple="true">
                    </a>
                </div>
            </div>
            <div class="col-md-9">
                <p class="mbr-text align-right links mbr-fonts-style display-7">
                    <a href="#" class="text-black">ABOUT</a> &nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#" class="text-black">TERMS</a> &nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#" class="text-black">CAREERS</a> &nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#" class="text-black">CONTACT</a>
                </p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-md-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                        © Copyright 2018 Footer Template- All Rights Reserved
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                        <div class="soc-item">
                            <a href="https://twitter.com/mobirise" target="_blank">
                                <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                                <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.youtube.com/c/mobirise" target="_blank">
                                <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://instagram.com/mobirise" target="_blank">
                                <span class="socicon-instagram socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://plus.google.com/u/0/+Mobirise" target="_blank">
                                <span class="socicon-googleplus socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.behance.net/Mobirise" target="_blank">
                                <span class="socicon-behance socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
-->
<!--<section once="" class="cid-qv5ALL8e7H" id="footer7-3k" data-rv-view="8796">

    

    <div class="mbr-overlay" style="opacity: 0.4; background-color: rgb(51, 42, 104);"></div>

    <div class="container">
        <div class="media-container-row align-center mbr-white">
            <div class="row">
                <ul class="foot-menu">
                    
                    
                    
                    
                    
                <li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="text-white mbr-bold" href="#" target="_blank">About us</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="text-white mbr-bold" href="#" target="_blank">Services</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="text-white mbr-bold" href="#" target="_blank">Get In Touch</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="text-white mbr-bold" href="#" target="_blank">Careers</a>
                    </li><li class="foot-menu-item mbr-fonts-style display-7">
                        <a class="text-white mbr-bold" href="#" target="_blank">Work</a>
                    </li></ul>
            </div>
            <div class="row">
                <div class="social-list align-right pb-2">
                    
                    
                    
                    
                    
                    
                <div class="soc-item">
                        <a href="https://twitter.com/mobirise" target="_blank">
                            <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                            <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://www.youtube.com/c/mobirise" target="_blank">
                            <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://instagram.com/mobirise" target="_blank">
                            <span class="socicon-instagram socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://plus.google.com/u/0/+Mobirise" target="_blank">
                            <span class="socicon-googleplus socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                        </a>
                    </div><div class="soc-item">
                        <a href="https://www.behance.net/Mobirise" target="_blank">
                            <span class="socicon-behance socicon mbr-iconfont mbr-iconfont-social" media-simple="true"></span>
                        </a>
                    </div></div>
            </div>
            <div class="row row-copirayt">
                <p class="mbr-text mb-0 mbr-fonts-style mbr-white display-7">
                  
                </p>
            </div>
        </div>
    </div>
</section>


  -->

<section once="" class="cid-qv5AM4LlJp" id="footer6-3l" data-rv-view="8874">

    

    

    <div class="container">
        <div class="media-container-row align-center mbr-white">
            <div class="col-12">
                <p class="mbr-text mb-0 mbr-fonts-style display-7">
                     Alumini Connect - All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</section>


  <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touch-swipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  <script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<!-- Custom -->
<script>
  $(function() {
    $("#registeredSuccessfully:visible").fadeOut(8000);
  });
</script>
<script>
  $("#loginForm").on("submit", function(e) {
    e.preventDefault();
    $.post("checklogin.php", $(this).serialize() ).done(function(data) {
        var result = $.trim(data);
        if(result == "ok") {
             $('#auth_model').modal('show');
           //window.location.href = "index.php";
        }else if(result == "okay") {
          window.location.href = "user-profile.php";
        } else {
          $("#loginError").show();
        }
      });
  });


</script>
 

  
</body>
</html>